// =====================================================================
// v3.3: Treino — "Aprender a Aprender" (programa de 8 semanas do David).
// Base científica: prática de recuperação, repetição espaçada, intercalação, elaboração,
// codificação dupla e metacognição (Dunlosky et al. 2013; Roediger & Karpicke 2006; Cepeda et al. 2006).
// Conteúdo de referência: doc "Aprender a Aprender — Programa do David" (Claude Docs).
//
// O que tem: sessão guiada de 30 min (6 passos com cronômetro), modo 15 min e modo "dia ruim";
// flashcards com repetição espaçada (SM-2 simplificado, intervalos 1-3-7-16-35 dias); roteiro de
// 8 fases com elos; caderno de erros (vira flashcard com 1 toque); calibração (nota prevista x real);
// revisão de domingo com 4 indicadores; card no Início; lembrete diário e de domingo.
// Tudo offline, dentro de D (vai no backup). Formato novo passa por trEstado() (não quebra dados).
// Carregar DEPOIS de inicio.js (registra o bloco no Início e estende lbLista/lbAbrirPedido).
// Depende de: D, save, render, go, tela, toast, esc, hoje, addDias, parseD, pad2, uid, NATIVO,
//             BLOCOS/inCfg/inAplicar (inicio.js), lbLista/lbAbrirPedido/lbEnviar/lbHora (lembretes.js),
//             ganharXP (arena.js, opcional), aprRender (aprender.js, opcional).
// =====================================================================

const TR_PASSOS = [
  {id:'prep',      nome:'Preparar',            min:1,  dica:'Celular longe do alcance, água do lado. Escreva uma frase só: o que você vai conseguir explicar no fim.'},
  {id:'rev',       nome:'Aquecer com revisão', min:5,  dica:'Flashcards que vencem hoje. Tente lembrar a resposta inteira antes de virar o card.'},
  {id:'tentar',    nome:'Tentar antes',        min:3,  dica:'Antes de ler o conteúdo novo, tente responder a pergunta ou o exercício. Errar aqui ajuda a gravar a resposta certa depois.'},
  {id:'ativo',     nome:'Estudar ativo',       min:12, dica:'Leia ou assista em trechos curtos. A cada trecho: pare, resuma com suas palavras e desenhe um esquema.'},
  {id:'recuperar', nome:'Recuperar',           min:5,  dica:'Feche tudo. Folha em branco ou áudio: o que aprendi, por que funciona e um exemplo real (obra, trabalho, dia a dia).'},
  {id:'fechar',    nome:'Fechar o ciclo',      min:4,  dica:'Confira o que errou, crie flashcards das lacunas e registre onde parou.'}
];
const TR_MODOS = {
  '30':   {nome:'Sessão completa', passos:['prep','rev','tentar','ativo','recuperar','fechar'], fator:1,   xp:30},
  '15':   {nome:'Sessão curta',    passos:['prep','rev','tentar','ativo','recuperar','fechar'], fator:0.5, xp:15},
  'ruim': {nome:'Dia ruim',        passos:['prep','rev'],                                       fator:1,   xp:10}
};
const TR_ELOS = ['Ferro','Bronze','Prata','Ouro','Platina','Esmeralda','Diamante','Mestre'];
const TR_FASES = [
  {foco:'Hábito e ambiente', ex:'Uma sessão curta (15 min) por dia, no mesmo horário, com o celular fora do quarto.',
   crit:'6 de 7 dias com sessão', pq:'Mesmo horário e mesmo lugar viram gatilho automático. Com TDAH, começar sempre vale mais do que aguentar muito.'},
  {foco:'Recuperação', ex:'Depois de cada aula: folha em branco, 5 min escrevendo tudo o que lembra, depois conferir no material.',
   crit:'Fez a folha em branco em todas as aulas da semana', pq:'Tirar a informação da memória grava mais do que reler. É o efeito de testagem.'},
  {foco:'Repetição espaçada', ex:'Criar 5 a 10 flashcards por aula e revisar os que vencem no dia.',
   crit:'Revisões do dia zeradas em 5 dias da semana', pq:'Revisar em intervalos que crescem segura a curva do esquecimento com o mínimo de tempo.'},
  {foco:'Elaboração', ex:'Explicar 1 conceito por dia em voz alta ou num áudio de 2 min, sem olhar.',
   crit:'Explicar 3 conceitos sem travar', pq:'Perguntar "por quê?" e "como isso se liga ao que já sei?" prende a ideia nova às antigas.'},
  {foco:'Intercalação', ex:'Listas misturando assuntos (traço, volume, conversão de unidades). Cada erro vai para o caderno de erros com o porquê.',
   crit:'10 ou mais erros anotados no caderno', pq:'Misturar obriga você a escolher a estratégia certa, como na prova e na obra.'},
  {foco:'Codificação dupla', ex:'Transformar cada aula num desenho ou esquema de 1 página e explicar o desenho.',
   crit:'5 esquemas que você explica sem consulta', pq:'Palavra e imagem juntas criam dois caminhos para a mesma lembrança.'},
  {foco:'Metacognição', ex:'Antes de cada teste ou lista, registrar a nota prevista; depois, a real.',
   crit:'Diferença entre previsão e resultado abaixo de 20 pontos', pq:'Quem sabe o que não sabe estuda o que precisa e para de perder tempo no que já domina.'},
  {foco:'Transferência', ex:'Aprender um assunto novo fora do curso (ex.: um tema de geopolítica) usando só o método.',
   crit:'Explicar o assunto novo em 5 min para alguém', pq:'Usar o método num tema novo prova que ele virou seu, e não só do curso.'}
];
const TR_LADDER = [1, 3, 7, 16, 35];
const TR_NOTAS = ['Errei', 'Difícil', 'Bom', 'Fácil'];

// ---------- Estado ----------
function trEstado(){
  if(!D.treino || typeof D.treino !== 'object') D.treino = {};
  const t = D.treino;
  t.cfg = Object.assign({lembrete:true, hora:'19:00', domingo:true, domingoHora:'18:00'}, t.cfg || {});
  if(!(t.fase >= 1)) t.fase = 1;
  if(!t.fasesOk || typeof t.fasesOk !== 'object') t.fasesOk = {};
  ['sessoes','cards','revs','erros','calib','explicados'].forEach(k => { if(!Array.isArray(t[k])) t[k] = []; });
  if(!Array.isArray(t.decks) || !t.decks.length) t.decks = ['Edificações', 'Livre'];
  if(!t.zerou || typeof t.zerou !== 'object') t.zerou = {};
  if(!t.domingos || typeof t.domingos !== 'object') t.domingos = {};
  if(t.sessao && !TR_MODOS[t.sessao.modo]) t.sessao = null;
  return t;
}
let trAba = 'hoje', trDeck = 'todos', trRev = null, trCalOk = null;

// ---------- Datas e números ----------
const trDiasAtras = n => addDias(hoje(), -n);
function trDiasComSessao(n){ const ini = trDiasAtras(n - 1), s = new Set(); trEstado().sessoes.forEach(x => { if(x.data >= ini) s.add(x.data); }); return s.size; }
function trFezHoje(){ return trEstado().sessoes.some(x => x.data === hoje()); }
function trSequencia(){
  const s = new Set(trEstado().sessoes.map(x => x.data));
  let d = s.has(hoje()) ? hoje() : addDias(hoje(), -1), n = 0;
  while(s.has(d)){ n++; d = addDias(d, -1); }
  return n;
}
function trVencem(deck){ const h = hoje(); return trEstado().cards.filter(c => c.vence <= h && (!deck || deck === 'todos' || c.deck === deck)).sort((a, b) => a.vence < b.vence ? -1 : 1); }
function trRetencao(dias){
  const ini = trDiasAtras((dias || 7) - 1), r = trEstado().revs.filter(x => x.d >= ini);
  return r.length ? {pct: Math.round(r.filter(x => x.r > 0).length / r.length * 100), n: r.length} : null;
}
function trCalibracao(qtd){
  const c = trEstado().calib.filter(x => x.real != null).slice(-(qtd || 3));
  return c.length ? Math.round(c.reduce((s, x) => s + Math.abs(x.prev - x.real), 0) / c.length) : null;
}
function trExplicadosSemana(){ const ini = trDiasAtras(6); return trEstado().explicados.filter(x => x.data >= ini); }
function trEloAtual(){ const t = trEstado(); return t.fase > TR_FASES.length ? 'Desafiante' : TR_ELOS[t.fase - 1]; }

// O que dá para medir de cada fase (o David confirma o critério; o app só mostra o número)
function trMedida(i){
  const t = trEstado();
  if(i === 0){ const n = trDiasComSessao(7); return {txt: n + ' de 7 dias com sessão', ok: n >= 6}; }
  if(i === 2){ const ini = trDiasAtras(6), n = Object.keys(t.zerou).filter(d => d >= ini).length; return {txt: n + ' de 5 dias com revisões zeradas nesta semana', ok: n >= 5}; }
  if(i === 3){ const n = trExplicadosSemana().length; return {txt: n + ' conceito(s) explicado(s) sem consulta nesta semana', ok: n >= 3}; }
  if(i === 4){ const n = t.erros.length; return {txt: n + ' de 10 erros no caderno', ok: n >= 10}; }
  if(i === 6){ const c = trCalibracao(3); return c == null ? {txt: 'Registre previsão e nota real em Provas', ok: false} : {txt: 'Diferença média nas últimas provas: ' + c + ' pontos', ok: c < 20}; }
  return null;
}

// ---------- Flashcards (SM-2 simplificado) ----------
function trAgendar(c, r){
  c.ease = c.ease || 2.5; c.int = c.int || 0; c.rep = c.rep || 0;
  if(r === 0){ c.rep = 0; c.int = 1; c.ease = Math.max(1.3, c.ease - 0.2); c.lapsos = (c.lapsos || 0) + 1; }
  else if(r === 1){ c.int = Math.max(1, Math.round(c.int * 1.2)); c.ease = Math.max(1.3, c.ease - 0.15); }
  else if(r === 2){ c.rep += 1; c.int = c.rep <= TR_LADDER.length ? TR_LADDER[c.rep - 1] : Math.round(c.int * c.ease); }
  else { c.rep += 2; c.int = c.rep <= TR_LADDER.length ? TR_LADDER[c.rep - 1] : Math.round(c.int * c.ease * 1.3); c.ease = Math.min(3.5, c.ease + 0.15); }
  c.int = Math.max(1, Math.min(c.int, 365));
  c.vence = addDias(hoje(), c.int);
  return c;
}
function trNovoCard(deck, f, v, origem){
  f = String(f || '').trim(); v = String(v || '').trim();
  if(!f || !v){ toast('Preencha a pergunta e a resposta'); return null; }
  const c = {id: uid(), deck: deck || 'Livre', f, v, rep: 0, int: 0, ease: 2.5, vence: addDias(hoje(), 1), criado: hoje(), origem: origem || ''};
  trEstado().cards.push(c); save();
  return c;
}
function trIniciarRevisao(deck){
  const fila = trVencem(deck).map(c => c.id);
  trRev = {fila, i: 0, virado: false, deck: deck || 'todos', certos: 0};
  return fila.length;
}
function trNota(r){
  const t = trEstado(); if(!trRev) return;
  const c = t.cards.find(x => x.id === trRev.fila[trRev.i]); if(!c) return;
  trAgendar(c, r);
  t.revs.push({d: hoje(), c: c.id, r});
  if(t.revs.length > 3000) t.revs = t.revs.slice(-3000);
  if(r > 0) trRev.certos++;
  if(r === 0) trRev.fila.push(c.id + '#de-novo');   // errou: aparece de novo no fim desta revisão (sem reagendar)
  trRev.i++; trRev.virado = false;
  if(!trVencem().length) t.zerou[hoje()] = true;
  save(); trRender();
}
function trNotaDeNovo(ok){ trRev.i++; trRev.virado = false; if(ok) trRev.certos++; trRender(); }

function trRevisaoHTML(){
  const t = trEstado();
  if(!trRev) return '';
  if(trRev.i >= trRev.fila.length){
    const n = trRev.fila.filter(x => !String(x).includes('#')).length;
    return '<div class="card pad tr-col"><b style="font-size:17px">' + (n ? 'Revisão feita' : 'Nada para revisar hoje') + '</b>' +
      '<span class="sub">' + (n ? n + ' card(s) revisado(s). Cada um volta na data certa.' : 'Crie cards no fim da sessão ou na aba Cards.') + '</span></div>';
  }
  const id = String(trRev.fila[trRev.i]), deNovo = id.includes('#'), c = t.cards.find(x => x.id === id.split('#')[0]);
  if(!c){ trRev.i++; return trRevisaoHTML(); }
  const rest = trRev.fila.length - trRev.i;
  return '<div class="card pad tr-col">' +
    '<div class="between"><span class="sub">' + esc(c.deck) + (deNovo ? ' · de novo' : '') + '</span><span class="sub">faltam ' + rest + '</span></div>' +
    '<div class="tr-carta">' + esc(c.f) + '</div>' +
    (trRev.virado ?
      '<div class="tr-resp">' + esc(c.v) + '</div>' +
      (deNovo ?
        '<div class="row"><button class="btn outline" style="flex:1" onclick="trNotaDeNovo(false)">Ainda não</button><button class="btn primary" style="flex:1" onclick="trNotaDeNovo(true)">Agora foi</button></div>' :
        '<div class="tr-notas">' + TR_NOTAS.map((n, i) => '<button class="btn ' + (i === 0 ? 'danger' : i === 2 ? 'primary' : 'outline') + '" onclick="trNota(' + i + ')">' + n + '<small>' + trPrevia(c, i) + '</small></button>').join('') + '</div>') :
      '<button class="btn dark full" onclick="trRev.virado=true;trRender()">Mostrar resposta</button>') +
    '</div>';
}
function trPrevia(c, r){ const x = trAgendar(JSON.parse(JSON.stringify(c)), r); return x.int === 1 ? 'amanhã' : x.int + ' dias'; }

// ---------- Sessão guiada ----------
function trDuracao(passoId, modo){ const p = TR_PASSOS.find(x => x.id === passoId); return Math.round(p.min * 60 * TR_MODOS[modo].fator); }
function trComecar(modo){
  const t = trEstado();
  t.sessao = {modo, i: 0, ini: Date.now(), passoIni: Date.now(), pausa: null, meta: '', materia: t.decks[0], explicou: null, avisou: -1, clareza: 0, onde: ''};
  trRev = null; trAba = 'hoje'; save();
  if(tela !== 'treino') go('treino'); else trRender();
}
function trPassoAtual(){ const s = trEstado().sessao; return s ? TR_PASSOS.find(p => p.id === TR_MODOS[s.modo].passos[s.i]) : null; }
function trRestante(){
  const s = trEstado().sessao; if(!s) return 0;
  const agora = s.pausa || Date.now();
  return trDuracao(trPassoAtual().id, s.modo) - Math.floor((agora - s.passoIni) / 1000);
}
function trFmt(seg){ const neg = seg < 0; seg = Math.abs(seg); return (neg ? '+' : '') + Math.floor(seg / 60) + ':' + pad2(seg % 60); }
function trPausar(){
  const s = trEstado().sessao; if(!s) return;
  if(s.pausa){ s.passoIni += Date.now() - s.pausa; s.pausa = null; } else s.pausa = Date.now();
  save(); trRender();
}
function trLerCampos(){
  const s = trEstado().sessao; if(!s) return;
  const g = id => document.getElementById(id);
  if(g('tr-meta')) s.meta = g('tr-meta').value.trim();
  if(g('tr-materia')) s.materia = g('tr-materia').value;
  if(g('tr-onde')) s.onde = g('tr-onde').value.trim();
}
function trAvancar(){
  const t = trEstado(), s = t.sessao; if(!s) return;
  trLerCampos();
  const p = trPassoAtual();
  if(p.id === 'prep' && !s.meta){ toast('Escreva o que vai conseguir explicar no fim (pode ser curto)'); return; }
  const passos = TR_MODOS[s.modo].passos;
  if(s.i >= passos.length - 1){ trConcluir(); return; }
  s.i++; s.passoIni = Date.now(); s.pausa = null; trRev = null;
  if(TR_MODOS[s.modo].passos[s.i] === 'rev') trIniciarRevisao('todos');
  if(NATIVO && Android.vibrate) try{ Android.vibrate(); }catch(e){}
  save(); trRender();
}
function trVoltarPasso(){ const s = trEstado().sessao; if(!s || s.i === 0) return; trLerCampos(); s.i--; s.passoIni = Date.now(); s.pausa = null; save(); trRender(); }
function trExplicou(ok){
  const t = trEstado(), s = t.sessao; if(!s) return;
  s.explicou = ok;
  if(ok && s.meta && !t.explicados.some(x => x.data === hoje() && x.t === s.meta)) t.explicados.push({data: hoje(), t: s.meta, materia: s.materia});
  if(!ok && s.meta) toast('Normal. Vire isso um flashcard no próximo passo.');
  save(); trRender();
}
function trClareza(n){ trLerCampos(); trEstado().sessao.clareza = n; save(); trRender(); }
function trCardSessao(){
  const s = trEstado().sessao, f = document.getElementById('tr-sf'), v = document.getElementById('tr-sv');
  trLerCampos();
  if(trNovoCard(s.materia, f.value, v.value, 'sessão')){ toast('Card criado. Primeira revisão amanhã.'); trRender(); }
}
function trConcluir(){
  const t = trEstado(), s = t.sessao; if(!s) return;
  trLerCampos();
  const m = TR_MODOS[s.modo];
  t.sessoes.push({data: hoje(), modo: s.modo, meta: s.meta, materia: s.materia, clareza: s.clareza || null, onde: s.onde, explicou: s.explicou,
    min: Math.max(1, Math.round((Date.now() - s.ini) / 60000))});
  if(t.sessoes.length > 1500) t.sessoes = t.sessoes.slice(-1500);
  t.sessao = null; trRev = null; save();
  if(typeof ganharXP === 'function') ganharXP(m.xp, 'sessão de estudo');
  const seq = trSequencia();
  toast(s.modo === 'ruim' ? 'Dia ruim também conta. Sequência: ' + seq + (seq > 1 ? ' dias' : ' dia') + '.' : 'Sessão concluída. Sequência: ' + seq + (seq > 1 ? ' dias' : ' dia') + '.');
  if(typeof lbEnviar === 'function') lbEnviar(true);
  trRender(); render();
}
function trCancelar(){ if(!confirm('Encerrar sem registrar? A sessão não conta para a sequência.')) return; trEstado().sessao = null; trRev = null; save(); trRender(); }
function trCopiarPista(){
  const s = trEstado().sessao, tema = (s && s.meta) || '[assunto]';
  const txt = 'Estou estudando: ' + tema + '. Não me dê a resposta pronta. Me faça 3 perguntas curtas para eu testar se entendi; se eu errar, me dê só uma pista e espere eu tentar de novo.';
  if(NATIVO && Android.copy) Android.copy(txt); else { try{ navigator.clipboard.writeText(txt); }catch(e){} }
  toast('Pedido copiado. Cole na conversa com o Claude.');
}

function trSessaoHTML(){
  const t = trEstado(), s = t.sessao, m = TR_MODOS[s.modo], passos = m.passos, p = trPassoAtual(), rest = trRestante();
  const ult = s.i === passos.length - 1;
  let corpo = '';
  if(p.id === 'prep'){
    corpo = '<label class="f">Hoje vou conseguir explicar…<input id="tr-meta" maxlength="120" value="' + esc(s.meta) + '" placeholder="Ex.: como calcular o traço do concreto"></label>' +
      '<label class="f">Matéria<select id="tr-materia">' + t.decks.map(d => '<option' + (d === s.materia ? ' selected' : '') + '>' + esc(d) + '</option>').join('') + '</select></label>';
  } else if(p.id === 'rev'){
    if(!trRev) trIniciarRevisao('todos');
    corpo = trRevisaoHTML();
  } else if(p.id === 'ativo'){
    corpo = '<button class="btn outline full" onclick="trCopiarPista()">Travou? Copiar pedido de pista para o Claude</button>';
  } else if(p.id === 'recuperar'){
    corpo = s.meta ? '<div class="card pad tr-col"><span class="sub">No fim do passo, responda:</span><b>Conseguiu explicar "' + esc(s.meta) + '" sem olhar?</b>' +
      '<div class="row"><button class="btn ' + (s.explicou === false ? 'dark' : 'outline') + '" style="flex:1" onclick="trExplicou(false)">Ainda não</button>' +
      '<button class="btn ' + (s.explicou === true ? 'primary' : 'outline') + '" style="flex:1" onclick="trExplicou(true)">Consegui</button></div></div>' : '';
  } else if(p.id === 'fechar'){
    corpo = '<div class="card pad tr-col"><b>Clareza de hoje</b><span class="sub">1 = nebuloso · 5 = explicaria para um colega</span>' +
        '<div class="tr-clareza">' + [1,2,3,4,5].map(n => '<button class="btn ' + (s.clareza === n ? 'primary' : 'outline') + '" onclick="trClareza(' + n + ')">' + n + '</button>').join('') + '</div>' +
        '<label class="f">Onde parei<input id="tr-onde" maxlength="160" value="' + esc(s.onde) + '" placeholder="Ex.: apostila p. 42, exercício 5"></label></div>' +
      '<div class="card pad tr-col"><b>Flashcard de uma lacuna</b>' +
        '<label class="f">Pergunta<input id="tr-sf" maxlength="200" placeholder="Ex.: Para que serve o slump test?"></label>' +
        '<label class="f">Resposta curta<input id="tr-sv" maxlength="300" placeholder="Ex.: Medir a consistência do concreto fresco"></label>' +
        '<button class="btn outline full" onclick="trCardSessao()">Criar card</button></div>';
  }
  return '<div class="row"><button class="iconbtn" aria-label="Voltar" onclick="go(\'inicio\')">' + TR_SVG_VOLTAR + '</button><h1 style="flex:1">' + esc(m.nome) + '</h1>' +
      '<button class="x" aria-label="Encerrar sessão" onclick="trCancelar()">×</button></div>' +
    '<div class="tr-trilha">' + passos.map((id, i) => '<span class="' + (i < s.i ? 'ok' : i === s.i ? 'on' : '') + '"></span>').join('') + '</div>' +
    '<div class="focus tr-passo"><div class="lbl">Passo ' + (s.i + 1) + ' de ' + passos.length + '</div>' +
      '<div class="t">' + esc(p.nome) + '</div>' +
      '<div id="tr-relogio" class="timer' + (rest < 0 ? ' tr-acabou' : '') + '">' + trFmt(rest) + '</div>' +
      '<div class="s">' + esc(p.dica) + '</div>' +
      '<div class="row"><button class="btn ghost" style="flex:1" onclick="trPausar()">' + (s.pausa ? 'Continuar' : 'Pausar') + '</button>' +
      '<button class="btn white" style="flex:2" onclick="trAvancar()">' + (ult ? 'Concluir sessão' : 'Próximo passo') + '</button></div></div>' +
    corpo +
    (s.i > 0 ? '<button class="btn outline full" onclick="trVoltarPasso()">Voltar ao passo anterior</button>' : '') +
    (s.modo === '30' && s.i < 2 ? '<p class="note" style="margin:0;text-align:center">Sem energia hoje? <a href="#" onclick="trEstado().sessao.modo=\'ruim\';save();trRender();return false">Trocar para "dia ruim"</a>: só os 2 primeiros passos, e conta para a sequência.</p>' : '');
}

// ---------- Fases ----------
function trCumpriFase(){
  const t = trEstado(), i = t.fase - 1; if(i >= TR_FASES.length) return;
  if(!confirm('Confirma que cumpriu: "' + TR_FASES[i].crit + '"?')) return;
  t.fasesOk[t.fase] = hoje(); t.fase++; save();
  if(typeof ganharXP === 'function') ganharXP(100, 'fase do treino');
  toast(t.fase > TR_FASES.length ? 'Programa concluído. Elo Desafiante: agora é manutenção.' : 'Subiu para ' + TR_ELOS[t.fase - 1] + ': ' + TR_FASES[t.fase - 1].foco);
  trRender(); render();
}

// ---------- Erros e calibração ----------
function trSalvarErro(){
  const g = id => (document.getElementById(id).value || '').trim();
  const e = {id: uid(), data: hoje(), materia: document.getElementById('tr-em').value, oque: g('tr-eo'), porque: g('tr-ep'), regra: g('tr-er')};
  if(!e.oque || !e.regra){ toast('Preencha pelo menos o que errou e a regra certa'); return; }
  trEstado().erros.push(e); save(); toast('Erro anotado. Erro bem anotado vale ouro.'); trRender();
}
function trErroCard(id){
  const t = trEstado(), e = t.erros.find(x => x.id === id); if(!e || e.card) return;
  const c = trNovoCard(e.materia, e.oque + (e.porque ? ' (cuidado: ' + e.porque + ')' : '') + ' — qual a regra certa?', e.regra, 'erro');
  if(c){ e.card = c.id; save(); toast('Virou flashcard. Primeira revisão amanhã.'); trRender(); }
}
function trApagar(lista, id){ if(!confirm('Apagar?')) return; const t = trEstado(); t[lista] = t[lista].filter(x => x.id !== id); save(); trRender(); }
function trSalvarProva(){
  const nome = (document.getElementById('tr-pn').value || '').trim(), prev = Number(document.getElementById('tr-pp').value);
  if(!nome || !(prev >= 0 && prev <= 100)){ toast('Dê um nome e uma previsão de 0 a 100'); return; }
  trEstado().calib.push({id: uid(), data: hoje(), nome, prev: Math.round(prev), real: null}); save(); toast('Previsão registrada. Depois da prova, anote a nota real.'); trRender();
}
function trNotaReal(id){
  const c = trEstado().calib.find(x => x.id === id); if(!c) return;
  const v = prompt('Nota real de "' + c.nome + '" (0 a 100):', c.real == null ? '' : c.real);
  if(v == null) return; const n = Number(String(v).replace(',', '.'));
  if(!(n >= 0 && n <= 100)){ toast('Use um número de 0 a 100'); return; }
  c.real = Math.round(n); save();
  const d = c.real - c.prev;
  toast(Math.abs(d) < 10 ? 'Boa calibração.' : d > 0 ? 'Você sabia mais do que achava.' : 'Excesso de confiança: vale revisar este assunto.');
  trRender();
}

// ---------- Ações de config ----------
function trCfg(k, v){ trEstado().cfg[k] = v; save(); if(typeof lbEnviar === 'function') lbEnviar(true); trRender(); }
function trNovoDeck(){
  const n = (prompt('Nome do novo baralho (ex.: Desenho Técnico, Geopolítica):') || '').trim();
  if(!n) return; const t = trEstado(); if(t.decks.includes(n)){ toast('Esse baralho já existe'); return; }
  t.decks.push(n); trDeck = n; save(); trRender();
}
function trSalvarCard(){
  const c = trNovoCard(document.getElementById('tr-cd').value, document.getElementById('tr-cf').value, document.getElementById('tr-cv').value, 'manual');
  if(c){ toast('Card criado. Primeira revisão amanhã.'); trRender(); }
}
function trSalvarDomingo(){ const t = trEstado(); t.domingos[hoje()] = {ajuste: (document.getElementById('tr-aj').value || '').trim()}; save(); toast('Revisão da semana salva.'); trRender(); }
function trIrAba(a){ trAba = a; if(a !== 'cards') trRev = null; trRender(); document.querySelector('main').scrollTop = 0; }

// ---------- Render ----------
const TR_SVG_VOLTAR = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>';
const TR_SVG_CEREBRO = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 4a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 6 1V5a3 3 0 0 0-3-1z"/><path d="M15 4a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-6 1"/></svg>';

function trHojeHTML(){
  const t = trEstado(), i = t.fase - 1, fase = TR_FASES[i], venc = trVencem().length, seq = trSequencia(), feito = trFezHoje();
  const ehDomingo = new Date().getDay() === 0;
  return (ehDomingo ? '<button class="card pad tr-aviso" onclick="trIrAba(\'domingo\')"><b>Hoje é domingo</b><span class="sub">Faça a revisão da semana: 4 números, 2 minutos.</span></button>' : '') +
    '<div class="focus"><div class="lbl">' + (feito ? 'Sessão de hoje feita' : 'Treino de hoje') + '</div>' +
      '<div class="t">' + (fase ? 'Fase ' + t.fase + ' · ' + esc(fase.foco) : 'Manutenção') + '</div>' +
      '<div class="s">' + (fase ? esc(fase.ex) : 'Sessão padrão nos dias úteis e revisão no domingo.') + '</div>' +
      '<div class="row" style="flex-wrap:wrap;gap:6px"><span class="chip">Sequência: ' + seq + (seq === 1 ? ' dia' : ' dias') + '</span><span class="chip">' + venc + ' card(s) para hoje</span><span class="chip">Elo ' + esc(trEloAtual()) + '</span></div>' +
      '<button class="btn white" onclick="trComecar(\'' + (t.fase === 1 ? '15' : '30') + '\')">' + (feito ? 'Fazer outra sessão' : 'Começar sessão de ' + (t.fase === 1 ? '15' : '30') + ' min') + '</button>' +
      '<div class="row"><button class="btn ghost" style="flex:1" onclick="trComecar(\'' + (t.fase === 1 ? '30' : '15') + '\')">' + (t.fase === 1 ? '30 min' : '15 min') + '</button><button class="btn ghost" style="flex:1" onclick="trComecar(\'ruim\')">Dia ruim (6 min)</button></div></div>' +
    (venc ? '<button class="btn outline full" onclick="trIrAba(\'cards\');trIniciarRevisao(\'todos\');trRender()">Só revisar os ' + venc + ' card(s) agora</button>' : '') +
    '<div class="card pad tr-col"><b>Como funciona a sessão</b>' +
      TR_PASSOS.map((p, k) => '<div class="row" style="align-items:flex-start"><span class="tr-num">' + (k + 1) + '</span><span><b>' + esc(p.nome) + '</b> <span class="sub">' + p.min + ' min</span></span></div>').join('') +
      '<p class="note" style="margin:0">Regra-mãe: todo estudo termina em recuperação (tirar da cabeça sem olhar) e todo conteúdo volta em intervalos crescentes.</p></div>' +
    '<div class="card pad tr-col"><b>Lembretes</b>' +
      '<label class="row" style="font-size:15px;font-weight:600"><input type="checkbox" style="width:22px;height:22px" ' + (t.cfg.lembrete ? 'checked' : '') + ' onchange="trCfg(\'lembrete\',this.checked)"> Lembrete diário da sessão</label>' +
      '<label class="f">Horário<input type="time" value="' + esc(t.cfg.hora) + '" onchange="trCfg(\'hora\',this.value||\'19:00\')"></label>' +
      '<label class="row" style="font-size:15px;font-weight:600"><input type="checkbox" style="width:22px;height:22px" ' + (t.cfg.domingo ? 'checked' : '') + ' onchange="trCfg(\'domingo\',this.checked)"> Revisão de domingo</label>' +
      '<label class="f">Horário no domingo<input type="time" value="' + esc(t.cfg.domingoHora) + '" onchange="trCfg(\'domingoHora\',this.value||\'18:00\')"></label>' +
      '<p class="note" style="margin:0">Se já fez a sessão do dia, o lembrete daquele dia não toca.</p></div>';
}

function trCardsHTML(){
  const t = trEstado(), lista = t.cards.filter(c => trDeck === 'todos' || c.deck === trDeck), venc = trVencem(trDeck).length, ret = trRetencao(7);
  if(trRev) return '<div class="row"><button class="btn outline" onclick="trRev=null;trRender()">← Voltar aos cards</button></div>' + trRevisaoHTML();
  return '<div class="filters">' + ['todos'].concat(t.decks).map(d => '<button class="' + (trDeck === d ? 'on' : '') + '" onclick="trDeck=\'' + esc(d).replace(/'/g, "\\'") + '\';trRender()">' + (d === 'todos' ? 'Todos' : esc(d)) + '</button>').join('') +
      '<button onclick="trNovoDeck()">+ Baralho</button></div>' +
    '<div class="card pad tr-col"><div class="between"><b>' + venc + ' para revisar hoje</b><span class="sub">' + lista.length + ' no total</span></div>' +
      '<span class="sub">' + (ret ? 'Acerto nos últimos 7 dias: <b>' + ret.pct + '%</b> em ' + ret.n + ' revisões. Ideal: entre 80% e 90%.' : 'Sem revisões nos últimos 7 dias.') + '</span>' +
      '<button class="btn primary full" ' + (venc ? '' : 'disabled style="opacity:.5"') + ' onclick="trIniciarRevisao(trDeck);trRender()">Revisar agora</button></div>' +
    '<div class="card pad tr-col"><b>Novo card</b>' +
      '<label class="f">Baralho<select id="tr-cd">' + t.decks.map(d => '<option' + (d === trDeck ? ' selected' : '') + '>' + esc(d) + '</option>').join('') + '</select></label>' +
      '<label class="f">Pergunta<input id="tr-cf" maxlength="200" placeholder="Uma ideia por card. Pergunta que obriga a lembrar."></label>' +
      '<label class="f">Resposta curta<input id="tr-cv" maxlength="300" placeholder="Curta e com suas palavras"></label>' +
      '<button class="btn outline full" onclick="trSalvarCard()">Criar card</button></div>' +
    (lista.length ? '<div class="card">' + lista.slice().sort((a, b) => a.vence < b.vence ? -1 : 1).slice(0, 80).map(c =>
      '<div class="item"><span class="txt">' + esc(c.f) + '<small>' + esc(c.deck) + ' · ' + (c.vence <= hoje() ? 'vence hoje' : 'próxima: ' + quando(c.vence).toLowerCase()) + (c.lapsos ? ' · errou ' + c.lapsos + 'x' : '') + '</small></span>' +
      '<button class="x" aria-label="Apagar card" onclick="trApagar(\'cards\',\'' + c.id + '\')">×</button></div>').join('') + '</div>' : '') +
    '<p class="note" style="margin:0">Dica: card bom tem uma ideia só, pergunta que obriga a lembrar (não a reconhecer) e resposta com suas palavras.</p>';
}

function trRoteiroHTML(){
  const t = trEstado();
  return '<p class="note" style="margin:0">Cada fase acrescenta uma habilidade sem tirar a anterior. O conteúdo de treino é o próprio curso de Edificações. Só avance quando cumprir o critério.</p>' +
    TR_FASES.map((f, i) => {
      const n = i + 1, ok = !!t.fasesOk[n], atual = n === t.fase, bloq = n > t.fase, med = atual ? trMedida(i) : null;
      return '<div class="card pad tr-col tr-fase' + (bloq ? ' bloq' : '') + (atual ? ' atual' : '') + '">' +
        '<div class="between"><span class="tr-elo">' + TR_ELOS[i].toUpperCase() + '</span><span class="sub">' + (ok ? 'concluída em ' + quando(t.fasesOk[n]).toLowerCase() : atual ? 'fase atual' : 'bloqueada') + '</span></div>' +
        '<b style="font-size:16px">Semana ' + n + ' · ' + esc(f.foco) + '</b>' +
        (bloq ? '<span class="sub">Critério: ' + esc(f.crit) + '</span>' :
          '<span style="font-size:14px;line-height:1.5">' + esc(f.ex) + '</span>' +
          '<span class="sub"><b>Critério:</b> ' + esc(f.crit) + '</span>' +
          '<span class="sub"><b>Por quê:</b> ' + esc(f.pq) + '</span>' +
          (med ? '<span class="tr-medida' + (med.ok ? ' ok' : '') + '">' + esc(med.txt) + '</span>' : '') +
          (atual ? '<button class="btn primary full" onclick="trCumpriFase()">Cumpri o critério</button>' : '')) +
        '</div>';
    }).join('') +
    (t.fase > TR_FASES.length ? '<div class="focus"><div class="lbl">Elo Desafiante</div><div class="t">Programa concluído</div><div class="s">Agora é manutenção: sessão padrão nos dias úteis e revisão no domingo. Para um assunto novo, crie um baralho e repita as fases 2 a 8 nele.</div></div>' : '');
}

function trErrosHTML(){
  const t = trEstado();
  return '<div class="card pad tr-col"><b>Anotar um erro</b><span class="sub">Erro anotado com o porquê é a revisão mais barata que existe.</span>' +
      '<label class="f">Matéria<select id="tr-em">' + t.decks.map(d => '<option>' + esc(d) + '</option>').join('') + '</select></label>' +
      '<label class="f">O que eu errei<input id="tr-eo" maxlength="200" placeholder="Ex.: confundi traço em massa com traço em volume"></label>' +
      '<label class="f">Por que errei<input id="tr-ep" maxlength="200" placeholder="Ex.: li rápido o enunciado"></label>' +
      '<label class="f">Regra certa<input id="tr-er" maxlength="300" placeholder="Ex.: traço em massa usa kg; em volume, usar a massa unitária"></label>' +
      '<button class="btn primary full" onclick="trSalvarErro()">Salvar no caderno</button></div>' +
    (t.erros.length ? '<div class="card">' + t.erros.slice().reverse().slice(0, 60).map(e =>
      '<div class="item" style="align-items:flex-start;padding:10px 0"><span class="txt"><b>' + esc(e.oque) + '</b>' +
        '<small>' + (e.porque ? 'Por quê: ' + esc(e.porque) + ' · ' : '') + 'Regra: ' + esc(e.regra) + '</small><small>' + esc(e.materia) + ' · ' + quando(e.data) + '</small></span>' +
        (e.card ? '<span class="sub" style="flex-shrink:0">virou card</span>' : '<button class="pill" onclick="trErroCard(\'' + e.id + '\')">Virar card</button>') +
        '<button class="x" aria-label="Apagar erro" onclick="trApagar(\'erros\',\'' + e.id + '\')">×</button></div>').join('') + '</div>' : '<div class="empty">Caderno vazio. Na fase 5 ele precisa de 10 entradas.</div>');
}

function trProvasHTML(){
  const t = trEstado(), cal = trCalibracao(3), lista = t.calib.slice().reverse();
  return '<div class="card pad tr-col"><b>Antes de um teste ou lista</b><span class="sub">Preveja a nota de 0 a 100. Depois compare. Calibrar é saber o que você sabe.</span>' +
      '<label class="f">Prova ou lista<input id="tr-pn" maxlength="80" placeholder="Ex.: Prova de Materiais de Construção"></label>' +
      '<label class="f">Nota prevista (0 a 100)<input id="tr-pp" type="number" min="0" max="100" inputmode="numeric" placeholder="Ex.: 70"></label>' +
      '<button class="btn primary full" onclick="trSalvarProva()">Registrar previsão</button></div>' +
    (cal != null ? '<div class="card pad tr-col"><b>Diferença média (últimas 3): ' + cal + ' pontos</b><span class="sub">Meta da fase 7: abaixo de 20. O ideal é cair semana a semana.</span></div>' : '') +
    (lista.length ? '<div class="card pad tr-col">' + lista.slice(0, 30).map(c =>
      '<div class="tr-cal"><div class="between"><b style="font-size:14px">' + esc(c.nome) + '</b><span class="sub">' + quando(c.data) + '</span></div>' +
        '<div class="tr-barra"><span class="sub">Previsto</span><div class="bar"><div style="width:' + c.prev + '%;opacity:.55"></div></div><b>' + c.prev + '</b></div>' +
        (c.real == null ? '<button class="btn outline full" style="height:40px" onclick="trNotaReal(\'' + c.id + '\')">Anotar nota real</button>' :
          '<div class="tr-barra"><span class="sub">Real</span><div class="bar"><div style="width:' + c.real + '%"></div></div><b>' + c.real + '</b></div>' +
          '<span class="sub">' + (c.real - c.prev === 0 ? 'Na mosca.' : (c.real > c.prev ? 'Subestimou em ' : 'Superestimou em ') + Math.abs(c.real - c.prev) + ' pontos.') + ' <a href="#" onclick="trNotaReal(\'' + c.id + '\');return false">editar</a></span>') +
      '</div>').join('') + '</div>' : '');
}

function trDomingoHTML(){
  const t = trEstado(), dias = trDiasComSessao(7), ret = trRetencao(7), cal = trCalibracao(3), exp = trExplicadosSemana(), salvo = t.domingos[hoje()];
  const ind = (nome, valor, meta, ok) => '<div class="card pad tr-col tr-ind"><span class="sub">' + nome + '</span><b>' + valor + '</b><span class="sub ' + (ok ? 'tr-ok' : '') + '">' + meta + '</span></div>';
  return '<p class="note" style="margin:0">Se não dá para medir, vira só boa intenção. Quatro números dos últimos 7 dias:</p>' +
    '<div class="grid2">' +
      ind('Constância', dias + ' de 7 dias', dias >= 5 ? 'No alvo (5 ou mais)' : 'Alvo: 5 ou mais', dias >= 5) +
      ind('Retenção', ret ? ret.pct + '%' : '—', !ret ? 'Revise flashcards' : ret.pct > 90 ? 'Fácil demais: crie cards mais difíceis' : ret.pct >= 80 ? 'No alvo (80–90%)' : 'Abaixo de 80%: cards menores', ret && ret.pct >= 80 && ret.pct <= 90) +
      ind('Calibração', cal == null ? '—' : cal + ' pts', cal == null ? 'Registre provas' : cal < 20 ? 'Boa (abaixo de 20)' : 'Alvo: abaixo de 20', cal != null && cal < 20) +
      ind('Explicação', exp.length + ' conceito(s)', t.explicados.length + ' no total, sem consulta', exp.length > 0) +
    '</div>' +
    (exp.length ? '<div class="card pad tr-col"><b>Explicados nesta semana</b>' + exp.map(x => '<span style="font-size:14px">• ' + esc(x.t) + '</span>').join('') + '</div>' : '') +
    '<div class="card pad tr-col"><b>O que vou ajustar na próxima semana?</b>' +
      '<label class="f"><input id="tr-aj" maxlength="200" value="' + esc(salvo ? salvo.ajuste : '') + '" placeholder="Ex.: estudar antes do jantar, não depois"></label>' +
      '<button class="btn primary full" onclick="trSalvarDomingo()">' + (salvo ? 'Atualizar' : 'Salvar revisão da semana') + '</button></div>' +
    '<p class="note" style="margin:0">O teste final são as notas do SENAI: compare a média deste semestre com a do anterior.</p>';
}

function trRender(){
  const el = document.getElementById('s-treino'); if(!el) return;
  const t = trEstado();
  if(t.sessao){ el.innerHTML = trSessaoHTML(); return; }
  const abas = [['hoje','Hoje'],['cards','Cards'],['roteiro','Roteiro'],['erros','Erros'],['provas','Provas'],['domingo','Domingo']];
  el.innerHTML =
    '<div class="row"><button class="iconbtn" aria-label="Voltar" onclick="go(\'inicio\')">' + TR_SVG_VOLTAR + '</button><h1>Treino do cérebro</h1></div>' +
    '<div class="filters">' + abas.map(a => '<button class="' + (trAba === a[0] ? 'on' : '') + '" onclick="trIrAba(\'' + a[0] + '\')">' + a[1] + '</button>').join('') + '</div>' +
    ({hoje: trHojeHTML, cards: trCardsHTML, roteiro: trRoteiroHTML, erros: trErrosHTML, provas: trProvasHTML, domingo: trDomingoHTML}[trAba] || trHojeHTML)();
}
// Relógio da sessão: atualiza só o número (não redesenha a tela, para não apagar o que está sendo digitado)
function trTick(){
  const s = D.treino && D.treino.sessao; if(!s || tela !== 'treino') return;
  const el = document.getElementById('tr-relogio'); if(!el) return;
  const r = trRestante();
  el.textContent = trFmt(r); el.classList.toggle('tr-acabou', r < 0);
  if(r <= 0 && s.avisou !== s.i && !s.pausa){
    s.avisou = s.i; save();
    if(NATIVO && Android.vibrate) try{ Android.vibrate(); }catch(e){}
    toast('Tempo do passo. Pode avançar quando terminar a frase.');
  }
}

// ---------- Card no Início ----------
function trBannerHTML(){
  const t = trEstado(), venc = trVencem().length, seq = trSequencia(), feito = trFezHoje(), fase = TR_FASES[t.fase - 1];
  return '<div class="ico" style="background:var(--est-soft);color:var(--est);flex-shrink:0">' + TR_SVG_CEREBRO + '</div>' +
    '<span style="flex:1;min-width:0"><b style="font-size:15px;display:block">' + (t.sessao ? 'Sessão em andamento' : feito ? 'Treino de hoje feito' : 'Treino do cérebro') + '</b>' +
    '<span class="sub">' + (fase ? 'Fase ' + t.fase + ' · ' + esc(trEloAtual()) : 'Manutenção') + ' · sequência ' + seq + ' · ' + venc + ' card(s) hoje</span></span>' +
    '<span class="pill" style="display:flex;align-items:center;flex-shrink:0">' + (t.sessao ? 'Continuar' : feito ? 'Abrir' : 'Começar') + '</span>';
}

// ---------- Lembretes (estende lembretes.js) ----------
function trLembretes(){
  const t = trEstado(), L = [], agora = Date.now(), h = hoje();
  if(typeof lbHora !== 'function') return L;
  const fezEm = new Set(t.sessoes.map(x => x.data));
  for(let i = 0; i < 7; i++){
    const dia = addDias(h, i), dom = parseD(dia).getDay() === 0;
    if(t.cfg.lembrete && !fezEm.has(dia)){
      const q = lbHora(dia, t.cfg.hora), fase = TR_FASES[t.fase - 1];
      const venc = i === 0 ? trVencem().length : t.cards.filter(c => c.vence <= dia).length;
      if(q > agora + 30000) L.push({id: 'treino-' + dia, quando: q, titulo: 'Hora do treino', abrir: 'treino', publico: 'Lembrete de estudo',
        texto: (fase ? 'Fase ' + t.fase + ': ' + fase.foco + '. ' : '') + (venc ? venc + ' card(s) para revisar. ' : '') + 'Sem energia? O modo dia ruim leva 6 min e conta.'});
    }
    if(t.cfg.domingo && dom && !t.domingos[dia]){
      const q = lbHora(dia, t.cfg.domingoHora);
      if(q > agora + 30000) L.push({id: 'treino-dom-' + dia, quando: q, titulo: 'Revisão de domingo', texto: 'Quatro números da semana e um ajuste para a próxima. 2 minutos.', abrir: 'treino-domingo', publico: 'Revisão da semana'});
    }
  }
  return L;
}

// ---------- Integração com o app ----------
(function(){
  trEstado();
  const st = document.createElement('style');
  st.textContent =
    '.tr-col{display:flex;flex-direction:column;gap:10px}' +
    '.tr-trilha{display:flex;gap:6px}.tr-trilha span{flex:1;height:6px;border-radius:3px;background:var(--line)}.tr-trilha span.ok{background:var(--accent);opacity:.5}.tr-trilha span.on{background:var(--accent)}' +
    '.tr-passo .timer{color:inherit;margin:4px 0}.tr-acabou{opacity:.75}' +
    '.tr-carta{font-size:20px;font-weight:700;line-height:1.35;padding:18px 4px;text-align:center;overflow-wrap:anywhere}' +
    '.tr-resp{font-size:17px;line-height:1.45;padding:14px;border-radius:14px;background:var(--accent-soft);text-align:center;overflow-wrap:anywhere}' +
    '.tr-notas{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}.tr-notas .btn{height:auto;min-height:54px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:2px}.tr-notas small{font-size:11px;font-weight:600;opacity:.8}' +
    '.tr-clareza{display:grid;grid-template-columns:repeat(5,1fr);gap:6px}.tr-clareza .btn{padding:0}' +
    '.tr-num{width:24px;height:24px;border-radius:12px;background:var(--accent-soft);color:var(--accent);font-weight:800;font-size:12px;display:flex;align-items:center;justify-content:center;flex-shrink:0}' +
    '.tr-fase.bloq{opacity:.55}.tr-fase.atual{outline:2px solid var(--accent);outline-offset:-2px}' +
    '.tr-elo{font-size:12px;font-weight:800;letter-spacing:1.5px;color:var(--accent)}body.arena .tr-elo{color:var(--gold,#C8AA6E)}' +
    '.tr-medida{font-size:13px;font-weight:700;padding:8px 12px;border-radius:10px;background:var(--line)}.tr-medida.ok{background:var(--accent-soft);color:var(--accent)}' +
    '.tr-ind b{font-size:22px}.tr-ok{color:var(--accent);font-weight:700}' +
    '.tr-cal{display:flex;flex-direction:column;gap:6px;padding-bottom:10px;border-bottom:1px solid var(--line)}.tr-cal:last-child{border-bottom:0;padding-bottom:0}' +
    '.tr-barra{display:grid;grid-template-columns:58px 1fr 30px;align-items:center;gap:8px}.tr-barra b{text-align:right;font-size:14px}' +
    '.tr-aviso{border:0;text-align:left;display:flex;flex-direction:column;gap:4px;outline:2px solid var(--est);outline-offset:-2px}';
  document.head.appendChild(st);

  const sec = document.createElement('section'); sec.className = 'screen'; sec.id = 's-treino';
  document.querySelector('main').appendChild(sec);

  // Atalho em Mais
  const mais = document.getElementById('s-mais');
  const card = document.createElement('button'); card.className = 'card pad'; card.id = 'tr-mais';
  card.style.cssText = 'border:0;text-align:left;display:flex;flex-direction:column;gap:6px;background:var(--est);color:#fff';
  card.innerHTML = '<b style="font-size:17px">Treino do cérebro</b><span style="font-size:14px;opacity:.9">Aprender a aprender: sessão guiada, flashcards e o roteiro de 8 semanas</span>';
  card.onclick = () => go('treino');
  mais.insertBefore(card, mais.children[1] || null);

  // Card no Início (bloco configurável do inicio.js; entra logo depois do "Foco agora")
  const inicio = document.getElementById('s-inicio');
  const ban = document.createElement('button'); ban.id = 'tr-card'; ban.className = 'card pad';
  ban.style.cssText = 'border:0;text-align:left;display:flex;align-items:center;gap:12px;width:100%';
  ban.onclick = () => go('treino');
  inicio.appendChild(ban);
  if(typeof BLOCOS === 'object'){
    BLOCOS['tr-card'] = {nome:'Treino do cérebro', desc:'Sequência, cards de hoje e "Começar sessão"', temas:['classico','arena','hud']};
    if(D.cfg.inicio && Array.isArray(D.cfg.inicio.ordem) && !D.cfg.inicio.ordem.includes('tr-card')){
      const o = D.cfg.inicio.ordem, k = o.indexOf('focus');
      o.splice(k >= 0 ? k + 1 : o.length, 0, 'tr-card'); save();
    }
    if(typeof INICIO_PADRAO === 'object' && !INICIO_PADRAO.ordem.includes('tr-card')){
      const k = INICIO_PADRAO.ordem.indexOf('focus'); INICIO_PADRAO.ordem.splice(k + 1, 0, 'tr-card');
    }
    if(typeof inCfg === 'function') inCfg();
  }

  // Entrada pela seção Aprender
  if(typeof aprRender === 'function'){
    const _ar = aprRender;
    aprRender = function(){
      _ar();
      const el = document.getElementById('s-aprender'); if(!el || document.getElementById('tr-apr')) return;
      const b = document.createElement('button'); b.id = 'tr-apr'; b.className = 'card pad';
      b.style.cssText = 'border:0;text-align:left;display:flex;flex-direction:column;gap:4px;background:var(--est);color:#fff';
      b.innerHTML = '<b style="font-size:16px">Treino: aprender a aprender</b><span style="font-size:14px;opacity:.9">A técnica de estudo vale para qualquer assunto, inclusive IA. Abrir o treino</span>';
      b.onclick = () => go('treino');
      el.insertBefore(b, el.children[2] || null);
    };
  }

  // Lembretes: acrescenta os do treino à lista que vai para o Android
  if(typeof lbLista === 'function'){
    const _ll = lbLista;
    lbLista = function(){
      const base = _ll();
      const c = (D.cfg && D.cfg.lembretes) || {};
      if(c.ativo === false) return base;
      return base.concat(trLembretes()).sort((a, b) => a.quando - b.quando).slice(0, 60);
    };
  }
  // Notificação tocada: o pedido só pode ser lido uma vez, então esta versão substitui a do
  // lembretes.js e repete o tratamento original (mesmas telas) para os outros destinos.
  if(typeof lbAbrirPedido === 'function'){
    lbAbrirPedido = function(){
      if(!NATIVO || !Android.takeOpenRequest) return;
      const a = Android.takeOpenRequest(); if(!a) return;
      if(a === 'treino'){ trAba = 'hoje'; go('treino'); }
      else if(a === 'treino-domingo'){ trAba = 'domingo'; go('treino'); }
      else if(a === 'clientes'){ vista = 'clientes'; go('tarefas'); }
      else if(a === 'fechar'){ go('inicio'); openSheet('hud-fechar'); }
      else if(['inicio', 'financas', 'tarefas', 'noticias', 'mais'].includes(a)) go(a);
    };
  }

  const _r = render;
  render = function(){
    _r();
    const b = document.getElementById('tr-card'); if(b) b.innerHTML = trBannerHTML();
    if(typeof inAplicar === 'function') inAplicar();
  };
  const _go = go;
  go = function(t){ _go(t); if(t === 'treino') trRender(); };
  setInterval(trTick, 1000);
  render();
})();
