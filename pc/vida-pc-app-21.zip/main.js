// Vida para PC (Windows). Casca Electron que roda o MESMO app do celular (pasta conteudo/) e oferece
// a mesma ponte window.Android (preload.js), com equivalentes do PC:
//  rede (só as APIs permitidas), feeds de notícias, cofre (DPAPI do Windows via safeStorage),
//  cópia dos dados em arquivo, backup em Documentos\Vida, lembretes como notificações do Windows
//  (o programa fica ao lado do relógio), atualização do conteúdo pelo GitHub com ASSINATURA conferida.
'use strict';
const { app, BrowserWindow, ipcMain, net, shell, clipboard, safeStorage, Notification, Tray, Menu, dialog, nativeImage, powerMonitor } = require('electron');
const fs = require('fs'), path = require('path'), crypto = require('crypto');

const CASCA = 1;   // versão da casca (o .exe). Conteúdo novo pode exigir casca nova (latest.json: pc.casca).
const RELEASES = 'https://raw.githubusercontent.com/davidcardozowow-cmd/vida-app-releases/main/';
const API_LATEST = 'https://api.github.com/repos/davidcardozowow-cmd/vida-app-releases/contents/latest.json?ref=main';
// Chave pública que assina o conteúdo publicado. A privada fica só no ambiente de build (igual à chave do APK).
const CHAVE_PUBLICA = fs.readFileSync(path.join(__dirname, 'recursos', 'conteudo.pub'), 'utf8');
const APIS = ['https://api.pluggy.ai/', 'https://api.groq.com/', 'https://generativelanguage.googleapis.com/', 'https://api.github.com/repos/'];
const OCULTO = process.argv.includes('--oculto');

if (!app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }
app.setAppUserModelId('com.david.vida');
const DIR = app.getPath('userData');
const arq = n => path.join(DIR, n);
const lerJson = (p, pad) => { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch (e) { return pad; } };
function gravar(p, txt) { const tmp = p + '.tmp'; fs.writeFileSync(tmp, txt); fs.renameSync(tmp, p); }

let win = null, tray = null, saindo = false, abrirPedido = '';
let cfg = lerJson(arq('pc.json'), {});
const salvarCfg = () => gravar(arq('pc.json'), JSON.stringify(cfg, null, 1));

// ---------- Conteúdo (o app em si): o embutido ou o atualizado mais novo ----------
const EMBUTIDO = path.join(__dirname, 'conteudo');
const versaoDe = pasta => lerJson(path.join(pasta, 'versao.json'), {versionCode: 0, versionName: '?'});
function pastaConteudo() {
  const a = lerJson(arq('conteudo-atual.json'), null);
  if (a && a.pasta && fs.existsSync(path.join(DIR, a.pasta, 'index.html')) && versaoDe(path.join(DIR, a.pasta)).versionCode > versaoDe(EMBUTIDO).versionCode)
    return path.join(DIR, a.pasta);
  return EMBUTIDO;
}

// ---------- Janela ----------
function criarJanela() {
  const j = cfg.janela || {};
  win = new BrowserWindow({
    width: j.w || 1100, height: j.h || 820, x: j.x, y: j.y, minWidth: 380, minHeight: 560,
    backgroundColor: '#0B0F14', title: 'Vida', show: false, autoHideMenuBar: true,
    icon: path.join(__dirname, 'recursos', 'icone.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, spellcheck: true }
  });
  win.setMenu(null);
  if (j.max) win.maximize();
  win.loadFile(path.join(pastaConteudo(), 'index.html'));
  win.once('ready-to-show', () => { if (!OCULTO) win.show(); });
  // Nunca navega para fora do app; links abrem no navegador
  win.webContents.on('will-navigate', (e, url) => { if (!url.startsWith('file://')) { e.preventDefault(); abrirFora(url); } });
  win.webContents.setWindowOpenHandler(({ url }) => { abrirFora(url); return { action: 'deny' }; });
  const lembrarJanela = () => { if (!win || win.isMinimized()) return; const b = win.getNormalBounds(); cfg.janela = { x: b.x, y: b.y, w: b.width, h: b.height, max: win.isMaximized() }; salvarCfg(); };
  win.on('resize', lembrarJanela); win.on('move', lembrarJanela);
  // Fechar = continua ao lado do relógio (para os lembretes). Sair pelo menu do ícone.
  win.on('close', e => {
    if (saindo) return;
    e.preventDefault(); win.hide();
    if (!cfg.avisouBandeja) { cfg.avisouBandeja = true; salvarCfg(); notificar('Vida continua aberto', 'Fica ao lado do relógio para te lembrar das coisas. Para sair de vez: botão direito no ícone → Sair.'); }
  });
  let ultimoFoco = 0;
  win.on('focus', () => { if (Date.now() - ultimoFoco > 30000) { ultimoFoco = Date.now(); js('window.appResume && window.appResume()'); } });
}
function mostrar() { if (!win) criarJanela(); if (win.isMinimized()) win.restore(); win.show(); win.focus(); }
function js(code) { if (win && !win.isDestroyed()) win.webContents.executeJavaScript(code, true).catch(() => {}); }
function cb(fn, ...args) { js('window.' + fn + ' && window.' + fn + '(' + args.map(a => JSON.stringify(a)).join(',') + ')'); }
function abrirFora(url) { if (/^https:\/\//.test(String(url))) shell.openExternal(url); }

// ---------- Bandeja e iniciar com o Windows ----------
function criarBandeja() {
  tray = new Tray(nativeImage.createFromPath(path.join(__dirname, 'recursos', 'bandeja.png')));
  tray.setToolTip('Vida');
  const menu = () => Menu.buildFromTemplate([
    { label: 'Abrir o Vida', click: mostrar },
    { label: 'Abrir junto com o Windows', type: 'checkbox', checked: cfg.iniciar !== false, click: i => { cfg.iniciar = i.checked; salvarCfg(); iniciarComWindows(); } },
    { type: 'separator' },
    { label: 'Sair', click: () => { saindo = true; app.quit(); } }
  ]);
  tray.setContextMenu(menu());
  tray.on('click', mostrar);
}
function iniciarComWindows() {
  if (process.platform !== 'win32' || !app.isPackaged) return;
  app.setLoginItemSettings({ openAtLogin: cfg.iniciar !== false, args: ['--oculto'] });
}

// ---------- Notificações e lembretes ----------
function notificar(titulo, texto, abrir) {
  if (!Notification.isSupported()) return;
  const n = new Notification({ title: titulo, body: texto, icon: path.join(__dirname, 'recursos', 'icone.png') });
  n.on('click', () => { mostrar(); if (abrir) { abrirPedido = abrir; js('window.lbAbrirPedido && window.lbAbrirPedido()'); } });
  n.show();
}
let timers = [];
function agendarLembretes() {
  timers.forEach(clearTimeout); timers = [];
  const lista = lerJson(arq('lembretes.json'), []), agora = Date.now();
  let ultimo = cfg.ultimoLembrete || 0;
  lista.forEach(o => {
    const q = Number(o.quando) || 0;
    if (q > ultimo && q <= agora && agora - q < 60 * 60000) disparar(o);          // perdeu há menos de 1 h (PC estava dormindo)
    else if (q > agora && q - agora < 8 * 864e5) timers.push(setTimeout(() => disparar(o), q - agora));
  });
}
function disparar(o) {
  cfg.ultimoLembrete = Math.max(cfg.ultimoLembrete || 0, Number(o.quando) || 0); salvarCfg();
  notificar(o.titulo || 'Vida', o.texto || o.publico || 'Você tem um lembrete', o.abrir || 'inicio');
}

// ---------- Ponte: chamadas do app ----------
ipcMain.on('sync', (e, nome, ...a) => {
  try {
    switch (nome) {
      case 'secureGet': { const c = lerJson(arq('cofre.json'), {}); const v = c[a[0]]; if (!v) return (e.returnValue = '');
        e.returnValue = v.p ? v.v : safeStorage.decryptString(Buffer.from(v.v, 'base64')); return; }
      case 'secureSet': { const c = lerJson(arq('cofre.json'), {});
        if (!a[1]) delete c[a[0]];
        else if (safeStorage.isEncryptionAvailable()) c[a[0]] = { v: safeStorage.encryptString(String(a[1])).toString('base64') };
        else c[a[0]] = { p: 1, v: String(a[1]) };   // só em ambiente de teste (Linux sem chaveiro)
        gravar(arq('cofre.json'), JSON.stringify(c)); e.returnValue = true; return; }
      case 'loadPersisted': { e.returnValue = fs.existsSync(arq('dados.json')) ? fs.readFileSync(arq('dados.json'), 'utf8') : ''; return; }
      case 'appVersion': { e.returnValue = versaoDe(pastaConteudo()).versionName + ' (PC)'; return; }
      case 'takeOpenRequest': { e.returnValue = abrirPedido; abrirPedido = ''; return; }
      case 'saveBackup': { e.returnValue = salvarBackup(a[0], a[1]); return; }
    }
    e.returnValue = '';
  } catch (err) { e.returnValue = nome === 'saveBackup' ? 'erro:' + err.message : ''; }
});
ipcMain.on('async', async (e, nome, ...a) => {
  try {
    switch (nome) {
      case 'http': return http(...a);
      case 'fetchText': return fetchText(...a);
      case 'persist': return gravar(arq('dados.json'), String(a[0]));
      case 'openUrl': return abrirFora(a[0]);
      case 'copy': return clipboard.writeText(String(a[0] || ''));
      case 'setReminders': gravar(arq('lembretes.json'), String(a[0] || '[]')); return agendarLembretes();
      case 'pickFile': {
        const r = await dialog.showOpenDialog(win, { title: 'Restaurar backup do Vida', defaultPath: pastaBackup(), filters: [{ name: 'Backup do Vida', extensions: ['json'] }], properties: ['openFile'] });
        if (!r.canceled && r.filePaths[0]) cb('__arquivoCb', fs.readFileSync(r.filePaths[0], 'utf8').slice(0, 30e6));
        return;
      }
      case 'checkUpdate': return verificarAtualizacao(a[0]);
      case 'installUpdate': return instalarAtualizacao();
    }
  } catch (err) { console.error(nome, err); }
});

async function http(id, metodo, url, cabJson, corpo) {
  let status = 0, texto;
  try {
    if (!APIS.some(p => String(url).startsWith(p))) throw new Error('URL não permitida');
    const cab = Object.assign({ 'Accept': 'application/json', 'User-Agent': 'Vida-PC' }, JSON.parse(cabJson || '{}'));
    const op = { method: metodo, headers: cab, signal: AbortSignal.timeout(60000) };
    if (corpo) { op.body = corpo; cab['Content-Type'] = 'application/json'; }
    const r = await net.fetch(url, op);
    status = r.status; texto = await r.text();
  } catch (err) { texto = JSON.stringify({ erroApp: String(err.message || err) }); }
  cb('__httpCb', id, status, texto);
}
async function fetchText(id, url) {
  let status = 0, texto = '';
  try {
    if (!/^https:\/\//.test(String(url))) throw new Error('Só https');
    const r = await net.fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140 Safari/537.36',
      'Accept': 'application/rss+xml, application/atom+xml, application/xml;q=0.9, text/xml;q=0.9, */*;q=0.5' }, signal: AbortSignal.timeout(20000) });
    status = r.status;
    let buf = Buffer.from(await r.arrayBuffer()); if (buf.length > 3e6) buf = buf.subarray(0, 3e6);
    const cs = ((r.headers.get('content-type') || '').match(/charset=([\w-]+)/i) || buf.subarray(0, 300).toString('latin1').match(/encoding=["']([\w-]+)/i) || [])[1] || 'utf-8';
    try { texto = new TextDecoder(cs.toLowerCase()).decode(buf); } catch (e2) { texto = buf.toString('utf8'); }
  } catch (err) { texto = ''; }
  cb('__httpCb', id, status, texto);
}

// ---------- Backup em Documentos\Vida (guarda os 4 mais novos) ----------
const pastaBackup = () => path.join(app.getPath('documents'), 'Vida');
function salvarBackup(nome, conteudo) {
  if (!/^Vida-backup-[\d-]+\.json$/.test(nome)) return 'erro:nome';
  const p = pastaBackup(); fs.mkdirSync(p, { recursive: true });
  gravar(path.join(p, nome), conteudo);
  fs.readdirSync(p).filter(f => /^Vida-backup-.*\.json$/.test(f)).sort().reverse().slice(4).forEach(f => { try { fs.unlinkSync(path.join(p, f)); } catch (e) {} });
  return 'ok:Documentos\\Vida';
}

// ---------- Atualização do conteúdo (assinado) ----------
let ultimaInfo = null;
async function baixar(url, max) {
  const r = await net.fetch(url, { headers: { 'Accept': 'application/vnd.github.raw', 'User-Agent': 'Vida-PC' }, signal: AbortSignal.timeout(120000) });
  if (!r.ok) throw new Error('HTTP ' + r.status);
  const b = Buffer.from(await r.arrayBuffer()); if (b.length > max) throw new Error('grande demais'); return b;
}
async function verificarAtualizacao(id) {
  let r = {};
  try {
    let txt; try { txt = (await baixar(API_LATEST, 200000)).toString('utf8'); } catch (e) { txt = (await baixar(RELEASES + 'latest.json?t=' + Date.now(), 200000)).toString('utf8'); }
    const j = JSON.parse(txt), pc = j.pc || {};
    ultimaInfo = pc;
    r = { tem: (pc.versionCode || 0) > versaoDe(pastaConteudo()).versionCode, versionName: pc.versionName || j.versionName, notas: (pc.casca > CASCA ? 'Precisa baixar o Vida para PC de novo (vou abrir a página). ' : '') + (j.notas || '') };
  } catch (e) { r = { erro: 'Não consegui verificar agora. Confira a internet.' }; }
  cb('__updCheck', id, JSON.stringify(r));
}
async function instalarAtualizacao() {
  try {
    const pc = ultimaInfo; if (!pc || !pc.conteudo) throw new Error('Procure a atualização primeiro');
    if (pc.casca > CASCA) { abrirFora(pc.pagina || 'https://github.com/davidcardozowow-cmd/vida-app-releases/releases/latest'); cb('__updCb', 'nada', 'Baixe e extraia o novo Vida para PC; seus dados continuam.'); return; }
    cb('__updCb', 'baixando', 'Baixando...');
    const b = await baixar(RELEASES + pc.conteudo + '?t=' + Date.now(), 40e6);
    if (crypto.createHash('sha256').update(b).digest('hex') !== pc.sha256) throw new Error('arquivo diferente do publicado');
    const pacote = JSON.parse(b.toString('utf8'));
    const assinado = Buffer.from(JSON.stringify({ versionCode: pacote.versionCode, versionName: pacote.versionName, arquivos: pacote.arquivos }));
    if (!crypto.verify(null, assinado, CHAVE_PUBLICA, Buffer.from(pacote.assinatura || '', 'base64'))) throw new Error('assinatura inválida');
    cb('__updCb', 'instalando', 'Instalando...');
    const pasta = 'conteudo-' + pacote.versionCode, dest = path.join(DIR, pasta);
    fs.rmSync(dest, { recursive: true, force: true });
    for (const [rel, b64] of Object.entries(pacote.arquivos)) {
      const alvo = path.resolve(dest, rel);
      if (!alvo.startsWith(dest + path.sep)) throw new Error('caminho inválido');
      fs.mkdirSync(path.dirname(alvo), { recursive: true });
      fs.writeFileSync(alvo, Buffer.from(b64, 'base64'));
    }
    fs.writeFileSync(path.join(dest, 'versao.json'), JSON.stringify({ versionCode: pacote.versionCode, versionName: pacote.versionName }));
    const antiga = lerJson(arq('conteudo-atual.json'), null);
    gravar(arq('conteudo-atual.json'), JSON.stringify({ pasta }));
    if (antiga && antiga.pasta && antiga.pasta !== pasta) fs.rmSync(path.join(DIR, antiga.pasta), { recursive: true, force: true });
    cb('__updCb', 'ok', 'Atualizado para ' + pacote.versionName);
    setTimeout(() => { if (win) win.loadFile(path.join(pastaConteudo(), 'index.html')); }, 900);
  } catch (e) { cb('__updCb', 'erro', 'Não deu para atualizar: ' + e.message); }
}

// ---------- Início ----------
app.on('second-instance', mostrar);
app.whenReady().then(() => {
  criarJanela(); criarBandeja(); iniciarComWindows(); agendarLembretes();
  powerMonitor.on('resume', () => { agendarLembretes(); js('window.appResume && window.appResume()'); });
  setInterval(agendarLembretes, 6 * 3600e3);
});
app.on('before-quit', () => { saindo = true; });
app.on('window-all-closed', () => { /* continua na bandeja */ });
