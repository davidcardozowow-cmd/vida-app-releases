// =====================================================================
// Evolução v3.0 (vale para todos os visuais), a partir da pesquisa de referências:
// 1. "O dia em pontos": cada ponto = 15 min do dia útil; os que passaram apagam (cegueira temporal).
// 2. Tempo estimado por tarefa + "o dia cabe?" (soma das tarefas de hoje × tempo que resta).
// 3. Contagem regressiva do foco visível no Início enquanto o timer corre (ponto de execução).
// 4. Plano de ataque de dívidas: avalanche × bola de neve, calculado só no celular (nunca vai para IA).
// Depende de: D, save, render, esc, toast, hoje, addDias, pad2, brl, lerValor, uid, val, openSheet,
//             closeSheet, formHTML, salvarTarefa, itemTarefa, foco, paraHoje, T, restoMs (index.html).
// =====================================================================

const MIN_OPCOES = [0, 5, 15, 30, 45, 60, 90, 120, 180];
function evCfg(){
  D.cfg.dia = Object.assign({ini:'07:00', fim:'22:00'}, D.cfg.dia || {});
  if(!Array.isArray(D.dividas)) D.dividas = [];
  return D.cfg.dia;
}
const hm = s => { const [h, m] = String(s || '0:0').split(':').map(Number); return (h || 0) * 60 + (m || 0); };
function fmtMin(m){ m = Math.max(0, Math.round(m)); const h = Math.floor(m / 60), r = m % 60; return h ? h + 'h' + (r ? pad2(r) : '') : r + ' min'; }

// ---------- 1 e 2. Dia em pontos + o dia cabe? ----------
function diaEstado(){
  const c = evCfg(), a = new Date(), agora = a.getHours() * 60 + a.getMinutes();
  let ini = hm(c.ini), fim = hm(c.fim); if(fim <= ini) fim = ini + 60;
  const total = Math.ceil((fim - ini) / 15);
  const passados = Math.max(0, Math.min(total, Math.floor((agora - ini) / 15)));
  const resta = Math.max(0, fim - Math.max(agora, ini));
  const tarefas = paraHoje().reduce((s, t) => s + (t.min || 0), 0);
  const semEst = paraHoje().filter(t => !t.min).length;
  return {total, passados, resta, tarefas, semEst, antes: agora < ini, depois: agora >= fim, c};
}
function diaPontosHTML(){
  const e = diaEstado();
  let dots = '';
  for(let i = 0; i < e.total; i++) dots += '<i class="' + (i < e.passados ? 'p' : i === e.passados && !e.antes && !e.depois ? 'a' : '') + '"></i>' + (i % 4 === 3 ? '<b></b>' : '');
  let linha;
  if(e.depois) linha = 'Dia útil encerrado. Descanse.';
  else if(e.antes) linha = 'O dia útil começa às ' + e.c.ini + '.';
  else linha = 'Faltam <b>' + fmtMin(e.resta) + '</b> de dia útil';
  let cabe = '';
  if(e.tarefas && !e.depois){
    const ok = e.tarefas <= e.resta;
    cabe = '<span class="dp-cabe ' + (ok ? 'ok' : 'nao') + '">Tarefas de hoje: ' + fmtMin(e.tarefas) + (ok ? ' · cabe' : ' · não cabe, adie algo') + '</span>';
  } else if(e.semEst && !e.depois) cabe = '<span class="dp-cabe">Dica: diga quanto tempo cada tarefa leva para ver se o dia cabe.</span>';
  return '<div class="between" style="align-items:baseline"><span class="dp-t">' + linha + '</span><button class="dp-cfg" onclick="openSheet(\'dia-cfg\')">' + e.c.ini + '–' + e.c.fim + '</button></div>' +
    '<div class="dp-grade">' + dots + '</div>' + cabe;
}
function diaRender(){ const el = document.getElementById('dia-pontos'); if(el) el.innerHTML = diaPontosHTML(); }
function salvarDiaCfg(){
  const ini = val('f-ini'), fim = val('f-fim');
  if(!ini || !fim || hm(fim) <= hm(ini)){ toast('O fim precisa ser depois do início'); return; }
  D.cfg.dia = {ini, fim}; save(); closeSheet(); render(); toast('Dia útil: ' + ini + ' às ' + fim);
}

// ---------- 3. Contagem do foco no Início ----------
function focoContagem(){
  const fe = document.getElementById('focus'); if(!fe) return;
  let el = document.getElementById('foco-cont');
  const f = foco(), rodando = T.fim || T.resto != null;
  if(!f || !rodando || (T.tarefa && T.tarefa !== f.id)){ if(el) el.remove(); return; }
  if(!el){ el = document.createElement('button'); el.id = 'foco-cont'; el.className = 'foco-cont'; el.onclick = () => openSheet('foco', f.id); }
  const alvo = fe.querySelector('.arena-in') || fe;
  if(el.parentNode !== alvo) alvo.insertBefore(el, alvo.children[2] || null);
  const ms = restoMs(), s = Math.ceil(ms / 1000), pct = Math.max(0, Math.min(100, ms / (T.min * 60000) * 100));
  el.innerHTML = '<span>' + (T.fim ? 'Foco rodando' : 'Foco pausado') + ' · <b>' + pad2(Math.floor(s / 60)) + ':' + pad2(s % 60) + '</b></span><span class="fc-bar"><span style="width:' + pct.toFixed(1) + '%"></span></span>';
}
setInterval(focoContagem, 1000);

// ---------- 4. Plano de ataque de dívidas ----------
// Simula mês a mês: juros entram, todas recebem o mínimo, o "extra" (e os mínimos de quem já quitou)
// vão para a dívida-alvo. Avalanche = maior juro primeiro; bola de neve = menor saldo primeiro.
function simularDividas(estrategia, extra){
  let ds = D.dividas.filter(d => d.saldo > 0).map(d => ({id:d.id, nome:d.nome, s:d.saldo, j:(d.juros || 0) / 100, m:d.minimo || 0}));
  if(!ds.length) return null;
  const ordem = estrategia === 'avalanche' ? (a, b) => b.j - a.j || a.s - b.s : (a, b) => a.s - b.s || b.j - a.j;
  const quitacao = {}; let mes = 0, juros = 0;
  const orcamento = ds.reduce((s, d) => s + d.m, 0) + (extra || 0);
  while(ds.length && mes < 600){
    mes++;
    ds.forEach(d => { const ju = d.s * d.j; d.s += ju; juros += ju; });
    let livre = orcamento;
    ds.forEach(d => { const p = Math.min(d.m, d.s); d.s -= p; livre -= p; });
    ds.sort(ordem);
    for(const d of ds){ if(livre <= 0) break; const p = Math.min(livre, d.s); d.s -= p; livre -= p; }
    ds = ds.filter(d => { if(d.s <= 0.005){ quitacao[d.id] = mes; return false; } return true; });
  }
  return {meses: ds.length ? null : mes, juros, quitacao, ordem: D.dividas.filter(d => d.saldo > 0).slice().sort((a, b) => (quitacao[a.id] || 9999) - (quitacao[b.id] || 9999))};
}
function mesesTxt(n){ if(n == null) return 'nunca (o pagamento não cobre os juros)'; const a = Math.floor(n / 12), m = n % 12; return (a ? a + (a > 1 ? ' anos' : ' ano') : '') + (a && m ? ' e ' : '') + (m ? m + (m > 1 ? ' meses' : ' mês') : ''); }
function dataQuitacao(n){ if(n == null) return '—'; const d = new Date(); d.setMonth(d.getMonth() + n); return MESES[d.getMonth()] + ' de ' + d.getFullYear(); }
function dividasHTML(){
  evCfg();
  const extra = D.cfg.extraDivida || 0;
  let h = '<div class="between" style="align-items:center"><h2>Plano para quitar dívidas</h2><button class="pill" onclick="openSheet(\'divida\')">+ Dívida</button></div>';
  if(!D.dividas.length) return h + '<p class="note" style="margin:0">Cadastre suas dívidas (cartão, empréstimo, parcelamento) com saldo, juros ao mês e parcela mínima. O app calcula a ordem que te livra mais rápido e quanto de juros você economiza. Tudo calculado aqui no celular.</p>';
  const ruins = D.dividas.filter(d => d.saldo > 0 && d.minimo <= d.saldo * (d.juros || 0) / 100);
  const av = simularDividas('avalanche', extra), bn = simularDividas('bola', extra);
  const melhor = !av || !bn ? av || bn : (av.juros <= bn.juros ? av : bn);
  const nomeMelhor = melhor === av ? 'Avalanche (maior juro primeiro)' : 'Bola de neve (menor saldo primeiro)';
  const total = D.dividas.reduce((s, d) => s + (d.saldo || 0), 0);
  h += '<div class="between"><span class="sub">Total devido</span><b class="money">' + brl(total) + '</b></div>' +
    '<div class="card" style="padding:4px 14px">' + D.dividas.map(d =>
      '<div class="item"><div class="txt" onclick="openSheet(\'divida\',\'' + d.id + '\')">' + esc(d.nome) + '<small>' + brl(d.saldo) + ' · ' + String(d.juros || 0).replace('.', ',') + '% ao mês · mínimo ' + brl(d.minimo || 0) + '</small></div></div>').join('') + '</div>' +
    '<label class="f">Quanto a mais você consegue pagar por mês, além dos mínimos? (R$)<input id="f-extra" inputmode="decimal" value="' + (extra ? String(extra).replace('.', ',') : '') + '" placeholder="0,00" onchange="D.cfg.extraDivida=lerValor(this.value)||0;save();render()"></label>';
  if(ruins.length) h += '<p class="note" style="margin:0;color:var(--danger)">Atenção: em ' + ruins.map(d => esc(d.nome)).join(', ') + ' o mínimo não cobre os juros do mês. A dívida cresce mesmo pagando. Priorize essa ou renegocie.</p>';
  if(melhor){
    h += '<div class="dv-res"><span class="sub">Melhor estratégia</span><b>' + nomeMelhor + '</b>' +
      '<span>Livre de dívidas em <b>' + mesesTxt(melhor.meses) + '</b>' + (melhor.meses ? ' (' + dataQuitacao(melhor.meses) + ')' : '') + '</span>' +
      '<span>Juros totais: <b>' + brl(melhor.juros) + '</b>' + (av && bn && Math.abs(av.juros - bn.juros) > 1 ? ' · economiza ' + brl(Math.abs(av.juros - bn.juros)) + ' em relação à outra' : '') + '</span>' +
      '<span class="sub" style="margin-top:4px">Ordem de ataque:</span>' +
      melhor.ordem.map((d, i) => '<span>' + (i + 1) + '. ' + esc(d.nome) + ' · quitada em ' + dataQuitacao(melhor.quitacao[d.id]) + '</span>').join('') + '</div>' +
      '<p class="note" style="margin:0">Pague o mínimo de todas e jogue todo o extra na primeira da lista. Quando ela acabar, o valor que ia para ela passa para a próxima. Isto é uma simulação, não uma recomendação financeira: confira juros e saldos no contrato.</p>';
  }
  return h;
}
function salvarDivida(){
  const nome = (val('f-desc') || '').trim(), saldo = lerValor(val('f-valor')), juros = lerValor(val('f-juros')), minimo = lerValor(val('f-min'));
  if(!nome){ toast('Dê um nome à dívida'); return; }
  if(!(saldo > 0)){ toast('Informe o saldo devedor'); return; }
  if(!(minimo > 0)){ toast('Informe a parcela mínima'); return; }
  const d = {nome, saldo, juros: isFinite(juros) ? juros : 0, minimo};
  if(sheetId){ Object.assign(D.dividas.find(x => x.id === sheetId), d); } else D.dividas.push(Object.assign({id: uid()}, d));
  save(); closeSheet(); render(); toast('Dívida salva');
}
function excluirDivida(id){ if(!confirm('Excluir esta dívida do plano?')) return; D.dividas = D.dividas.filter(x => x.id !== id); save(); closeSheet(); render(); }


// ---------- 5. Widget da tela inicial (próxima ação + microfone) ----------
let widgetUltimo = '';
function widgetAtualizar(){
  if(!NATIVO || !Android.setWidget) return;
  const f = foco(), h = hoje();
  const feitas = D.tarefas.filter(t => t.feita && t.feitaEm === h).length, total = feitas + paraHoje().length;
  const titulo = f ? (proxPasso(f) ? proxPasso(f).t : f.titulo) : 'Nada pendente agora';
  const partes = [];
  if(f && proxPasso(f)) partes.push(f.titulo);
  if(total) partes.push('Hoje ' + feitas + '/' + total);
  const c = contasAbertas().find(x => x.venc <= addDias(h, 2)); if(c) partes.push(c.desc + ' ' + quando(c.venc).toLowerCase());
  if(typeof vdParaHoje === 'function' && vdParaHoje().length) partes.push(vdParaHoje().length + ' cliente(s) hoje');
  const sub = partes.join(' · ');
  if(titulo + '|' + sub === widgetUltimo) return;
  widgetUltimo = titulo + '|' + sub;
  try { Android.setWidget(titulo, sub); } catch(e){}
}
function vozDoWidget(){
  if(NATIVO && Android.takeVoiceRequest && Android.takeVoiceRequest() && Android.listen) Android.listen('Fale o comando');
}

// ---------- Integração ----------
(function(){
  evCfg();
  // Dia em pontos: logo acima do foco
  const fe = document.getElementById('focus');
  const dp = document.createElement('div'); dp.id = 'dia-pontos'; dp.className = 'dia-pontos';
  fe.insertAdjacentElement('beforebegin', dp);
  // Dívidas: em Finanças, antes da meta
  const meta = document.getElementById('meta-card');
  const dv = document.createElement('div'); dv.id = 'dividas-card'; dv.className = 'card pad';
  dv.style.cssText = 'display:flex;flex-direction:column;gap:12px';
  meta.insertAdjacentElement('beforebegin', dv);

  const _f = formHTML;
  formHTML = function(tipo, id){
    if(tipo === 'dia-cfg') return '<h2>Seu dia útil</h2><p class="note" style="margin:0">Os pontos mostram este intervalo. Cada ponto vale 15 minutos e apaga quando o tempo passa.</p>' +
      '<div class="row"><label class="f" style="flex:1">Começa<input type="time" id="f-ini" value="' + evCfg().ini + '"></label><label class="f" style="flex:1">Termina<input type="time" id="f-fim" value="' + evCfg().fim + '"></label></div>' +
      '<button class="btn primary full" onclick="salvarDiaCfg()">Salvar</button>';
    if(tipo === 'divida'){
      const d = id ? D.dividas.find(x => x.id === id) : null, num = v => v ? String(v).replace('.', ',') : '';
      return '<h2>' + (d ? 'Editar dívida' : 'Nova dívida') + '</h2>' +
        '<label class="f">Nome<input id="f-desc" value="' + (d ? esc(d.nome) : '') + '" placeholder="Ex.: cartão Nubank, empréstimo"></label>' +
        '<label class="f">Saldo devedor hoje (R$)<input id="f-valor" inputmode="decimal" value="' + num(d && d.saldo) + '" placeholder="0,00"></label>' +
        '<label class="f">Juros ao mês (%)<input id="f-juros" inputmode="decimal" value="' + num(d && d.juros) + '" placeholder="Ex.: 12,5 (veja no app do banco ou contrato)"></label>' +
        '<label class="f">Parcela mínima por mês (R$)<input id="f-min" inputmode="decimal" value="' + num(d && d.minimo) + '" placeholder="0,00"></label>' +
        '<button class="btn primary full" onclick="salvarDivida()">Salvar</button>' +
        (d ? '<button class="btn danger full" onclick="excluirDivida(\'' + d.id + '\')">Excluir</button>' : '');
    }
    let h = _f(tipo, id);
    if(tipo === 'tarefa'){
      const t = id ? D.tarefas.find(x => x.id === id) : null, atual = t && t.min || 0;
      const sel = '<label class="f">Quanto tempo leva?<select id="f-min">' + MIN_OPCOES.map(m => '<option value="' + m + '"' + (m === atual ? ' selected' : '') + '>' + (m ? fmtMin(m) : 'Não sei / sem estimativa') + '</option>').join('') + '</select></label>';
      h = h.replace('<label class="f">Quando', sel + '<label class="f">Quando');
    }
    return h;
  };
  const _salvar = salvarTarefa;
  salvarTarefa = function(){
    const editando = sheetId, n = D.tarefas.length, min = parseInt(val('f-min'), 10) || 0;
    _salvar();
    const t = editando ? D.tarefas.find(x => x.id === editando) : (D.tarefas.length > n ? D.tarefas[D.tarefas.length - 1] : null);
    if(t){ if(min) t.min = min; else delete t.min; save(); render(); }
  };
  const _item = itemTarefa;
  itemTarefa = function(t){ const h = _item(t); return t.min && !t.feita ? h.replace('</small>', ' · ' + fmtMin(t.min) + '</small>') : h; };

  const _r = render;
  render = function(){ _r(); diaRender(); focoContagem(); const c = document.getElementById('dividas-card'); if(c) c.innerHTML = dividasHTML(); clearTimeout(render._w); render._w = setTimeout(widgetAtualizar, 400); };
  const _res = window.appResume;
  window.appResume = function(){ if(_res) _res(); vozDoWidget(); widgetAtualizar(); };
  setTimeout(vozDoWidget, 900);
  setInterval(() => { if(tela === 'inicio') diaRender(); }, 60000);
  render();
})();
