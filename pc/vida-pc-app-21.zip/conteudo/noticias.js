// =====================================================================
// Notícias (v2.8): feed estilo Instagram com política do Brasil, mundo/
// geopolítica, Jornal Nacional e "Em alta" (Google Trends Brasil + atalho
// para o assunto no X). Atualiza a cada 15 min com o app aberto e sempre que
// ele volta para a tela. Notícias em outro idioma são traduzidas pela IA grátis
// (só manchete e resumo públicos — nenhum dado pessoal vai junto).
// Segurança: o conteúdo dos feeds é sempre tratado como TEXTO (esc), links e
// imagens só https. Cache fora de D (não entra no backup): localStorage 'vida.noticias'.
// Depende de: D, save, toast, esc, go, tela, NATIVO, _cbs, uid, openSheet, closeSheet,
//             formHTML, iaPronta, iaPedir, iaJSON (index.html / ia.js).
// =====================================================================

const NT_INTERVALO = 15 * 60 * 1000;
const NT_JANELA = 36 * 3600 * 1000;      // mostra as últimas 36 h
const NT_GUARDA = 48 * 3600 * 1000;      // guarda 48 h no cache
const NT_TRENDS = 'https://trends.google.com/trending/rss?geo=BR';
const NT_CATS = [
  {id:'tudo',   nome:'Tudo'},
  {id:'brasil', nome:'Brasil'},
  {id:'mundo',  nome:'Mundo'},
  {id:'jn',     nome:'JN'},
  {id:'alta',   nome:'Em alta'}
];
// Fontes com linhas editoriais diferentes, para não virar bolha. Dá para ligar/desligar e adicionar outras.
const NT_FONTES = [
  {id:'g1pol',   nome:'g1 Política',        sigla:'g1', cor:'#C4170C', cat:'brasil', lang:'pt', url:'https://g1.globo.com/rss/g1/politica/'},
  {id:'jn',      nome:'Jornal Nacional',    sigla:'JN', cor:'#0A3A7A', cat:'jn',     lang:'pt', url:'https://g1.globo.com/rss/g1/jornal-nacional/'},
  {id:'folha',   nome:'Folha · Poder',      sigla:'F',  cor:'#1A1A1A', cat:'brasil', lang:'pt', url:'https://feeds.folha.uol.com.br/poder/rss091.xml'},
  {id:'estadao', nome:'Estadão Política',   sigla:'E',  cor:'#2F3A46', cat:'brasil', lang:'pt', url:'https://www.estadao.com.br/arc/outboundfeeds/feeds/rss/sections/politica/'},
  {id:'poder360',nome:'Poder360',           sigla:'P3', cor:'#B8860B', cat:'brasil', lang:'pt', url:'https://www.poder360.com.br/feed/'},
  {id:'cnnbr',   nome:'CNN Brasil Política',sigla:'CNN',cor:'#CC0000', cat:'brasil', lang:'pt', url:'https://www.cnnbrasil.com.br/politica/feed/'},
  {id:'agbr',    nome:'Agência Brasil',     sigla:'AB', cor:'#00703C', cat:'brasil', lang:'pt', url:'https://agenciabrasil.ebc.com.br/rss/politica/feed.xml'},
  {id:'gazeta',  nome:'Gazeta do Povo',     sigla:'GP', cor:'#0B5394', cat:'brasil', lang:'pt', url:'https://www.gazetadopovo.com.br/feed/rss/republica.xml'},
  {id:'carta',   nome:'CartaCapital',       sigla:'CC', cor:'#D52B1E', cat:'brasil', lang:'pt', url:'https://www.cartacapital.com.br/politica/feed/'},
  {id:'metro',   nome:'Metrópoles',         sigla:'M',  cor:'#E4002B', cat:'brasil', lang:'pt', url:'https://www.metropoles.com/feed'},
  {id:'g1mundo', nome:'g1 Mundo',           sigla:'g1', cor:'#C4170C', cat:'mundo',  lang:'pt', url:'https://g1.globo.com/rss/g1/mundo/'},
  {id:'bbcbr',   nome:'BBC News Brasil',    sigla:'BBC',cor:'#BB1919', cat:'mundo',  lang:'pt', url:'https://feeds.bbci.co.uk/portuguese/rss.xml'},
  {id:'dwbr',    nome:'DW Brasil',          sigla:'DW', cor:'#05B2FC', cat:'mundo',  lang:'pt', url:'https://rss.dw.com/xml/rss-br-all'},
  {id:'folhamun',nome:'Folha · Mundo',      sigla:'F',  cor:'#1A1A1A', cat:'mundo',  lang:'pt', url:'https://feeds.folha.uol.com.br/mundo/rss091.xml'},
  {id:'aljaz',   nome:'Al Jazeera',         sigla:'AJ', cor:'#D29E2A', cat:'mundo',  lang:'en', url:'https://www.aljazeera.com/xml/rss/all.xml'},
  {id:'guardian',nome:'The Guardian',       sigla:'G',  cor:'#052962', cat:'mundo',  lang:'en', url:'https://www.theguardian.com/world/rss'},
  {id:'nyt',     nome:'New York Times',     sigla:'NYT',cor:'#111111', cat:'mundo',  lang:'en', url:'https://rss.nytimes.com/services/xml/rss/nyt/World.xml'}
];

// ---------- Configuração (em D, vai no backup) e cache (fora de D) ----------
function ntCfg(){
  const c = D.cfg.noticias = Object.assign({off:{}, extras:[], cat:'tudo'}, D.cfg.noticias || {});
  if(!c.off || typeof c.off !== 'object') c.off = {};
  if(!Array.isArray(c.extras)) c.extras = [];
  return c;
}
function ntFontes(){ return NT_FONTES.concat(ntCfg().extras.map(e => Object.assign({sigla:(e.nome||'?').slice(0,2), cor:'#5E625F'}, e))); }
function ntFonte(id){ return ntFontes().find(f => f.id === id) || {nome:id, sigla:'?', cor:'#5E625F', cat:'brasil'}; }

const NT_KEY = 'vida.noticias';
let NT;
function ntLer(){
  try { NT = JSON.parse(localStorage.getItem(NT_KEY) || '{}'); } catch(e){ NT = {}; }
  NT = Object.assign({itens:[], trends:[], ts:0, st:{}, trad:{}, vistos:{}, mostrar:30}, NT);
}
function ntGravar(){
  // Limpa traduções de notícias que já saíram do cache
  const ids = new Set(NT.itens.map(i => i.id));
  Object.keys(NT.trad).forEach(k => { if(!ids.has(k)) delete NT.trad[k]; });
  try { localStorage.setItem(NT_KEY, JSON.stringify(NT)); } catch(e){ NT.itens = NT.itens.slice(0, 150); try{ localStorage.setItem(NT_KEY, JSON.stringify(NT)); }catch(_){} }
}
ntLer();

// ---------- Leitura dos feeds (RSS 2.0, RSS 1.0/RDF e Atom), tolerante a XML quebrado ----------
const ntParser = new DOMParser();
function ntTexto(s){
  if(!s) return '';
  s = s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1');
  // Converte entidades e remove tags, sem executar nada (documento inerte do DOMParser)
  let t = ntParser.parseFromString(s, 'text/html').body.textContent || '';
  if(/<[a-z!\/]/i.test(t)) t = ntParser.parseFromString(t, 'text/html').body.textContent || '';
  return t.replace(/\s+/g, ' ').trim();
}
function ntCru(s){ return (s || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1'); }
function ntTag(bloco, nome){
  const m = bloco.match(new RegExp('<' + nome + '(?:\\s[^>]*)?>([\\s\\S]*?)</' + nome + '>', 'i'));
  return m ? m[1] : '';
}
function ntAttr(bloco, nome, attr){
  const re = new RegExp('<' + nome + '\\s[^>]*?' + attr + '\\s*=\\s*["\']([^"\']+)["\'][^>]*>', 'gi');
  const out = []; let m; while((m = re.exec(bloco))) out.push({tag:m[0], v:m[1]}); return out;
}
function ntUrl(u){
  u = ntTexto(u).replace(/&amp;/g, '&').trim();
  if(u.startsWith('//')) u = 'https:' + u;
  if(u.startsWith('http://')) u = 'https://' + u.slice(7);   // o app só abre https
  return /^https:\/\/[^\s"'<>]+$/.test(u) ? u : '';
}
function ntImagem(b){
  const cands = [];
  ntAttr(b, 'media:content', 'url').forEach(x => { if(!/medium=["'](video|audio)/i.test(x.tag) && !/type=["'](video|audio)/i.test(x.tag)) cands.push(x.v); });
  ntAttr(b, 'media:thumbnail', 'url').forEach(x => cands.push(x.v));
  ntAttr(b, 'enclosure', 'url').forEach(x => { if(/type=["']image/i.test(x.tag) || /\.(jpe?g|png|webp|gif)(\?|$)/i.test(x.v)) cands.push(x.v); });
  const dest = ntTag(b, 'imagem-destaque'); if(dest) cands.push(dest);
  const img = ntTag(ntTag(b, 'image'), 'url'); if(img) cands.push(img);
  const html = ntCru(ntTag(b, 'content:encoded') + ntTag(b, 'description') + ntTag(b, 'content') + ntTag(b, 'summary'))
    .replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#0?39;/g, "'");
  const m = html.match(/<img[^>]+src\s*=\s*["']([^"']+)["']/i); if(m) cands.push(m[1]);
  for(const c of cands){ const u = ntUrl(c); if(u) return u; }
  return '';
}
function ntLink(b){
  let l = ntTexto(ntTag(b, 'link'));
  if(!l){ const al = ntAttr(b, 'link', 'href'); const alt = al.find(x => !/rel=["'](?!alternate)/i.test(x.tag)) || al[0]; if(alt) l = alt.v; }
  if(!l){ const g = ntTexto(ntTag(b, 'guid')); if(/^https?:/.test(g)) l = g; }
  return ntUrl(l);
}
function ntData(b){
  for(const t of ['pubDate', 'dc:date', 'published', 'updated', 'a10:updated']){
    const s = ntTexto(ntTag(b, t)); if(s){ const d = Date.parse(s); if(isFinite(d)) return d; }
  }
  return 0;
}
function ntResumo(s, max){
  s = s || ''; if(s.length <= max) return s;
  const c = s.slice(0, max); const i = c.lastIndexOf(' ');
  return (i > max * 0.6 ? c.slice(0, i) : c) + '…';
}
function ntHash(s){ let h = 5381; for(let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36); }

function ntParseFeed(xml, fonte, agora){
  const blocos = xml.match(/<item[\s>][\s\S]*?<\/item>/gi) || xml.match(/<entry[\s>][\s\S]*?<\/entry>/gi) || [];
  const itens = [];
  blocos.slice(0, 60).forEach(b => {
    const titulo = ntTexto(ntTag(b, 'title')); const link = ntLink(b);
    if(!titulo || !link) return;
    let desc = ntTexto(ntTag(b, 'description') || ntTag(b, 'summary') || ntTag(b, 'content'));
    if(desc.toLowerCase().startsWith(titulo.toLowerCase())) desc = desc.slice(titulo.length).trim();
    itens.push({id:ntHash(link), f:fonte.id, cat:fonte.cat, lang:fonte.lang || 'pt',
      t:ntResumo(titulo, 220), d:ntResumo(desc, 260), l:link, img:ntImagem(b), ts:ntData(b) || agora});
  });
  return itens;
}
function ntParseTrends(xml){
  return (xml.match(/<item[\s>][\s\S]*?<\/item>/gi) || []).slice(0, 20).map(b => {
    const ni = ntTag(b, 'ht:news_item');
    return {t:ntTexto(ntTag(b, 'title')), traf:ntTexto(ntTag(b, 'ht:approx_traffic')), img:ntUrl(ntTag(b, 'ht:picture')),
      nt:ntTexto(ntTag(ni, 'ht:news_item_title')), nu:ntUrl(ntTag(ni, 'ht:news_item_url')), ns:ntTexto(ntTag(ni, 'ht:news_item_source')),
      ts:ntData(b)};
  }).filter(x => x.t);
}

// ---------- Rede ----------
function ntBaixar(url){
  return new Promise(res => {
    if(!NATIVO || !Android.fetchText){ res({status:0, body:''}); return; }
    const id = uid(); _cbs[id] = res;
    const limite = setTimeout(() => { if(_cbs[id]){ delete _cbs[id]; res({status:0, body:''}); } }, 40000);
    _cbs[id] = r => { clearTimeout(limite); res(r); };
    Android.fetchText(id, url);
  });
}

let ntRodando = false;
async function ntAtualizar(forcar){
  if(ntRodando) return;
  if(!forcar && Date.now() - NT.ts < NT_INTERVALO) return;
  if(!NATIVO || !Android.fetchText){ if(forcar) toast('As notícias funcionam no app instalado'); return; }
  ntRodando = true; ntRender();
  const cfg = ntCfg(), agora = Date.now();
  const ativas = ntFontes().filter(f => !cfg.off[f.id]);
  const antigos = NT.itens;
  const porFonte = {};
  await Promise.all(ativas.map(async f => {
    const r = await ntBaixar(f.url);
    let itens = [];
    try { if(r.status >= 200 && r.status < 300) itens = ntParseFeed(r.body || '', f, agora); } catch(e){ itens = []; }
    if(itens.length){ porFonte[f.id] = itens; NT.st[f.id] = {ok:true, n:itens.length, quando:agora}; }
    else NT.st[f.id] = {ok:false, n:0, quando:agora, erro: r.status ? 'erro ' + r.status : 'sem resposta'};
  }));
  const tr = await ntBaixar(NT_TRENDS);
  try { const t = ntParseTrends(tr.body || ''); if(t.length){ NT.trends = t; NT.st._trends = {ok:true, n:t.length, quando:agora}; } else NT.st._trends = {ok:false, n:0, quando:agora}; } catch(e){}

  // Junta: fontes que falharam mantêm o que já tinham; remove fontes desligadas; tira repetidas
  const vistos = new Set(), titulos = new Set(), novos = [];
  const primeiraVez = {}; antigos.forEach(i => { primeiraVez[i.id] = i.v || i.ts; });
  ativas.forEach(f => (porFonte[f.id] || antigos.filter(i => i.f === f.id)).forEach(i => {
    const chave = i.t.toLowerCase().replace(/[^a-zà-ú0-9 ]/g, '').slice(0, 70);
    if(vistos.has(i.id) || titulos.has(chave)) return;
    vistos.add(i.id); titulos.add(chave);
    i.v = primeiraVez[i.id] || agora;
    if(i.ts > agora + 3600e3) i.ts = agora;   // data no futuro (fuso errado no feed)
    if(agora - i.ts < NT_GUARDA) novos.push(i);
  }));
  novos.sort((a, b) => b.ts - a.ts);
  NT.itens = novos.slice(0, 400); NT.ts = agora;
  ntGravar(); ntRodando = false; ntRender();
  ntTraduzir();
}

// ---------- Tradução (IA grátis) ----------
let ntTraduzindo = false;
async function ntTraduzir(){
  if(ntTraduzindo || !iaPronta()) return;
  const lim = Date.now() - NT_JANELA;
  const fila = NT.itens.filter(i => i.lang !== 'pt' && !NT.trad[i.id] && i.ts >= lim).slice(0, 45);
  if(!fila.length) return;
  ntTraduzindo = true; ntRender();
  const sistema = 'Você traduz manchetes de notícias para o português do Brasil. Tradução fiel e jornalística, sem opinar, ' +
    'sem resumir e sem acrescentar nada. Mantenha nomes próprios, siglas e números. ' +
    'Responda só com JSON no formato {"t":[{"i":0,"titulo":"...","resumo":"..."}]}, um objeto para cada item recebido, com o mesmo "i".';
  try {
    for(let k = 0; k < fila.length; k += 15){
      const lote = fila.slice(k, k + 15);
      const entrada = JSON.stringify(lote.map((x, i) => ({i, titulo:x.t, resumo:x.d})));
      const j = iaJSON(await iaPedir(sistema, entrada));
      (Array.isArray(j.t) ? j.t : []).forEach(r => {
        const x = lote[r && r.i]; if(!x || typeof r.titulo !== 'string' || !r.titulo.trim()) return;
        NT.trad[x.id] = {t:ntResumo(r.titulo.trim(), 240), d:ntResumo(String(r.resumo || '').trim(), 300)};
      });
      ntGravar(); ntRender();
    }
  } catch(e){ NT.erroTrad = e.message; }
  ntTraduzindo = false; ntRender();
}

// ---------- Tela ----------
function ntRel(ts){
  const m = Math.max(0, Math.round((Date.now() - ts) / 60000));
  if(m < 1) return 'agora'; if(m < 60) return 'há ' + m + ' min';
  const h = Math.floor(m / 60); if(h < 24) return 'há ' + h + ' h';
  return 'há ' + Math.floor(h / 24) + ' d';
}
function ntDaCat(cat){
  const lim = Date.now() - NT_JANELA;
  const base = NT.itens.filter(i => i.ts >= lim && !ntCfg().off[i.f]);
  if(cat === 'tudo') return base;
  if(cat === 'jn') return base.filter(i => i.cat === 'jn' || /jornal-nacional/.test(i.l));
  return base.filter(i => i.cat === cat);
}
function ntNovas(cat){
  const v = NT.vistos[cat] || 0;
  if(cat === 'alta') return NT.trends.length && (NT.st._trends || {}).quando > v ? 1 : 0;
  return ntDaCat(cat).filter(i => (i.v || i.ts) > v).length;
}
function ntOriginal(id){ NT.verOriginal = NT.verOriginal || {}; NT.verOriginal[id] = !NT.verOriginal[id]; ntRender(); }

function ntPost(i, n){
  const f = ntFonte(i.f), tr = NT.trad[i.id], orig = NT.verOriginal && NT.verOriginal[i.id];
  const titulo = tr && !orig ? tr.t : i.t, desc = tr && !orig ? tr.d : i.d;
  const catNome = (NT_CATS.find(c => c.id === i.cat) || {}).nome || '';
  return '<article class="nt-post" data-n="' + n + '">' +
    '<div class="nt-hd"><span class="nt-av" style="background:' + esc(f.cor) + '">' + esc(f.sigla) + '</span>' +
      '<div class="nt-who"><b>' + esc(f.nome) + '</b><span>' + ntRel(i.ts) + (catNome ? ' · ' + catNome : '') + '</span></div>' +
      (i.lang !== 'pt' ? '<span class="nt-lang">' + (tr ? (orig ? 'ORIGINAL' : 'TRADUZIDA') : esc(i.lang.toUpperCase())) + '</span>' : '') + '</div>' +
    (i.img ? '<img class="nt-img" data-a="abrir" loading="lazy" referrerpolicy="no-referrer" alt="" src="' + esc(i.img) + '" onerror="this.remove()">' : '') +
    '<div class="nt-bd" data-a="abrir"><h3>' + esc(titulo) + '</h3>' + (desc ? '<p>' + esc(desc) + '</p>' : '') + '</div>' +
    (tr ? '<button class="nt-trbtn" data-a="original">' + (orig ? 'Ver tradução' : 'Traduzido do inglês · ver original') + '</button>' : '') +
    '<div class="nt-ac"><button data-a="abrir">Ler</button><button data-a="x">No X</button><button data-a="compartilhar">Compartilhar</button></div>' +
  '</article>';
}
function ntAlta(){
  if(!NT.trends.length) return '<div class="empty">' + (ntRodando ? 'Buscando os assuntos em alta…' : 'Ainda sem dados. Toque em atualizar.') + '</div>';
  return '<p class="note nt-aviso">Assuntos mais buscados no Brasil agora (Google). O X cobra pelo acesso aos tópicos dele, então cada assunto tem um atalho que abre a conversa direto no app do X.</p>' +
    NT.trends.map((t, n) => '<article class="nt-trend" data-tn="' + n + '">' +
      '<span class="nt-rank">' + (n + 1) + '</span>' +
      '<div class="nt-tx"><b>' + esc(t.t) + '</b><span>' + esc(t.traf ? t.traf + ' buscas' : '') + '</span>' +
        (t.nt ? '<p data-a="tnoticia">' + esc(t.nt) + (t.ns ? ' <i>· ' + esc(t.ns) + '</i>' : '') + '</p>' : '') +
        '<div class="nt-ac"><button data-a="tx">Ver no X</button>' + (t.nu ? '<button data-a="tnoticia">Ler notícia</button>' : '') + '</div></div>' +
      (t.img ? '<img loading="lazy" referrerpolicy="no-referrer" alt="" src="' + esc(t.img) + '" onerror="this.remove()">' : '') +
    '</article>').join('');
}

let ntLista = [];
function ntRender(){
  const el = document.getElementById('s-noticias'); if(!el || tela !== 'noticias') { ntBanner(); return; }
  const cfg = ntCfg(), cat = cfg.cat;
  const status = ntRodando ? 'Atualizando…' : NT.ts ? 'Atualizado ' + ntRel(NT.ts) + ' · a cada 15 min' : 'Ainda não atualizado';
  const temIngles = ntDaCat(cat === 'alta' ? 'tudo' : cat).some(i => i.lang !== 'pt' && !NT.trad[i.id]);
  let corpo;
  if(cat === 'alta') corpo = ntAlta();
  else {
    ntLista = ntDaCat(cat);
    const mostra = ntLista.slice(0, NT.mostrar);
    corpo = (cat === 'jn' ? '<div class="nt-jn"><div><b>Jornal Nacional</b><span>De segunda a sábado, à noite, na Globo. Aqui ficam as matérias publicadas no g1.</span></div><button class="btn primary" data-a="assistirjn">Ver no g1</button></div>' : '') +
      (mostra.length ? mostra.map(ntPost).join('') :
        '<div class="empty">' + (ntRodando ? 'Buscando notícias…' : NT.ts ? 'Nenhuma notícia nas últimas 36 horas nesta aba.' : 'Toque em atualizar para buscar as notícias.') + '</div>') +
      (ntLista.length > mostra.length ? '<button class="btn outline full" data-a="mais">Mostrar mais ' + Math.min(20, ntLista.length - mostra.length) + '</button>'
        : mostra.length ? '<div class="nt-fim"><b>Você está em dia</b><span>Isso é tudo das últimas 36 horas.</span></div>' : '');
  }
  el.innerHTML =
    '<div class="between" style="align-items:center"><div><h1>Notícias</h1><div class="sub">' + status + '</div></div>' +
      '<div class="row" style="gap:6px">' +
        (iaPronta() ? '<button class="nt-ico" data-a="resumo" aria-label="Resumo"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M4 12h10M4 18h7"/></svg></button>' : '') +
        '<button class="nt-ico" data-a="atualizar" aria-label="Atualizar"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"' + (ntRodando ? ' class="nt-gira"' : '') + '><path d="M21 12a9 9 0 1 1-3-6.7L21 8"/><path d="M21 3v5h-5"/></svg></button>' +
        '<button class="nt-ico" data-a="fontes" aria-label="Fontes"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0"/><circle cx="16" cy="6" r="2"/><circle cx="10" cy="12" r="2"/><circle cx="18" cy="18" r="2"/></svg></button>' +
      '</div></div>' +
    '<div class="nt-stories">' + NT_CATS.map(c => {
      const n = c.id === cat ? 0 : ntNovas(c.id);
      return '<button class="nt-story' + (c.id === cat ? ' on' : '') + (n ? ' novo' : '') + '" data-cat="' + c.id + '"><span class="nt-ring"><span>' + ntIconeCat(c.id) + '</span></span>' + c.nome + '</button>';
    }).join('') + '</div>' +
    (temIngles && cat !== 'alta' ? (iaPronta()
      ? (ntTraduzindo ? '<p class="note nt-aviso">Traduzindo as notícias em inglês…</p>' : NT.erroTrad ? '<p class="note nt-aviso">Não deu para traduzir agora: ' + esc(NT.erroTrad) + '</p>' : '')
      : '<p class="note nt-aviso">Algumas notícias estão em inglês. Para traduzir automaticamente, ative a IA grátis em <b>Mais → Inteligência artificial</b>.</p>') : '') +
    corpo;
}
function ntIconeCat(id){
  const p = {
    tudo:'<path d="M4 5h16v14H4z"/><path d="M8 9h8M8 13h8M8 17h5"/>',
    brasil:'<path d="M12 3 21 12 12 21 3 12z"/><circle cx="12" cy="12" r="3"/>',
    mundo:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/>',
    jn:'<rect x="3" y="6" width="18" height="12" rx="2"/><path d="m10 9 5 3-5 3z"/>',
    alta:'<path d="M3 17l6-6 4 4 8-8"/><path d="M15 7h6v6"/>'
  }[id];
  return '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + p + '</svg>';
}

function ntAbrir(url){ if(!url) return; if(NATIVO && Android.openUrl) Android.openUrl(url); else window.open(url, '_blank'); }
function ntBuscaX(termo){
  const q = termo.replace(/[“”"'‘’]/g, '').split(/\s+/).filter(w => w.length > 3).slice(0, 6).join(' ') || termo;
  return 'https://x.com/search?q=' + encodeURIComponent(q) + '&f=top';
}
function ntCompartilhar(i){
  const tr = NT.trad[i.id], t = (tr ? tr.t : i.t) + '\n' + i.l;
  if(NATIVO && Android.shareText) Android.shareText(t); else { try{ navigator.clipboard.writeText(t); toast('Link copiado'); }catch(e){} }
}
function ntMudarCat(cat){
  const cfg = ntCfg(); NT.vistos[cfg.cat] = Date.now();
  cfg.cat = cat; NT.vistos[cat] = Date.now(); NT.mostrar = 30; save(); ntGravar(); ntRender();
  document.querySelector('main').scrollTop = 0;
}

// ---------- Resumo do dia (IA grátis, só manchetes públicas) ----------
async function ntResumir(){
  openSheet('nt-resumo');
  const el = document.getElementById('nt-res');
  const lim = Date.now() - 12 * 3600e3;
  const base = NT.itens.filter(i => i.ts >= lim && !ntCfg().off[i.f]).slice(0, 60);
  if(!base.length){ el.innerHTML = '<div class="empty">Sem manchetes das últimas 12 horas. Atualize primeiro.</div>'; return; }
  const linhas = base.map(i => '- [' + ntFonte(i.f).nome + '] ' + ((NT.trad[i.id] || {}).t || i.t)).join('\n');
  const sistema = 'Você faz um resumo de notícias para um leitor brasileiro com TDAH. ' + hojeExtenso() + ' ' +
    'Use APENAS as manchetes recebidas; não acrescente fatos. Seja neutro e equilibrado: não opine, não tome lado e apresente posições diferentes quando houver. ' +
    'Agrupe por assunto e entregue no máximo 7 tópicos curtos (uma ou duas frases cada), do mais importante para o menos, ' +
    'com as fontes entre parênteses. Primeiro Brasil, depois mundo. Responda em português do Brasil, em texto simples, um tópico por linha começando com "• ".';
  try {
    const r = await iaPedir(sistema, linhas);
    el.innerHTML = r.split('\n').map(s => s.trim()).filter(Boolean).map(s => '<p class="nt-resp">' + esc(s) + '</p>').join('') +
      '<p class="note" style="margin:0">Resumo feito pela IA a partir de ' + base.length + ' manchetes das últimas 12 horas. Confira na fonte antes de repassar.</p>';
  } catch(e){ el.innerHTML = '<div class="empty">' + esc(e.message) + '</div>'; }
}

// ---------- Fontes ----------
function ntFontesHTML(){
  const cfg = ntCfg();
  const linha = f => {
    const s = NT.st[f.id];
    const st = !s ? 'ainda não buscada' : s.ok ? s.n + ' notícias' : 'falhou (' + esc(s.erro || '') + ')';
    return '<label class="item" style="gap:10px"><input type="checkbox" ' + (cfg.off[f.id] ? '' : 'checked') + ' onchange="ntLigar(\'' + f.id + '\',this.checked)">' +
      '<span class="nt-av sm" style="background:' + esc(f.cor) + '">' + esc(f.sigla) + '</span>' +
      '<span class="txt">' + esc(f.nome) + '<small' + (s && !s.ok ? ' style="color:var(--danger)"' : '') + '>' + ((NT_CATS.find(c => c.id === f.cat) || {}).nome || '') + (f.lang !== 'pt' ? ' · em inglês, traduzida' : '') + ' · ' + st + '</small></span>' +
      (f.extra ? '<button class="pill" onclick="event.preventDefault();ntRemover(\'' + f.id + '\')">Tirar</button>' : '') + '</label>';
  };
  return '<h2>Fontes de notícias</h2>' +
    '<p class="note" style="margin:0">Veículos com linhas editoriais diferentes, para você ver mais de um lado. Desmarque o que não quiser ver.</p>' +
    '<div class="card" style="padding:4px 14px">' + ntFontes().map(f => linha(Object.assign({extra: !NT_FONTES.includes(f)}, f))).join('') + '</div>' +
    '<h2>Adicionar fonte</h2>' +
    '<p class="note" style="margin:0">Cole o endereço do feed RSS do site (geralmente termina em /feed ou /rss).</p>' +
    '<label class="f">Nome<input id="nt-nome" placeholder="Ex.: Valor Econômico"></label>' +
    '<label class="f">Endereço do feed<input id="nt-url" autocapitalize="off" autocomplete="off" spellcheck="false" placeholder="https://..."></label>' +
    '<div class="row"><label class="f" style="flex:1">Aba<select id="nt-cat"><option value="brasil">Brasil</option><option value="mundo">Mundo</option><option value="jn">JN</option></select></label>' +
    '<label class="f" style="flex:1">Idioma<select id="nt-lang"><option value="pt">Português</option><option value="en">Inglês</option><option value="es">Espanhol</option></select></label></div>' +
    '<button class="btn primary full" onclick="ntAdicionar()">Adicionar</button>';
}
// Desligar só esconde (sem nova busca); religar busca de novo se a fonte não tem nada guardado
function ntLigar(id, on){ const c = ntCfg(); if(on){ delete c.off[id]; if(!NT.itens.some(i => i.f === id)) NT.ts = 0; } else c.off[id] = true; save(); }
function ntAdicionar(){
  const nome = (val('nt-nome') || '').trim(), url = (val('nt-url') || '').trim();
  if(!nome || !/^https:\/\/\S+$/.test(url)){ toast('Preencha o nome e um endereço que comece com https://'); return; }
  ntCfg().extras.push({id:'x' + uid(), nome, url, cat:val('nt-cat'), lang:val('nt-lang'), sigla:nome.slice(0, 2), cor:'#5E625F'});
  save(); NT.ts = 0; openSheet('nt-fontes'); toast('Fonte adicionada. Atualizando…'); ntAtualizar(true);
}
function ntRemover(id){ const c = ntCfg(); c.extras = c.extras.filter(e => e.id !== id); delete c.off[id]; save(); openSheet('nt-fontes'); }

// ---------- Atalho no Início ----------
function ntBanner(){
  const b = document.getElementById('nt-banner'); if(!b) return;
  const lista = ntDaCat('tudo'), n = ntNovas('tudo');
  // Destaque = a mais recente COM foto (se nenhuma tiver, a mais recente)
  const top = lista.slice(0, 8).find(i => i.img) || lista[0];
  if(!top){ b.style.display = 'none'; return; }
  b.style.display = '';
  const tx = i => { const tr = NT.trad[i.id]; return {t: tr ? tr.t : i.t, d: tr ? tr.d : i.d}; };
  const f = ntFonte(top.f), cat = (NT_CATS.find(c => c.id === top.cat) || {}).nome || '', x = tx(top);
  const outras = lista.filter(i => i !== top).slice(0, 2);
  const capa = top.img
    ? '<div class="ini-capa"><img loading="lazy" referrerpolicy="no-referrer" alt="" src="' + esc(top.img) + '" onerror="this.parentNode.classList.add(\'sem\');this.remove()"><span class="ini-selo">' + esc(f.sigla) + '</span></div>'
    : '<div class="ini-capa sem" style="--fc:' + esc(f.cor) + '"><span class="ini-selo">' + esc(f.sigla) + '</span></div>';
  b.innerHTML = capa +
    '<div class="ini-corpo">' +
      '<div class="ini-meta"><span>' + esc(f.nome) + ' · ' + ntRel(top.ts) + (cat ? ' · ' + esc(cat) : '') + '</span>' + (n ? '<span class="ini-pill">' + n + (n > 1 ? ' novas' : ' nova') + '</span>' : '') + '</div>' +
      '<b class="ini-tit">' + esc(x.t) + '</b>' +
      (x.d ? '<span class="ini-res">' + esc(x.d) + '</span>' : '') +
      (outras.length ? '<div class="ini-mais">' + outras.map(o => '<div class="ini-linha">' +
        (o.img ? '<img loading="lazy" referrerpolicy="no-referrer" alt="" src="' + esc(o.img) + '" onerror="this.remove()">' : '<span class="nt-av sm" style="background:' + esc(ntFonte(o.f).cor) + '">' + esc(ntFonte(o.f).sigla) + '</span>') +
        '<span>' + esc(tx(o).t) + '</span></div>').join('') + '</div>' : '') +
      '<span class="ini-cta">Ver todas as notícias</span>' +
    '</div>';
}

// ---------- Integração com o app ----------
(function(){
  const sec = document.createElement('section');
  sec.className = 'screen'; sec.id = 's-noticias';
  document.querySelector('main').appendChild(sec);

  // Botão na barra de baixo, logo depois do Início
  const nav = document.querySelector('nav');
  const bt = document.createElement('button');
  bt.dataset.go = 'noticias'; bt.onclick = () => go('noticias');
  bt.innerHTML = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h13v16H6a2 2 0 0 1-2-2z"/><path d="M17 8h3v10a2 2 0 0 1-2 2"/><path d="M8 8h5M8 12h5M8 16h3"/></svg>Notícias';
  nav.insertBefore(bt, nav.querySelector('[data-go=tarefas]'));
  nav.classList.add('seis');

  // Atalho discreto no Início
  const inicio = document.getElementById('s-inicio');
  const ban = document.createElement('button');
  ban.id = 'nt-banner'; ban.className = 'card ini-card';
  ban.style.cssText = 'display:none';
  ban.onclick = () => go('noticias');
  inicio.appendChild(ban);

  // Cliques no feed (delegação: nenhum link do feed vira código)
  sec.addEventListener('click', e => {
    const a = e.target.closest('[data-a],[data-cat]'); if(!a) return;
    if(a.dataset.cat){ ntMudarCat(a.dataset.cat); return; }
    const acao = a.dataset.a, post = a.closest('[data-n]'), trend = a.closest('[data-tn]');
    const i = post ? ntLista[+post.dataset.n] : null, t = trend ? NT.trends[+trend.dataset.tn] : null;
    if(acao === 'atualizar') ntAtualizar(true);
    else if(acao === 'fontes') openSheet('nt-fontes');
    else if(acao === 'resumo') ntResumir();
    else if(acao === 'mais'){ NT.mostrar += 20; ntRender(); }
    else if(acao === 'assistirjn') ntAbrir('https://g1.globo.com/jornal-nacional/');
    else if(i && acao === 'abrir') ntAbrir(i.l);
    else if(i && acao === 'x') ntAbrir(ntBuscaX((NT.trad[i.id] || {}).t || i.t));
    else if(i && acao === 'compartilhar') ntCompartilhar(i);
    else if(i && acao === 'original') ntOriginal(i.id);
    else if(t && acao === 'tx') ntAbrir('https://x.com/search?q=' + encodeURIComponent(t.t) + '&f=top');
    else if(t && acao === 'tnoticia') ntAbrir(t.nu);
  });

  const _f = formHTML;
  formHTML = function(tipo, id){
    if(tipo === 'nt-fontes') return ntFontesHTML();
    if(tipo === 'nt-resumo') return '<h2>Resumo das notícias</h2><div id="nt-res" style="display:flex;flex-direction:column;gap:10px"><div class="empty">Lendo as manchetes…</div></div>';
    return _f(tipo, id);
  };
  const _close = closeSheet;
  closeSheet = function(){ const era = sheetTipo; _close(); if(era === 'nt-fontes'){ ntRender(); if(Date.now() - NT.ts > NT_INTERVALO) ntAtualizar(); } };

  const _go = go;
  go = function(t){
    if(tela === 'noticias' && t !== 'noticias') NT.vistos[ntCfg().cat] = Date.now(), ntGravar();
    _go(t);
    if(t === 'noticias'){ NT.mostrar = 30; ntRender(); ntAtualizar(); ntTraduzir(); }
  };
  const _r = render;
  render = function(){ _r(); ntBanner(); };

  // A cada minuto confere se já passaram 15 min (só com o app aberto); e ao voltar para o app
  setInterval(() => { if(!document.hidden) ntAtualizar(); }, 60000);
  const _res = window.appResume;
  window.appResume = function(){ if(_res) _res(); ntAtualizar(); if(tela === 'noticias') ntRender(); };
  setTimeout(() => ntAtualizar(), 2500);
  ntBanner();
})();
