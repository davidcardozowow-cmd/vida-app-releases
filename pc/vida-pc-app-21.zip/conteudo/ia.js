// =====================================================================
// IA no app (v2.6)
// 1. IA grátis dentro do app (Groq ou Gemini): texto livre -> tarefas; tarefa -> passos.
// 2. "Perguntar ao Claude / ChatGPT": monta o pedido e abre o app escolhido (assinaturas do David).
// 3. "Compartilhar -> Vida": texto vindo de outro app (ex.: WhatsApp) abre a anotação com IA.
// Regra de privacidade: FINANÇAS NUNCA vão para a IA grátis. Só para Claude/ChatGPT, por ação do David.
// Depende de: D, save, render, toast, esc, cofre, http, NATIVO, openSheet, closeSheet, tmpPassos,
//             renderPassos, AREAS, hoje, addDias, quando, brl, lancMes, contasAbertas (index.html).
// =====================================================================

const IA = {
  groq:   {nome:'Groq',   modelo:'llama-3.3-70b-versatile', reserva:'llama-3.1-8b-instant', chave:'ia_groq',
           site:'https://console.groq.com/keys'},
  gemini: {nome:'Gemini', modelo:'gemini-3.5-flash-lite', reserva:null, chave:'ia_gemini',
           site:'https://aistudio.google.com/apikey'}
};
const APPS_IA = {claude:{nome:'Claude', pacote:'com.anthropic.claude'}, chatgpt:{nome:'ChatGPT', pacote:'com.openai.chatgpt'}};

function iaCfg(){ D.cfg.ia = D.cfg.ia || ''; return D.cfg.ia ? IA[D.cfg.ia] : null; }
function iaPronta(){ const c = iaCfg(); return !!(c && NATIVO && cofre.get(c.chave)); }
function hojeExtenso(){
  const d = new Date(), dias = ['domingo','segunda-feira','terça-feira','quarta-feira','quinta-feira','sexta-feira','sábado'];
  return 'Hoje é ' + dias[d.getDay()] + ', ' + pad2(d.getDate()) + '/' + pad2(d.getMonth()+1) + '/' + d.getFullYear() + ' (' + hoje() + ').';
}

// ---------- Chamada à IA grátis ----------
function iaErro(r){
  if(r.status === 0) return 'Sem internet ou a IA não respondeu.';
  if(r.status === 401 || r.status === 403) return 'A chave da IA foi recusada. Confira em Mais → Inteligência artificial.';
  if(r.status === 429) return 'Limite gratuito da IA atingido por agora. Tente daqui a pouco.';
  if(r.status === 404) return 'Modelo não encontrado. Em Mais, deixe o campo "Modelo" vazio para usar o padrão.';
  return 'A IA respondeu com erro ' + r.status + '.';
}
async function iaPedir(sistema, usuario, modeloForcado){
  const id = D.cfg.ia, c = IA[id]; if(!c) throw new Error('Configure a IA grátis em Mais.');
  const chave = cofre.get(c.chave); if(!chave) throw new Error('Falta a chave da IA. Configure em Mais.');
  const modelo = modeloForcado || (D.cfg.iaModelo || '').trim() || c.modelo;
  let r;
  if(id === 'groq'){
    r = await http('POST', 'https://api.groq.com/openai/v1/chat/completions', {'Authorization':'Bearer ' + chave},
      {model:modelo, temperature:0.2, max_tokens:900, messages:[{role:'system', content:sistema}, {role:'user', content:usuario}]});
    if(r.status === 429 && c.reserva && modelo !== c.reserva) return iaPedir(sistema, usuario, c.reserva);
    if(r.status !== 200) throw new Error(iaErro(r));
    return JSON.parse(r.body).choices[0].message.content || '';
  }
  r = await http('POST', 'https://generativelanguage.googleapis.com/v1beta/models/' + encodeURIComponent(modelo) + ':generateContent',
    {'x-goog-api-key': chave},
    {systemInstruction:{parts:[{text:sistema}]}, contents:[{role:'user', parts:[{text:usuario}]}], generationConfig:{temperature:0.2, maxOutputTokens:900}});
  if(r.status !== 200) throw new Error(iaErro(r));
  const j = JSON.parse(r.body);
  return ((((j.candidates || [])[0] || {}).content || {}).parts || []).map(p => p.text || '').join('');
}
function iaJSON(txt){
  const a = txt.indexOf('{'), b = txt.lastIndexOf('}');
  if(a < 0 || b <= a) throw new Error('A IA não respondeu no formato esperado. Tente de novo.');
  return JSON.parse(txt.slice(a, b + 1));
}

// ---------- 1. Texto livre -> tarefas ----------
let iaSugestoes = [];
async function iaOrganizar(){
  const txt = (val('f-ialivre') || '').trim(); if(!txt){ toast('Escreva o que precisa fazer'); return; }
  if(!iaPronta()){ toast('Configure a IA grátis em Mais'); return; }
  const btn = document.getElementById('ia-btn'); btn.disabled = true; btn.textContent = 'Organizando...';
  const sistema = 'Você transforma anotações de um brasileiro com TDAH em tarefas curtas e acionáveis. ' + hojeExtenso() +
    ' Responda SOMENTE com JSON no formato {"tarefas":[{"titulo":"...","area":"fin|trab|est|pes","data":"AAAA-MM-DD ou null"}]}. ' +
    'Regras: um item por ação; título começando com verbo, até 60 caracteres, em português; ' +
    'area: fin = dinheiro e contas, trab = trabalho e carreira, est = estudos e curso, pes = casa, saúde, família e o resto; ' +
    'converta "hoje", "amanhã", "sexta" etc. em data a partir de hoje; sem data mencionada, use null. ' +
    'NÃO invente tarefas, pessoas, valores ou datas que não estejam no texto.';
  try{
    const j = iaJSON(await iaPedir(sistema, txt));
    iaSugestoes = (j.tarefas || []).slice(0, 12).map(t => ({
      titulo: String(t.titulo || '').trim().slice(0, 80),
      area: AREAS[t.area] ? t.area : 'pes',
      data: /^\d{4}-\d{2}-\d{2}$/.test(String(t.data)) ? t.data : null,
      ok: true
    })).filter(t => t.titulo);
    if(!iaSugestoes.length) throw new Error('A IA não encontrou tarefas no texto.');
    iaRenderSugestoes();
  }catch(e){ toast(e.message); }
  finally{ const b = document.getElementById('ia-btn'); if(b){ b.disabled = false; b.textContent = 'Organizar com IA'; } }
}
function iaRenderSugestoes(){
  const el = document.getElementById('ia-sug'); if(!el) return;
  const n = iaSugestoes.filter(s => s.ok).length;
  el.innerHTML = '<div class="sub" style="font-weight:700">Confira antes de adicionar</div>'+
    '<div class="card" style="padding:2px 14px">'+iaSugestoes.map((s, i) => {
      const a = AREAS[s.area];
      return '<label class="item"><input type="checkbox" '+(s.ok?'checked':'')+' onchange="iaSugestoes['+i+'].ok=this.checked;iaRenderSugestoes()">'+
        '<span class="txt">'+esc(s.titulo)+'<small>'+quando(s.data)+'</small></span><span class="tag" style="color:'+a.cor+'">'+a.nome.toUpperCase()+'</span></label>';
    }).join('')+'</div>'+
    '<button class="btn primary full" '+(n?'':'disabled')+' onclick="iaAdicionar()">Adicionar '+n+' tarefa'+(n===1?'':'s')+'</button>';
}
function iaAdicionar(){
  const novas = iaSugestoes.filter(s => s.ok);
  novas.forEach((s, i) => D.tarefas.push({id:uid(), titulo:s.titulo, area:s.area, data:s.data, feita:false, status:'todo', passos:[], criada:Date.now() + i}));
  save(); closeSheet(); render(); toast(novas.length + ' tarefa(s) adicionada(s)');
  iaSugestoes = [];
}
function iaSalvarComoUma(){
  const txt = (val('f-ialivre') || '').trim(); if(!txt){ toast('Escreva algo'); return; }
  D.tarefas.push({id:uid(), titulo:txt.split('\n')[0].slice(0, 80), area:'pes', data:hoje(), feita:false, status:'todo', passos:[], criada:Date.now()});
  save(); closeSheet(); render(); toast('Tarefa salva');
}

// ---------- 2. Tarefa -> passos ----------
async function iaPassos(){
  const titulo = (val('f-titulo') || '').trim(); if(!titulo){ toast('Escreva a tarefa primeiro'); return; }
  if(!iaPronta()){ toast('Configure a IA grátis em Mais'); return; }
  const b = document.getElementById('ia-passos-btn'); b.disabled = true; b.textContent = 'Pensando...';
  const sistema = 'Você ajuda um brasileiro com TDAH a começar tarefas. ' + hojeExtenso() +
    ' Quebre a tarefa em 3 a 6 passos pequenos, concretos e em ordem, cada um de 5 a 10 minutos, começando com verbo, até 50 caracteres. ' +
    'O primeiro passo deve ser bem fácil de começar. Responda SOMENTE com JSON: {"passos":["...","..."]}. Não invente fatos sobre a pessoa.';
  try{
    const j = iaJSON(await iaPedir(sistema, 'Tarefa: ' + titulo + '\nÁrea: ' + AREAS[val('f-area')].nome));
    const ps = (j.passos || []).map(p => String(p).trim().slice(0, 70)).filter(Boolean).slice(0, 6);
    if(!ps.length) throw new Error('A IA não sugeriu passos. Tente de novo.');
    ps.forEach(p => tmpPassos.push({t:p, ok:false})); renderPassos();
    toast(ps.length + ' passos sugeridos. Edite à vontade.');
  }catch(e){ toast(e.message); }
  finally{ b.disabled = false; b.textContent = 'Quebrar em passos com IA'; }
}

// ---------- 3. Perguntar ao Claude / ChatGPT ----------
function promptTarefa(){
  const titulo = (val('f-titulo') || '').trim() || '[tarefa]';
  const passos = tmpPassos.map(p => '- ' + p.t).join('\n');
  return 'O que eu quero: ajuda para concluir a tarefa "' + titulo + '".\n' +
    'Como: me dê um plano curto e prático, em passos numerados de até 10 minutos, e diga por qual começar agora.\n' +
    'O que eu NÃO quero: texto longo, teoria ou passos genéricos. Se faltar informação, me pergunte antes de supor.\n' +
    'Como saber que deu certo: eu consigo começar o primeiro passo em menos de 2 minutos.\n' +
    (passos ? '\nPassos que já anotei:\n' + passos + '\n' : '') + '\nContexto: tenho TDAH. ' + hojeExtenso();
}
function promptFinancas(){
  const cats = {}; let e = 0, s = 0;
  lancMes().filter(l => !l.interno).forEach(l => { if(l.tipo === 'in') e += l.valor; else { s += l.valor; cats[l.cat || 'Outros'] = (cats[l.cat || 'Outros'] || 0) + l.valor; } });
  const linhasCat = Object.entries(cats).sort((a, b) => b[1] - a[1]).map(([c, v]) => '- ' + c + ': ' + brl(v)).join('\n') || '- (sem gastos anotados)';
  const contas = contasAbertas().slice(0, 10).map(c => '- ' + c.desc + ': ' + brl(c.valor) + ', vence ' + c.venc).join('\n') || '- (nenhuma)';
  const m = D.meta;
  return 'O que eu quero: entender para onde está indo meu dinheiro neste mês e o que ajustar.\n' +
    'Como: análise curta, com no máximo 3 recomendações práticas, mostrando as contas passo a passo.\n' +
    'O que eu NÃO quero: sugestão de empréstimo, de investimento arriscado, nem números que não estejam abaixo.\n' +
    'Como saber que deu certo: eu saio sabendo uma ação para fazer hoje.\n\n' +
    hojeExtenso() + '\nEntradas do mês: ' + brl(e) + '\nGastos do mês: ' + brl(s) + '\nGastos por categoria:\n' + linhasCat +
    '\nContas a vencer:\n' + contas + (m && m.alvo ? '\nMeta: ' + m.nome + ', ' + brl(m.guardado) + ' de ' + brl(m.alvo) : '') +
    '\n\nObservação: tenho TDAH e gasto por impulso às vezes. Seja direto e gentil.';
}
function abrirPerguntar(texto){
  openSheet('perguntar');
  document.getElementById('f-perg').value = texto || '';
}
function perguntarEm(app){
  const t = (val('f-perg') || '').trim(); if(!t){ toast('Escreva a pergunta'); return; }
  if(NATIVO && Android.askApp){ Android.askApp(APPS_IA[app].pacote, t); toast('Abrindo o ' + APPS_IA[app].nome + '. O texto também foi copiado.'); closeSheet(); }
  else { try{ navigator.clipboard.writeText(t); }catch(e){} toast('Texto copiado'); }
}

// ---------- Formulários novos e botões extras ----------
const _formIA = formHTML;
formHTML = function(tipo, id){
  if(tipo === 'ia-anotar') return '<h2>Escrever do meu jeito</h2>'+
    '<p class="note" style="margin:0">Despeje tudo o que está na cabeça. A IA separa em tarefas, com área e data, e você confere antes de salvar.</p>'+
    '<label class="f"><textarea id="f-ialivre" placeholder="Ex.: amanhã ligar pro cliente da proposta, pagar a luz até sexta e revisar topografia pro SENAI"></textarea></label>'+
    (iaPronta() ? '<button class="btn primary full" id="ia-btn" onclick="iaOrganizar()">Organizar com IA</button>'
                : '<p class="note" style="margin:0">Para organizar automaticamente, ative a IA grátis em <b>Mais → Inteligência artificial</b>.</p>')+
    '<button class="btn outline full" onclick="iaSalvarComoUma()">Salvar como uma tarefa só</button>'+
    '<div id="ia-sug" style="display:flex;flex-direction:column;gap:10px"></div>';
  if(tipo === 'perguntar') return '<h2>Perguntar ao Claude ou ChatGPT</h2>'+
    '<p class="note" style="margin:0">O pedido já vem montado com as 4 partes. Ajuste se quiser e escolha onde perguntar. Usa a sua conta de cada app, sem custo extra.</p>'+
    '<label class="f"><textarea id="f-perg" style="height:220px"></textarea></label>'+
    '<div class="row"><button class="btn primary" style="flex:1" onclick="perguntarEm(\'claude\')">Abrir no Claude</button>'+
    '<button class="btn outline" style="flex:1" onclick="perguntarEm(\'chatgpt\')">Abrir no ChatGPT</button></div>';
  return _formIA(tipo, id);
};
const _openIA = openSheet;
openSheet = function(tipo, id){
  _openIA(tipo, id);
  const sh = document.getElementById('sheet');
  // v3.2: as opções de IA do "+" agora fazem parte da grade em index.html (formHTML 'rapido').
  if(tipo === 'tarefa'){
    const passos = document.getElementById('f-passos');
    const linha = document.createElement('div'); linha.className = 'row';
    linha.innerHTML = '<button class="pill" id="ia-passos-btn" style="flex:1;height:38px">Quebrar em passos com IA</button>'+
      '<button class="pill" style="flex:1;height:38px">Pedir ajuda ao Claude / GPT</button>';
    linha.children[0].onclick = iaPassos;
    linha.children[1].onclick = () => abrirPerguntar(promptTarefa());
    if(!iaPronta()) linha.children[0].style.display = 'none';
    passos.parentNode.appendChild(linha);
  }
};

// ---------- Configuração em "Mais" ----------
function iaCard(){
  const el = document.getElementById('ia-card'); if(!el) return;
  const id = D.cfg.ia || '', c = IA[id];
  const temChave = c && NATIVO && !!cofre.get(c.chave);
  el.innerHTML = '<h2>Inteligência artificial</h2>'+
    '<p class="note" style="margin:0">IA grátis dentro do app para organizar anotações em tarefas e quebrar tarefas em passos. <b>Seus dados de dinheiro nunca vão para ela.</b> Para análises de finanças, o app usa o Claude ou o ChatGPT que você já tem.</p>'+
    '<div class="seg"><button class="'+(id==='groq'?'on':'')+'" onclick="iaEscolher(\'groq\')">Groq</button><button class="'+(id==='gemini'?'on':'')+'" onclick="iaEscolher(\'gemini\')">Gemini</button><button class="'+(!id?'on':'')+'" onclick="iaEscolher(\'\')">Desligada</button></div>'+
    (c ? (id==='gemini' ? '<p class="note" style="margin:0;color:var(--warn)">Atenção: no plano grátis, o Google pode usar e revisar o que você envia. Prefira a Groq.</p>' : '<p class="note" style="margin:0">A Groq não guarda o que você envia, por padrão.</p>')+
      '<button class="btn outline" onclick="(window.Android&&Android.openUrl)?Android.openUrl(\''+c.site+'\'):0">Criar minha chave grátis ('+c.nome+')</button>'+
      '<label class="f">Chave da API<input id="ia-chave" type="password" autocomplete="off" placeholder="'+(temChave?'Já salva. Deixe vazio para manter.':'Cole aqui a chave')+'"></label>'+
      '<label class="f">Modelo (opcional)<input id="ia-modelo" autocomplete="off" autocapitalize="off" value="'+esc(D.cfg.iaModelo||'')+'" placeholder="Padrão: '+c.modelo+'"></label>'+
      '<button class="btn primary" onclick="iaSalvarTestar()">Salvar e testar</button>' : '');
}
function iaEscolher(id){ D.cfg.ia = id; D.cfg.iaModelo = ''; save(); iaCard(); }
async function iaSalvarTestar(){
  if(!NATIVO){ toast('Disponível só no app instalado'); return; }
  const c = IA[D.cfg.ia], k = (val('ia-chave') || '').trim();
  if(k) cofre.set(c.chave, k);
  D.cfg.iaModelo = (val('ia-modelo') || '').trim(); save();
  if(!cofre.get(c.chave)){ toast('Cole a chave primeiro'); return; }
  toast('Testando...');
  try{ const r = await iaPedir('Responda apenas com a palavra: ok', 'teste'); toast(/ok/i.test(r) ? 'IA funcionando!' : 'A IA respondeu: ' + r.slice(0, 40)); iaCard(); render(); }
  catch(e){ toast(e.message); }
}

// ---------- Compartilhar -> Vida ----------
window.appCompartilhado = function(){
  if(!NATIVO || !Android.takeShared) return;
  const t = Android.takeShared(); if(!t) return;
  go('inicio'); openSheet('ia-anotar');
  document.getElementById('f-ialivre').value = t;
  toast(iaPronta() ? 'Recebido. Toque em Organizar com IA.' : 'Recebido. Salve como tarefa.');
};
const _resumeIA = window.appResume;
window.appResume = function(){ if(_resumeIA) _resumeIA(); window.appCompartilhado(); };

(function(){
  // Cartão em Mais
  const mais = document.getElementById('s-mais');
  const c = document.createElement('div'); c.id = 'ia-card'; c.className = 'card pad';
  c.style.cssText = 'display:flex;flex-direction:column;gap:12px';
  mais.insertBefore(c, mais.children[2] || null);
  // Botão em Finanças
  const fin = document.getElementById('s-financas');
  const b = document.createElement('button'); b.className = 'btn outline full'; b.id = 'ia-fin-btn';
  b.textContent = 'Analisar meus gastos com Claude / ChatGPT';
  b.onclick = () => abrirPerguntar(promptFinancas());
  const linhaBotoes = fin.querySelector('.row');
  linhaBotoes.insertAdjacentElement('afterend', b);

  const _r = render;
  render = function(){ _r(); if(!document.getElementById('ia-chave')) iaCard(); };
  iaCard();
  setTimeout(window.appCompartilhado, 600);
})();
