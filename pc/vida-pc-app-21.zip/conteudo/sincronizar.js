// =====================================================================
// v4.2 SINCRONIZAR (celular <-> PC). Carregado por último.
// Os dados vão para UM arquivo (vida.json) num repositório PRIVADO do GitHub do David,
// CRIPTOGRAFADOS no aparelho (AES-GCM 256, chave derivada da senha dele por PBKDF2 310 mil voltas).
// O GitHub só vê dados embaralhados. Token e senha ficam no cofre de cada aparelho (nunca em D).
//
// Como juntar sem perder nada:
//  - save() compara com a última "foto" e carimba o que mudou: item com id ganha _m; chave ganha D._mk[chave]
//    (objetos simples, como cfg, são carimbados por subchave: D._mk['cfg.tema']); item apagado vira lápide em D._apag.
//  - merge: listas com id -> item a item (o carimbo mais novo vence; lápide mais nova que o item apaga);
//    objetos -> subchave a subchave; o resto -> o carimbo mais novo vence.
//  - Conflito de gravação (o outro aparelho gravou no meio) -> o GitHub recusa pelo sha -> lê de novo e junta.
// =====================================================================
const SY_ARQ = 'vida.json';
const SY_FORA = new Set(['_salvoEm', '_mk', '_apag', 'pendNotif']);   // nunca sincroniza (pendNotif = fila deste celular)
const SY_CFG_LOCAL = new Set(['voz', 'hudVoz', 'backup', 'sync']);     // ajustes que são de cada aparelho
const SY_API = 'https://api.github.com/repos/';
let SY_FOTO = null, syRodando = false, syTimer = null, syChaveCache = null, syPendente = null;

// ---------- Foto e carimbos ----------
const syObj = v => !!v && typeof v === 'object' && !Array.isArray(v);
const syListaId = v => Array.isArray(v) && v.every(x => syObj(x) && (typeof x.id === 'string' || typeof x.id === 'number'));
function syJson(o){ if(!syObj(o) || !('_m' in o)) return JSON.stringify(o); const c = Object.assign({}, o); delete c._m; return JSON.stringify(c); }
function syFoto(d){
  const f = {};
  Object.keys(d).forEach(k => {
    if(SY_FORA.has(k)) return;
    const v = d[k];
    if(syListaId(v)) { const m = {}; v.forEach(x => { m[x.id] = syJson(x); }); f[k] = {t: 'a', m}; }
    else if(syObj(v)) { const m = {}; Object.keys(v).forEach(s => { if(!(k === 'cfg' && SY_CFG_LOCAL.has(s))) m[s] = JSON.stringify(v[s]); }); f[k] = {t: 'o', m}; }
    else f[k] = {t: 'v', j: JSON.stringify(v)};
  });
  return f;
}
function syCarimbar(){
  if(!SY_FOTO) { SY_FOTO = syFoto(D); return; }
  const agora = Date.now(), nova = syFoto(D);
  if(!syObj(D._mk)) D._mk = {};
  if(!syObj(D._apag)) D._apag = {};
  const chaves = new Set([...Object.keys(SY_FOTO), ...Object.keys(nova)]);
  chaves.forEach(k => {
    const a = SY_FOTO[k], b = nova[k];
    const mudou = !a || !b || a.t !== b.t || JSON.stringify(a) !== JSON.stringify(b);
    if(!mudou) return;
    D._mk[k] = agora;
    if(b && b.t === 'a'){
      const am = a && a.t === 'a' ? a.m : {};
      D[k].forEach(x => { if(am[x.id] !== b.m[x.id]) x._m = agora; });
      Object.keys(am).forEach(id => { if(!(id in b.m)) D._apag[id] = agora; });
    } else if(a && a.t === 'a'){
      Object.keys(a.m).forEach(id => { D._apag[id] = agora; });
    }
    if(b && b.t === 'o'){
      const am = a && a.t === 'o' ? a.m : {};
      new Set([...Object.keys(am), ...Object.keys(b.m)]).forEach(s => { if(am[s] !== b.m[s]) D._mk[k + '.' + s] = agora; });
    }
  });
  SY_FOTO = nova;
}

// ---------- Juntar dois estados ----------
function syJuntar(L, R){
  const M = {}, mkL = L._mk || {}, mkR = R._mk || {}, apag = {};
  [L._apag || {}, R._apag || {}].forEach(o => Object.keys(o).forEach(id => { apag[id] = Math.max(apag[id] || 0, o[id]); }));
  const vivo = x => !(x.id in apag) || (x._m || 0) > apag[x.id];
  const chaves = new Set([...Object.keys(L), ...Object.keys(R)]);
  chaves.forEach(k => {
    if(SY_FORA.has(k)) return;
    const a = L[k], b = R[k], ta = mkL[k] || 0, tb = mkR[k] || 0;
    if(syListaId(a) && syListaId(b)){
      const porId = new Map();
      a.forEach(x => porId.set(String(x.id), x));
      b.forEach(y => {
        const x = porId.get(String(y.id));
        if(!x) porId.set(String(y.id), y);
        else { const mx = x._m || 0, my = y._m || 0; if(my > mx || (my === mx && syJson(y) > syJson(x))) porId.set(String(y.id), y); }
      });
      M[k] = [...porId.values()].filter(vivo);
    } else if(syObj(a) && syObj(b)){
      const o = {};
      new Set([...Object.keys(a), ...Object.keys(b)]).forEach(s => {
        if(k === 'cfg' && SY_CFG_LOCAL.has(s)) { if(s in a) o[s] = a[s]; return; }
        const sa = mkL[k + '.' + s] || 0, sb = mkR[k + '.' + s] || 0;
        let v;
        if(sb > sa) v = b[s];
        else if(sa > sb) v = a[s];
        else v = (s in a) ? a[s] : b[s];   // nenhum dos dois mexeu depois de juntar: são iguais (ou só um tem)
        if(v !== undefined) o[s] = v;
      });
      M[k] = o;
    } else {
      const v = tb > ta ? b : (ta > tb ? a : (a !== undefined ? a : b));
      if(v !== undefined) M[k] = v;
    }
  });
  // Mesmo lançamento do banco importado nos dois aparelhos antes de sincronizar: fica um só
  if(Array.isArray(M.lanc)){
    const visto = new Map();
    M.lanc = M.lanc.filter(l => {
      if(!l.pluggyId) return true;
      const outro = visto.get(l.pluggyId);
      if(!outro) { visto.set(l.pluggyId, l); return true; }
      apag[l.id] = Math.max(apag[l.id] || 0, Date.now(), (l._m || 0) + 1);
      return false;
    });
  }
  const mk = Object.assign({}, mkL);
  Object.keys(mkR).forEach(c => { mk[c] = Math.max(mk[c] || 0, mkR[c]); });
  const limite = Date.now() - 90 * 864e5;   // lápides somem depois de 90 dias
  Object.keys(apag).forEach(id => { if(apag[id] < limite) delete apag[id]; });
  M._mk = mk; M._apag = apag;
  ['_salvoEm', 'pendNotif'].forEach(k => { if(k in L) M[k] = L[k]; });
  return M;
}
// Conteúdo que importa (para saber se mudou): sem o que é só deste aparelho, chaves em ordem e listas por id
function syNuvem(d){ const c = Object.assign({}, d); delete c._salvoEm; delete c.pendNotif; if(syObj(c.cfg)){ c.cfg = Object.assign({}, c.cfg); SY_CFG_LOCAL.forEach(s => delete c.cfg[s]); } return c; }
function syCanon(v){
  if(Array.isArray(v)){ const l = v.map(syCanon); return syListaId(v) ? l.sort((a, b) => String(a.id) < String(b.id) ? -1 : String(a.id) > String(b.id) ? 1 : 0) : l; }
  if(syObj(v)){ const o = {}; Object.keys(v).sort().forEach(k => { o[k] = syCanon(v[k]); }); return o; }
  return v;
}
const syAssinatura = d => JSON.stringify(syCanon(syNuvem(d)));

// ---------- Criptografia ----------
const syB64 = u8 => { let s = ''; for(let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); };
const syDeB64 = s => { const b = atob(String(s).replace(/\s/g, '')); const u = new Uint8Array(b.length); for(let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; };
async function syGz(u8, abrir){
  if(typeof CompressionStream === 'undefined') return u8;
  const s = new Blob([u8]).stream().pipeThrough(abrir ? new DecompressionStream('gzip') : new CompressionStream('gzip'));
  return new Uint8Array(await new Response(s).arrayBuffer());
}
async function syChave(senha, sal){
  const k = senha + '|' + syB64(sal);
  if(syChaveCache && syChaveCache.k === k) return syChaveCache.c;
  const base = await crypto.subtle.importKey('raw', new TextEncoder().encode(senha), 'PBKDF2', false, ['deriveKey']);
  const c = await crypto.subtle.deriveKey({name: 'PBKDF2', salt: sal, iterations: 310000, hash: 'SHA-256'}, base, {name: 'AES-GCM', length: 256}, false, ['encrypt', 'decrypt']);
  syChaveCache = {k, c}; return c;
}
async function syFechar(obj, senha, salAntigo){
  const sal = salAntigo || crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
  const gz = typeof CompressionStream !== 'undefined';
  let bytes = new TextEncoder().encode(JSON.stringify(syNuvem(obj))); if(gz) bytes = await syGz(bytes, false);
  const ct = new Uint8Array(await crypto.subtle.encrypt({name: 'AES-GCM', iv}, await syChave(senha, sal), bytes));
  return {vida: 1, kdf: 'pbkdf2-sha256', it: 310000, sal: syB64(sal), iv: syB64(iv), gz, dados: syB64(ct), em: Date.now()};
}
async function syAbrir(env, senha){
  if(!env || env.vida !== 1) throw new Error('arquivo');
  const sal = syDeB64(env.sal);
  let bytes;
  try { bytes = new Uint8Array(await crypto.subtle.decrypt({name: 'AES-GCM', iv: syDeB64(env.iv)}, await syChave(senha, sal), syDeB64(env.dados))); }
  catch(e){ throw new Error('senha'); }
  if(env.gz) bytes = await syGz(bytes, true);
  return {dados: JSON.parse(new TextDecoder().decode(bytes)), sal};
}

// ---------- GitHub ----------
const syCfg = () => { if(!syObj(D.cfg.sync)) D.cfg.sync = {}; return D.cfg.sync; };
const syToken = () => cofre.get('sync_token') || '';
const sySenha = () => cofre.get('sync_senha') || '';
const syCab = () => ({'Authorization': 'Bearer ' + syToken(), 'Accept': 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28'});
async function syGh(metodo, caminho, corpo){
  const r = await http(metodo, SY_API + syCfg().repo + caminho, syCab(), corpo);
  let j = null; try { j = JSON.parse(r.body || 'null'); } catch(e){}
  return {status: r.status, j};
}
async function syLer(){
  const r = await syGh('GET', '/contents/' + SY_ARQ);
  if(r.status === 404) return null;
  if(r.status !== 200) throw new Error('gh' + r.status);
  let b64 = r.j.content;
  if(!b64 && r.j.sha){ const bl = await syGh('GET', '/git/blobs/' + r.j.sha); if(bl.status !== 200) throw new Error('gh' + bl.status); b64 = bl.j.content; }
  return {sha: r.j.sha, env: JSON.parse(new TextDecoder().decode(syDeB64(b64)))};
}
async function syGravar(env, sha){
  const corpo = {message: 'Vida: sincroniza (' + syAparelho() + ')', content: syB64(new TextEncoder().encode(JSON.stringify(env)))};
  if(sha) corpo.sha = sha;
  const r = await syGh('PUT', '/contents/' + SY_ARQ, corpo);
  if(r.status === 200 || r.status === 201) return true;
  if(r.status === 409 || r.status === 422) return false;   // outro aparelho gravou no meio: lê de novo
  throw new Error('gh' + r.status);
}
const syAparelho = () => (window.Android && Android.plataforma && Android.plataforma() === 'pc') ? 'PC' : 'celular';
function syMsgErro(e){
  const m = String(e && e.message || e);
  if(m === 'senha') return 'A senha não abre os dados da nuvem. Use a mesma senha do outro aparelho.';
  if(m === 'gh401' || m === 'gh403') return 'O GitHub recusou o token. Gere outro com acesso de escrita ao repositório.';
  if(m === 'gh404') return 'Repositório não encontrado. Confira o nome (dono/repositório) e o acesso do token.';
  if(/erroApp|gh0/.test(m)) return 'Sem internet agora. Tento de novo depois.';
  return 'Não deu para sincronizar (' + m + ').';
}

// ---------- Ciclo ----------
const syAtivo = () => !!(syCfg().repo && syCfg().ativo && NATIVO && syToken() && sySenha());
const syOcupado = () => !!sheetTipo || (document.activeElement && /INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName));
function syAplicar(M){
  const local = {}; SY_FORA.forEach(k => { if(k in D && k !== '_mk' && k !== '_apag') local[k] = D[k]; });
  const cfgLocal = {}; SY_CFG_LOCAL.forEach(s => { if(D.cfg && s in D.cfg) cfgLocal[s] = D.cfg[s]; });
  D = Object.assign(vazio(), M, local);
  D.cfg = Object.assign({}, D.cfg || {}, cfgLocal);
  normalizar();
  SY_FOTO = syFoto(D);
  syGravarLocal();
  try { if(typeof corAplicar === 'function') corAplicar(); if(typeof temaAplicar === 'function') temaAplicar(); } catch(e){}
  render();
}
let syGravarLocal = () => {};
async function sincronizar(manual){
  if(syRodando) return;
  if(!syAtivo()) { if(manual) toast('Ative a sincronização em Ajustes'); return; }
  syRodando = true; syEstado('Sincronizando…');
  try {
    syCarimbar(); syGravarLocal();
    for(let tentativa = 0; tentativa < 4; tentativa++){
      const remoto = await syLer();
      if(!remoto){   // nuvem vazia: este aparelho é o primeiro
        if(await syGravar(await syFechar(D, sySenha()), null)) break; else continue;
      }
      const {dados: R, sal} = await syAbrir(remoto.env, sySenha());
      const M = syJuntar(D, R);
      const mudouAqui = syAssinatura(M) !== syAssinatura(D);
      if(mudouAqui){
        if(syOcupado() && !manual) { syPendente = true; syEstado('Mudanças do outro aparelho esperando você terminar de digitar'); syRodando = false; return; }
        syAplicar(M);
      }
      if(syAssinatura(M) === syAssinatura(R)) break;   // a nuvem já está igual
      if(await syGravar(await syFechar(M, sySenha(), sal), remoto.sha)) break;
    }
    const c = syCfg(); c.ultima = Date.now(); c.erro = null; syPendente = false; syGravarLocal();
    syEstado(null);
    if(manual) toast('Sincronizado');
  } catch(e){
    const c = syCfg(); c.erro = syMsgErro(e); syGravarLocal();
    syEstado(null);
    if(manual || e.message === 'senha') toast(c.erro);
  }
  syRodando = false;
}
function syAgendar(){ if(!syAtivo()) return; clearTimeout(syTimer); syTimer = setTimeout(() => sincronizar(false), 12000); }

// ---------- Ativar (primeira vez em cada aparelho) ----------
async function syAtivar(){
  const repo = (val('sy-repo') || '').trim().replace(/^https?:\/\/github\.com\//, '').replace(/\.git$/, '').replace(/\/$/, '');
  const token = (val('sy-token') || '').trim(), s1 = val('sy-senha') || '', s2 = val('sy-senha2') || '';
  if(!/^[\w.-]+\/[\w.-]+$/.test(repo)) return toast('Repositório no formato dono/nome');
  if(token.length < 20) return toast('Cole o token do GitHub');
  if(s1.length < 8) return toast('A senha precisa de pelo menos 8 caracteres');
  if(s1 !== s2) return toast('As duas senhas estão diferentes');
  cofre.set('sync_token', token); cofre.set('sync_senha', s1);
  const c = syCfg(); c.repo = repo; c.ativo = false; syGravarLocal();
  syEstado('Conferindo o repositório…');
  try {
    const info = await syGh('GET', '');
    if(info.status !== 200) throw new Error('gh' + info.status);
    if(!info.j.private) { syEstado(null); return toast('Esse repositório é PÚBLICO. Use um repositório privado.'); }
    const remoto = await syLer();
    if(!remoto){ c.ativo = true; c.desde = Date.now(); syGravarLocal(); syEstado(null); await sincronizar(true); syCardRender(); return; }
    const {dados: R} = await syAbrir(remoto.env, s1);
    syPendente = R; syEstado(null); syCardRender();
  } catch(e){ syEstado(null); c.erro = syMsgErro(e); syGravarLocal(); syCardRender(); toast(c.erro); }
}
// A nuvem já tem dados: o David escolhe usar os de lá (aparelho novo) ou juntar os dois
async function syPrimeira(modo){
  const R = syPendente; if(!R || !syObj(R)) return;
  try { localStorage.setItem('vida.antesSync', JSON.stringify(D)); } catch(e){}
  const c = syCfg(); c.ativo = true; c.desde = Date.now();
  if(modo === 'nuvem'){ syAplicar(Object.assign({}, R)); }
  else { syCarimbar(); syAplicar(syJuntar(D, R)); }
  syPendente = null; syCfg().ativo = true; syCfg().desde = c.desde; syGravarLocal();
  await sincronizar(true); syCardRender();
}
function syDesligar(){
  if(!confirm('Parar de sincronizar neste aparelho? Os dados daqui continuam aqui.')) return;
  const c = syCfg(); c.ativo = false; cofre.set('sync_token', ''); cofre.set('sync_senha', ''); syChaveCache = null; syGravarLocal(); syCardRender();
}

// ---------- Tela (Ajustes → Sincronizar) ----------
function syEstado(t){ const e = document.getElementById('sy-estado'); if(e){ e.textContent = t || ''; e.style.display = t ? '' : 'none'; } }
function syQuando(ts){ if(!ts) return 'nunca'; const m = Math.round((Date.now() - ts) / 60000); return m < 1 ? 'agora' : m < 60 ? 'há ' + m + ' min' : new Date(ts).toLocaleString('pt-BR', {day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit'}); }
function syCardHTML(){
  const c = syCfg();
  if(!NATIVO) return '<div class="card pad sub">Disponível no app instalado (celular ou PC).</div>';
  let h = '<div class="card pad" style="display:flex;flex-direction:column;gap:10px">';
  h += '<div class="sub" id="sy-estado" style="display:none"></div>';
  if(syObj(syPendente)){
    const n = k => Array.isArray(syPendente[k]) ? syPendente[k].length : 0;
    h += '<b>A nuvem já tem dados do Vida</b><div class="sub">Lá: ' + n('tarefas') + ' tarefas, ' + n('lanc') + ' lançamentos, ' + n('contas') + ' contas. Aqui: ' + D.tarefas.length + ' tarefas, ' + D.lanc.length + ' lançamentos.</div>' +
      '<button class="btn primary full" onclick="syPrimeira(\'nuvem\')">Usar os dados da nuvem neste aparelho</button>' +
      '<button class="btn outline full" onclick="syPrimeira(\'juntar\')">Juntar com os deste aparelho</button>' +
      '<div class="sub">Aparelho novo (como o PC na 1ª vez): use os da nuvem. O que está aqui agora fica guardado como cópia.</div>';
  } else if(c.ativo){
    h += '<div><b>Sincronização ligada</b><div class="sub">Repositório ' + esc(c.repo) + ' · última: ' + syQuando(c.ultima) + '</div></div>';
    if(c.erro) h += '<div class="aviso-atraso">' + esc(c.erro) + '</div>';
    h += '<button class="btn outline full" onclick="sincronizar(true)">Sincronizar agora</button>' +
      '<button class="btn danger" style="align-self:flex-start" onclick="syDesligar()">Parar neste aparelho</button>';
  } else {
    h += '<div class="sub">Os mesmos dados no celular e no PC. Ficam num repositório <b>privado</b> do seu GitHub, <b>criptografados</b> com a sua senha: nem o GitHub consegue ler. Faça isto uma vez em cada aparelho, com o mesmo repositório e a mesma senha.</div>' +
      '<label class="f">Repositório (dono/nome)<input id="sy-repo" value="' + esc(c.repo || 'davidcardozowow-cmd/vida-dados') + '" autocapitalize="off" spellcheck="false"></label>' +
      '<label class="f">Token do GitHub<input id="sy-token" type="password" autocomplete="off" placeholder="github_pat_..."></label>' +
      '<label class="f">Senha dos dados (mín. 8)<input id="sy-senha" type="password" autocomplete="new-password"></label>' +
      '<label class="f">Repita a senha<input id="sy-senha2" type="password" autocomplete="new-password"></label>' +
      '<div class="sub">Guarde essa senha: sem ela os dados da nuvem não abrem (o backup semanal continua no aparelho).</div>' +
      (c.erro ? '<div class="aviso-atraso">' + esc(c.erro) + '</div>' : '') +
      '<button class="btn primary full" onclick="syAtivar()">Ativar</button>' +
      '<details class="mais-op" open><summary><span>Preparar no GitHub</span><small class="mais-res">3 min, uma vez só</small></summary><div class="mais-corpo sub" style="display:flex;flex-direction:column;gap:6px">' +
      '<div><b>A. Repositório:</b> abra <a href="#" onclick="syLink(\'https://github.com/new?name=vida-dados&visibility=private\');return false">github.com/new</a>, nome <b>vida-dados</b>, marque <b>Private</b> e toque em Create repository.</div>' +
      '<div><b>B. Token:</b> abra <a href="#" onclick="syLink(\'https://github.com/settings/personal-access-tokens/new\');return false">Fine-grained token</a>. Nome: Vida. Validade: a maior que aparecer.</div>' +
      '<div>Repository access: <b>Only select repositories</b> → vida-dados.</div>' +
      '<div>Permissions → Repository → <b>Contents: Read and write</b>.</div>' +
      '<div>Generate token, copie e cole aqui. Guarde o token e a senha: no PC você usa os mesmos.</div></div></details>';
  }
  return h + '</div>';
}
function syLink(u){ try { if(window.Android && Android.openUrl) return Android.openUrl(u); } catch(e){} window.open(u, '_blank'); }
function syCardRender(){ const e = document.getElementById('sy-card'); if(e) e.innerHTML = syCardHTML(); }
function syMontarAjuste(){
  const box = document.getElementById('aj-grupos'); if(!box || document.getElementById('aj-sync')) return;
  const g = document.createElement('details'); g.className = 'aj-grupo'; g.id = 'aj-sync';
  g.innerHTML = '<summary><div style="display:flex;flex-direction:column">Sincronizar celular e PC<span>Mesmos dados nos dois, criptografados</span></div></summary><div class="aj-corpo"><div id="sy-card"></div></div>';
  const conta = document.getElementById('aj-conta');
  if(conta) box.insertBefore(g, conta); else box.appendChild(g);
  g.addEventListener('toggle', () => { if(g.open) syCardRender(); });
  syCardRender();
}

(function(){
  // Gravar local sem carimbar (usado pela sincronização) e save() com carimbo + agendamento
  const _save = save;
  syGravarLocal = () => _save();
  save = function(){ try { syCarimbar(); } catch(e){} _save(); syAgendar(); };
  SY_FOTO = syFoto(D);
  syMontarAjuste();
  const _res = window.appResume;
  window.appResume = function(){ if(_res) _res(); if(syAtivo()) sincronizar(false); };
  // Terminou de digitar e havia mudanças do outro aparelho esperando
  const _close = closeSheet;
  closeSheet = function(){ _close(); if(syPendente === true) setTimeout(() => sincronizar(false), 300); };
  setInterval(() => { if(syAtivo() && document.visibilityState !== 'hidden') sincronizar(false); }, 5 * 60000);
  setTimeout(() => { if(syAtivo()) sincronizar(false); }, 2500);
})();
