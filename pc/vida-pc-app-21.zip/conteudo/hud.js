// =====================================================================
// Visual HUD (v2.9): painel de assistente, limpo, com funções exclusivas:
// 1. Painel de status (anel do dia, relógio, situação em uma frase, indicadores).
// 2. Briefing falado (TextToSpeech do celular, offline; nada sai do aparelho).
// 3. Comandos por voz ou texto (navegar, anotar tarefa, registrar gasto/entrada, foco...).
//    Gasto e entrada SEMPRE abrem o formulário preenchido para o David confirmar.
// 4. Alertas proativos (até 3, com ação de um toque).
// 5. Modo conforme a hora: planejar (manhã), foco (tarde), fechar o dia (noite).
// Ativo só com D.cfg.visual === 'hud' (body.hud). Depende de index.html, arena.js, ia.js, noticias.js.
// =====================================================================

window.PLUS_HUD = '<svg width="58" height="58" viewBox="0 0 58 58"><circle cx="29" cy="29" r="27" fill="#05090F" stroke="#4FD8FF" stroke-width="1.5"/>' +
  '<circle cx="29" cy="29" r="21" fill="none" stroke="#4FD8FF" stroke-opacity=".35" stroke-width="1" stroke-dasharray="3 4"/>' +
  '<path d="M29 20v18M20 29h18" stroke="#E6F7FF" stroke-width="2.6" stroke-linecap="round"/></svg>';

const HUD_DIAS = ['domingo','segunda-feira','terça-feira','quarta-feira','quinta-feira','sexta-feira','sábado'];
const semAcento = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();

// ---------- Números do dia ----------
function hudDia(){
  const h = hoje();
  const feitasHoje = D.tarefas.filter(t => t.feita && t.feitaEm === h);
  const paraHj = paraHoje();
  const atrasadas = pendentes().filter(t => t.data && t.data < h);
  const contas = contasAbertas().filter(c => c.venc <= addDias(h, 7));
  const rot = D.habitos.length, rotFeita = (D.habFeitos[h] || []).filter(id => D.habitos.some(x => x.id === id)).length;
  const total = feitasHoje.length + paraHj.length;
  const pct = total ? Math.round(feitasHoje.length / total * 100) : (rot ? Math.round(rotFeita / rot * 100) : 0);
  const novasNot = (typeof ntNovas === 'function') ? ntNovas('tudo') : 0;
  return {h, feitasHoje, paraHj, atrasadas, contas, rot, rotFeita, pct, novasNot};
}
function hudSituacao(d){
  const p = [];
  if(d.paraHj.length) p.push(d.paraHj.length + (d.paraHj.length > 1 ? ' tarefas para hoje' : ' tarefa para hoje'));
  else p.push('nenhuma tarefa pendente para hoje');
  const prox = d.contas[0];
  if(prox) p.push(prox.desc + ' vence ' + quando(prox.venc).toLowerCase().replace(/^(\d)/, 'em $1'));
  const s = p.join(', ');
  return s.charAt(0).toUpperCase() + s.slice(1) + '.';
}
function hudPontos(){
  if(typeof diaEstado !== 'function') return '';
  const e = diaEstado();
  let g = ''; for(let i = 0; i < e.total; i++) g += '<i class="' + (i < e.passados ? 'p' : i === e.passados && !e.antes && !e.depois ? 'a' : '') + '"></i>' + (i % 4 === 3 ? '<b></b>' : '');
  const txt = e.depois ? 'Dia útil encerrado' : e.antes ? 'Dia útil começa às ' + e.c.ini : 'Faltam ' + fmtMin(e.resta) + ' de dia útil' + (e.tarefas ? (e.tarefas <= e.resta ? ' · tarefas cabem' : ' · tarefas não cabem') : '');
  return '<div class="hud-tempo"><span>' + txt + '</span><div class="hud-dots">' + g + '</div></div>';
}

// ---------- 1. Painel ----------
function hudPainel(){
  const el = document.getElementById('hud-painel'); if(!el) return;
  const d = hudDia(), agora = new Date(), hr = agora.getHours();
  const r = 44, C = 2 * Math.PI * r, off = C * (1 - d.pct / 100);
  el.innerHTML =
    '<div class="hud-topo">' +
      '<div class="hud-anel"><svg width="104" height="104" viewBox="0 0 104 104">' +
        '<circle cx="52" cy="52" r="' + r + '" fill="none" stroke="rgba(79,216,255,.12)" stroke-width="6"/>' +
        '<circle cx="52" cy="52" r="' + r + '" fill="none" stroke="#4FD8FF" stroke-width="6" stroke-linecap="round" stroke-dasharray="' + C.toFixed(1) + '" stroke-dashoffset="' + off.toFixed(1) + '" transform="rotate(-90 52 52)"/>' +
        '<circle cx="52" cy="52" r="34" fill="none" stroke="rgba(79,216,255,.18)" stroke-width="1" stroke-dasharray="2 5"/></svg>' +
        '<div class="hud-anel-tx"><b>' + d.pct + '%</b><span>FEITO</span></div></div>' +
      '<div class="hud-hora"><div class="hud-relogio" id="hud-relogio">' + pad2(hr) + ':' + pad2(agora.getMinutes()) + '</div>' +
        '<div class="hud-data">' + DIAS[agora.getDay()] + ' · ' + agora.getDate() + ' ' + MESES[agora.getMonth()].slice(0, 3).toUpperCase() + '</div>' +
        '<div class="hud-ola">' + (hr < 12 ? 'Bom dia' : hr < 18 ? 'Boa tarde' : 'Boa noite') + ', ' + esc(D.nome || 'você') + '</div></div>' +
    '</div>' +
    '<p class="hud-sit">' + esc(hudSituacao(d)) + '</p>' + hudPontos() +
    '<button class="hud-brief" id="hud-brief" onclick="hudBriefing()">' + (hudFalando ? '■ Parar' : '▶ Briefing do dia') + '</button>';
}
setInterval(() => {
  const el = document.getElementById('hud-relogio'); if(!el || !document.body.classList.contains('hud')) return;
  const a = new Date(); el.textContent = pad2(a.getHours()) + ':' + pad2(a.getMinutes());
}, 20000);

// ---------- 2. Briefing falado ----------
let hudFalando = false;
window.__falaCb = function(estado){
  hudFalando = estado === 'inicio';
  if(estado === 'erro') toast('Seu celular não tem voz em português instalada. Veja em Configurações → Acessibilidade → Saída de texto para fala.');
  const b = document.getElementById('hud-brief'); if(b) b.textContent = hudFalando ? '■ Parar' : '▶ Briefing do dia';
};
// Fala: sempre com a voz do celular (motor escolhido pelo David; nada pago).
function falar(t){ if(NATIVO && Android.speak) Android.speak(t); }
function pararFala(silencioso){
  if(NATIVO && Android.stopSpeak) Android.stopSpeak();
  if(!silencioso) window.__falaCb('fim');
}
// Briefing curto (pesquisa: ponto de execução, ~3 frases). Os detalhes ficam para um segundo toque.
// Com voz online (o texto vai para um servidor), contas são faladas sem valor em R$.
function vozOnline(){ return !!(D.cfg.voz && D.cfg.voz.rede); }
function hudBriefingTexto(){
  const d = hudDia(), hr = new Date().getHours(), p = [];
  p.push((hr < 12 ? 'Bom dia' : hr < 18 ? 'Boa tarde' : 'Boa noite') + ', ' + (D.nome || '') + '.');
  const plano = hudPlanoHoje(), f = foco();
  if(plano) p.push('Seu plano: quando ' + plano.quando + ', então ' + plano.entao + '.');
  else if(f) p.push('Agora: ' + (proxPasso(f) ? proxPasso(f).t + ', para ' + f.titulo : f.titulo) + '.');
  else p.push('Nada pendente agora.');
  const urg = hudMaisUrgente(d); if(urg) p.push(urg);
  p.push('Quer os detalhes? Toque em ouvir detalhes.');
  return p.join(' ');
}
function hudMaisUrgente(d){
  const c = d.contas.find(x => x.venc <= addDias(d.h, 1));
  if(c) return c.desc + ' vence ' + quando(c.venc).toLowerCase() + (vozOnline() ? '.' : ', ' + brl(c.valor) + '.');
  if(typeof vdParaHoje === 'function' && vdParaHoje().length){ const v = vdParaHoje(); return v.length > 1 ? v.length + ' clientes para contatar hoje.' : 'Contatar ' + v[0].nome + ' hoje.'; }
  if(d.atrasadas.length) return d.atrasadas.length > 1 ? d.atrasadas.length + ' tarefas atrasadas.' : 'Uma tarefa atrasada.';
  return '';
}
function hudDetalhesTexto(){
  const d = hudDia(), p = [];
  if(d.paraHj.length) p.push('Você tem ' + d.paraHj.length + (d.paraHj.length > 1 ? ' tarefas' : ' tarefa') + ' para hoje' + (d.feitasHoje.length ? ' e já concluiu ' + d.feitasHoje.length : '') + '.');
  if(d.atrasadas.length) p.push(d.atrasadas.length > 1 ? d.atrasadas.length + ' estão atrasadas.' : 'Uma está atrasada.');
  if(typeof vdParaHoje === 'function' && vdParaHoje().length){ const v = vdParaHoje(); p.push('Clientes para hoje: ' + v.slice(0, 3).map(c => c.nome).join(', ') + '.'); }
  d.contas.slice(0, 2).forEach(c => p.push(c.desc + ' vence ' + quando(c.venc).toLowerCase() + (vozOnline() ? '.' : ', ' + brl(c.valor) + '.')));
  if(d.rot) p.push('Rotina: ' + d.rotFeita + ' de ' + d.rot + '.');
  if(D.pendNotif && D.pendNotif.length) p.push(D.pendNotif.length > 1 ? D.pendNotif.length + ' gastos para confirmar.' : 'Um gasto para confirmar.');
  if(typeof ntDaCat === 'function'){ const t = ntDaCat('tudo')[0]; if(t) p.push('Manchete: ' + ((NT.trad[t.id] || {}).t || t.t) + '.'); }
  return p.join(' ') || 'Nada mais por agora.';
}
function hudDetalhes(){ const t = hudDetalhesTexto(), el = document.getElementById('hud-brief-det'); if(el){ el.textContent = t; el.style.display = ''; } falar(t); }
function hudBriefing(){
  if(hudFalando){ pararFala(); hudFalando = false; hudPainel(); return; }
  const t = hudBriefingTexto();
  if(NATIVO && Android.speak){ falar(t); hudFalando = true; hudPainel(); }
  openSheet('hud-briefing'); document.getElementById('hud-brief-tx').textContent = t;
}

// ---------- 3. Comandos ----------
const HUD_TELAS = {noticias:'noticias', tarefas:'tarefas', missoes:'tarefas', financas:'financas', dinheiro:'financas', inicio:'inicio', mais:'mais', configuracoes:'mais', aprender:'aprender'};
function hudResponder(msg){ toast(msg); if(D.cfg.hudVoz) falar(msg); }
function hudComando(txt){
  const orig = String(txt || '').trim(); if(!orig) return;
  const s = semAcento(orig).replace(/[.!?]+$/, '');
  let m;
  // Navegar
  if((m = s.match(/^(?:abrir|abre|ir para|ir pra|vai para|vai pra|mostrar|mostra|ver)?\s*(?:as |a |o |os )?(noticias|tarefas|missoes|financas|dinheiro|inicio|mais|configuracoes|aprender)$/))){
    go(HUD_TELAS[m[1]]); hudResponder('Abrindo ' + m[1] + '.'); return;
  }
  if(/^(briefing|resumo do dia|como (esta|ta) (o |meu )?dia|status)$/.test(s)){ go('inicio'); hudBriefing(); return; }
  if(/^(detalhes|mais detalhes|o resto)$/.test(s)){ go('inicio'); hudBriefing(); hudDetalhes(); return; }
  if(/^(fechar|encerrar|finalizar) o dia$/.test(s)){ go('inicio'); openSheet('hud-fechar'); return; }
  if(/^(planejar|planeja) o dia$/.test(s)){ go('inicio'); hudBriefing(); return; }
  if(/^(so a missao|modo foco total)$/.test(s)){ entrarSoMissao(); return; }
  if(/^(foco|focar|iniciar foco|comecar foco)$/.test(s)){
    const f = foco(); if(!f){ hudResponder('Nada pendente para focar agora.'); return; }
    go('inicio'); openSheet('foco', f.id); return;
  }
  // Gasto: "gastei 45 no mercado", "paguei 120,50 de luz"
  if((m = s.match(/^(?:gastei|gasto|paguei|comprei)\s+(?:r\$\s*)?([\d.,]+)\s*(?:reais|real|conto|contos)?(?:\s+(?:no|na|nos|nas|em|de|do|da|com|pra|para)\s+(.+))?$/))){
    return hudLanc('gasto', m[1], m[2] || '');
  }
  if((m = s.match(/^(?:recebi|ganhei|entrou|entraram)\s+(?:r\$\s*)?([\d.,]+)\s*(?:reais|real)?(?:\s+(?:de|do|da|com|no|na)\s+(.+))?$/))){
    return hudLanc('entrada', m[1], m[2] || '');
  }
  // Tarefa: "tarefa ...", "me lembra de ...", "anotar ..."
  if((m = orig.match(/^\s*(?:tarefa|nova tarefa|lembrar de|lembra de|me lembra de|me lembre de|anotar|anota|preciso)\s*:?\s+(.+)$/i))){
    return hudTarefa(m[1]);
  }
  // Qualquer outra coisa: a IA grátis organiza (se estiver ligada)
  if(typeof iaPronta === 'function' && iaPronta()){ hudIA(orig); return; }
  hudResponder('Não entendi. Tente: "tarefa ligar pro cliente amanhã", "gastei 45 no mercado", "abrir notícias" ou "briefing".');
}
function hudLanc(tipo, valor, desc){
  const v = lerValor(valor);
  if(!(v > 0)){ hudResponder('Não entendi o valor.'); return; }
  go('financas'); openSheet(tipo);
  document.getElementById('f-valor').value = String(v).replace('.', ',');
  const ds = desc ? desc.charAt(0).toUpperCase() + desc.slice(1) : '';
  document.getElementById('f-desc').value = ds;
  if(tipo === 'gasto' && ds && typeof mapCat === 'function'){ const c = mapCat('', ds); const sel = document.getElementById('f-cat'); if(sel && CATS.includes(c)) sel.value = c; }
  hudResponder('Confira e toque em Salvar.');
}
function hudTarefa(texto){
  if(typeof iaPronta === 'function' && iaPronta()){ hudIA(texto); return; }
  let t = texto.trim(), data = hoje();
  const ns = semAcento(t);
  if(/(^|\s)amanha(?=\s|$)/.test(ns)){ data = addDias(hoje(), 1); t = t.replace(/(^|\s)amanh[ãa](?=\s|$)/i, ' ').replace(/\s+/g, ' ').trim(); }
  else if(/(^|\s)hoje(?=\s|$)/.test(ns)){ t = t.replace(/(^|\s)hoje(?=\s|$)/i, ' ').replace(/\s+/g, ' ').trim(); }
  t = t.charAt(0).toUpperCase() + t.slice(1);
  D.tarefas.push({id:uid(), titulo:t.slice(0, 120), area:'pes', data, feita:false, status:'todo', passos:[], criada:Date.now()});
  save(); render(); hudResponder('Tarefa anotada para ' + quando(data).toLowerCase() + '.');
}
function hudIA(texto){
  openSheet('ia-anotar');
  document.getElementById('f-ialivre').value = texto;
  if(typeof iaOrganizar === 'function') iaOrganizar();
}
function hudOuvir(){
  if(!NATIVO || !Android.listen){ toast('A voz funciona no app instalado'); return; }
  Android.listen('Fale o comando');
}
window.__vozCb = function(texto, erro){
  if(erro === 'indisponivel'){ toast('Reconhecimento de voz indisponível. Instale ou ative o app Google.'); return; }
  if(!texto) return;
  const inp = document.getElementById('hud-cmd-in'); if(inp) inp.value = texto;
  hudComando(texto);
  if(inp) setTimeout(() => { inp.value = ''; }, 1500);
};
function hudEnviar(){ const inp = document.getElementById('hud-cmd-in'); const t = inp.value; inp.value = ''; inp.blur(); hudComando(t); }

// ---------- 4. Alertas ----------
function hudAlertas(){
  const el = document.getElementById('hud-alertas'); if(!el) return;
  const d = hudDia(), al = [];
  if(d.atrasadas.length) al.push({t:d.atrasadas.length + (d.atrasadas.length > 1 ? ' tarefas atrasadas' : ' tarefa atrasada'), s:d.atrasadas[0].titulo, b:'Trazer para hoje', f:'hudTrazerHoje()'});
  contasAbertas().filter(c => c.venc <= addDias(d.h, 2)).slice(0, 2).forEach(c =>
    al.push({t:c.desc + ' vence ' + quando(c.venc).toLowerCase(), s:brl(c.valor), b:'Paguei', f:'pagarConta(\'' + c.id + '\')', warn:c.venc <= d.h}));
  if(typeof vdParaHoje === 'function'){ const v = vdParaHoje(); if(v.length) al.push({t:v.length + (v.length > 1 ? ' clientes para contatar' : ' cliente para contatar'), s:v.slice(0, 3).map(c => c.nome).join(', '), b:'Ver', f:'vista=\'clientes\';go(\'tarefas\')'}); }
  if(D.pendNotif && D.pendNotif.length) al.push({t:D.pendNotif.length + (D.pendNotif.length > 1 ? ' gastos capturados' : ' gasto capturado'), s:'Esperando sua confirmação', b:'Ver', f:'go(\'financas\')'});
  el.innerHTML = '<div class="hud-rot">Alertas</div>' + (al.length
    ? al.slice(0, 2).map(a => '<div class="hud-al' + (a.warn ? ' warn' : '') + '"><span class="hud-dot"></span><div><b>' + esc(a.t) + '</b><span>' + esc(a.s) + '</span></div><button onclick="' + a.f + '">' + a.b + '</button></div>').join('')
      + (al.length > 2 ? '<button class="hud-mais" onclick="hudTodosAlertas()">+ ' + (al.length - 2) + (al.length > 3 ? ' alertas' : ' alerta') + '</button>' : '')
    : '<div class="hud-al ok"><span class="hud-dot"></span><div><b>Tudo em ordem</b><span>Nenhum alerta agora.</span></div></div>');
  hudAlertasTodos = al;
}
let hudAlertasTodos = [];
function hudTodosAlertas(){
  const el = document.getElementById('hud-alertas');
  el.innerHTML = '<div class="hud-rot">Alertas</div>' + hudAlertasTodos.map(a => '<div class="hud-al' + (a.warn ? ' warn' : '') + '"><span class="hud-dot"></span><div><b>' + esc(a.t) + '</b><span>' + esc(a.s) + '</span></div><button onclick="' + a.f + '">' + a.b + '</button></div>').join('');
}
function hudTrazerHoje(){ const h = hoje(); pendentes().filter(t => t.data && t.data < h).forEach(t => t.data = h); save(); render(); hudResponder('Atrasadas trazidas para hoje.'); }

// ---------- 5. Modo conforme a hora ----------
function hudModo(){
  const el = document.getElementById('hud-modo'); if(!el) return;
  const hr = new Date().getHours(), fechado = D.hudFechado === hoje();
  el.classList.remove('vazio');
  let rot, tit, sub, bt, fn;
  const plano = hudPlanoHoje();
  if(hr < 12 && plano){ rot = 'Seu plano de ontem'; tit = 'Quando ' + plano.quando; sub = 'Então: ' + plano.entao; bt = 'Começar'; fn = 'openSheet(\'foco\',\'' + plano.tarefa.id + '\')'; }
  else if(hr < 18){ el.classList.add('vazio'); el.innerHTML = ''; return; }
  else if(hr < 18){ rot = 'Tarde'; tit = 'Foco'; const f = foco(); sub = f ? 'Próxima: ' + f.titulo : 'Nada pendente. Aproveite para adiantar algo.'; bt = f ? 'Focar 25 min' : 'Anotar tarefa'; fn = f ? 'openSheet(\'foco\',\'' + f.id + '\')' : 'openSheet(\'tarefa\')'; }
  else { rot = 'Noite'; tit = fechado ? 'Dia fechado' : 'Fechar o dia'; sub = fechado ? 'Prioridade de amanhã definida. Descanse.' : 'Veja o que fez, passe o resto para amanhã e escolha a prioridade.'; bt = fechado ? 'Rever' : 'Fechar o dia'; fn = 'openSheet(\'hud-fechar\')'; }
  el.innerHTML = '<div class="hud-rot">' + rot + '</div><div class="between" style="align-items:center;gap:12px"><div style="min-width:0"><b class="hud-modo-t">' + esc(tit) + '</b><span class="sub" style="display:block">' + esc(sub) + '</span></div>' +
    '<button class="btn outline" style="flex-shrink:0" onclick="' + fn + '">' + bt + '</button></div>';
}
function hudFecharHTML(){
  const d = hudDia(), amanha = addDias(d.h, 1);
  const sobra = pendentes().filter(t => t.data && t.data <= d.h);
  const opcoes = pendentes().filter(t => !t.data || t.data <= amanha).sort(ordenar);
  return '<h2>Fechar o dia</h2>' +
    '<div class="hud-rot">Feito hoje · ' + d.feitasHoje.length + '</div>' +
    '<div class="card" style="padding:4px 16px">' + (d.feitasHoje.length ? d.feitasHoje.map(t => '<div class="item done"><span class="txt">' + esc(t.titulo) + '</span></div>').join('') : '<div class="empty">Nada marcado como feito hoje. Amanhã é outro dia.</div>') + '</div>' +
    '<div class="hud-rot">Ficou para depois · ' + sobra.length + '</div>' +
    (sobra.length ? '<button class="btn outline full" onclick="hudEmpurrar()">Passar ' + sobra.length + (sobra.length > 1 ? ' tarefas' : ' tarefa') + ' para amanhã</button>' : '<p class="note" style="margin:0">Nada sobrando.</p>') +
    '<div class="hud-rot">Prioridade de amanhã</div>' +
    (opcoes.length ? '<label class="f"><select id="hud-prio" onchange="hudEntao()">' + opcoes.map(t => '<option value="' + t.id + '">' + esc(t.titulo) + '</option>').join('') + '</select></label>'
      : '<p class="note" style="margin:0">Sem tarefas abertas. Anote uma se quiser.</p>') +
    '<label class="f">Plano para começar: quando eu…<input id="hud-quando" placeholder="Ex.: chegar no trabalho / terminar o café" value="' + esc((D.planoSeEntao && D.planoSeEntao.quando) || '') + '"></label>' +
    '<p class="note" id="hud-entao" style="margin:-6px 0 0">' + esc(hudEntaoTexto(opcoes[0] && opcoes[0].id)) + '</p>' +
    '<div class="hud-rot">Como foi o dia?</div>' +
    '<div class="hud-humor">' + HUMORES.map((h, i) => '<button class="' + (((D.humor || {})[d.h]) === i + 1 ? 'on' : '') + '" onclick="hudHumor(' + (i + 1) + ')"><span>' + h[0] + '</span>' + h[1] + '</button>').join('') + '</div>' +
    '<button class="btn primary full" onclick="hudFechar()">Fechar o dia</button>';
}
function hudEntaoTexto(id){
  const t = D.tarefas.find(x => x.id === id); if(!t) return '';
  return '…então eu: ' + (proxPasso(t) ? proxPasso(t).t : t.titulo) + '. Decidir agora o gatilho ajuda a começar amanhã sem pensar.';
}
function hudEntao(){ const el = document.getElementById('hud-entao'); if(el) el.textContent = hudEntaoTexto(val('hud-prio')); }
const HUMORES = [['😣','Péssimo'],['🙁','Ruim'],['😐','Ok'],['🙂','Bom'],['😄','Ótimo']];
function hudHumor(n){
  if(!D.humor || typeof D.humor !== 'object') D.humor = {};
  D.humor[hoje()] = n;
  Object.keys(D.humor).filter(k => k < addDias(hoje(), -120)).forEach(k => delete D.humor[k]);
  save(); document.querySelectorAll('.hud-humor button').forEach((b, i) => b.classList.toggle('on', i === n - 1));
}
function hudPlanoHoje(){
  const p = D.planoSeEntao; if(!p || p.data !== hoje()) return null;
  const t = D.tarefas.find(x => x.id === p.tarefa && !x.feita); if(!t) return null;
  const passo = proxPasso(t);
  return {quando: p.quando, entao: passo ? passo.t : t.titulo, tarefa: t};
}
function hudEmpurrar(){
  const h = hoje(), am = addDias(h, 1);
  pendentes().filter(t => t.data && t.data <= h).forEach(t => t.data = am);
  save(); render(); openSheet('hud-fechar'); toast('Passadas para amanhã');
}
function hudFechar(){
  const id = val('hud-prio'), am = addDias(hoje(), 1);
  if(id){
    const t = D.tarefas.find(x => x.id === id);
    if(t){ D.tarefas.forEach(x => { if(x.status === 'doing' && !x.feita && x.id !== id) x.status = 'todo'; }); t.data = am; t.status = 'doing'; }
    const quandoTx = (val('hud-quando') || '').trim();
    D.planoSeEntao = quandoTx ? {data: am, quando: quandoTx, tarefa: id} : null;
  }
  const primeira = D.hudFechado !== hoje();
  D.hudFechado = hoje(); save(); closeSheet(); render();
  if(primeira && typeof ganharXP === 'function') ganharXP(10, 'dia fechado');
  hudResponder('Dia fechado. Amanhã começa pela prioridade que você escolheu. Descanse.');
}


// ---------- Voz do assistente: motor, voz, velocidade e tom (vozes do próprio celular) ----------
const VOZ_FRASE = 'Olá, ' + '{nome}' + '. Esta é a voz do seu assistente. Tudo em ordem por aqui.';
function vozCfg(){ D.cfg.voz = Object.assign({motor:'', nome:'', vel:1, tom:1}, D.cfg.voz || {}); return D.cfg.voz; }
function vozAplicar(){ const v = vozCfg(); if(NATIVO && Android.setVoice) Android.setVoice(v.motor || '', v.nome || '', +v.vel || 1, +v.tom || 1); }
let VOZES = null;
window.__vozesCb = function(j){ try { VOZES = j ? JSON.parse(j) : {motores:[], vozes:[]}; } catch(e){ VOZES = {motores:[], vozes:[]}; } vozCard(); };
function vozRotulo(v){
  const m = v.nome.match(/x-([a-z]{3})/i), cod = m ? m[1].toUpperCase() : v.nome.split(/[-_#]/).slice(-2).join(' ');
  const pais = /pt[-_]?br|bra/i.test(v.local) ? 'Brasil' : /pt[-_]?pt|prt/i.test(v.local) ? 'Portugal' : v.local;
  return {t:'Voz ' + cod + ' · ' + pais, s:(v.rede ? 'online, mais natural' : 'offline') + (v.qualidade >= 400 ? ' · alta qualidade' : '') + (v.instalada ? '' : ' · precisa baixar')};
}
function vozOuvir(nome){
  const v = vozCfg();
  if(NATIVO && Android.setVoice) Android.setVoice(v.motor || '', nome, +v.vel || 1, +v.tom || 1);
  falar(VOZ_FRASE.replace('{nome}', D.nome || 'David'));
}
function vozEscolher(nome){ vozCfg().nome = nome; vozCfg().rede = !!((VOZES && VOZES.vozes.find(x => x.nome === nome)) || {}).rede; save(); vozAplicar(); vozCard(); falar(VOZ_FRASE.replace('{nome}', D.nome || 'David')); }
function vozMotor(pkg){ const v = vozCfg(); v.motor = pkg; v.nome = ''; v.rede = false; save(); vozAplicar(); VOZES = null; vozCard(); if(NATIVO && Android.listVoices) Android.listVoices(); }
function vozAjuste(campo, valor){ vozCfg()[campo] = Math.round(parseFloat(valor) * 100) / 100; save(); vozAplicar(); const l = document.getElementById('voz-' + campo + '-v'); if(l) l.textContent = (+valor).toFixed(2).replace('.', ','); }
function vozMordomo(){ const v = vozCfg(); v.vel = 0.9; v.tom = 0.82; save(); vozAplicar(); vozCard(); falar('Às suas ordens, ' + (D.nome || 'David') + '. Seu dia está organizado.'); }
function vozPadrao(){ D.cfg.voz = {motor:'', nome:'', vel:1, tom:1, rede:false}; save(); vozAplicar(); VOZES = null; vozCard(); if(NATIVO && Android.listVoices) Android.listVoices(); }
function vozCard(){
  const c = document.getElementById('voz-card'); if(!c) return;
  if(!hudAtivo()){ c.style.display = 'none'; return; }
  c.style.display = 'flex';
  const v = vozCfg();
  let lista;
  if(!NATIVO) lista = '<p class="note" style="margin:0">Disponível no app instalado.</p>';
  else if(!VOZES) lista = '<button class="btn outline full" onclick="VOZES=null;Android.listVoices();this.textContent=\'Buscando vozes…\'">Ver vozes do celular</button>';
  else {
    const vs = VOZES.vozes.slice().sort((a, b) => (/br/i.test(b.local) - /br/i.test(a.local)) || (b.rede - a.rede) || (b.qualidade - a.qualidade));
    lista = (VOZES.motores.length > 1 ? '<label class="f">Motor de voz<select onchange="vozMotor(this.value)"><option value="">Padrão do celular</option>' + VOZES.motores.map(m => '<option value="' + esc(m.pkg) + '"' + (m.pkg === v.motor ? ' selected' : '') + '>' + esc(m.nome) + '</option>').join('') + '</select></label>' : '') +
      (vs.length ? '<div class="card" style="padding:4px 14px">' + vs.map(x => { const r = vozRotulo(x), on = x.nome === v.nome;
        return '<div class="item"><span class="txt" onclick="vozEscolher(\'' + esc(x.nome) + '\')">' + (on ? '● ' : '') + esc(r.t) + '<small>' + esc(r.s) + '</small></span><button class="pill" onclick="vozOuvir(\'' + esc(x.nome) + '\')">Ouvir</button>' +
          (on ? '' : '<button class="pill" onclick="vozEscolher(\'' + esc(x.nome) + '\')">Usar</button>') + '</div>'; }).join('') + '</div>'
        : '<p class="note" style="margin:0">Nenhuma voz em português neste motor. Escolha outro motor ou baixe vozes em Configurações → Acessibilidade → Saída de texto para fala.</p>');
  }
  c.innerHTML = '<h2>Voz do assistente</h2>' +
    '<p class="note" style="margin:0"><b>Voz mais natural de graça:</b> instale o app <b>SherpaTTS</b> (gratuito, sem internet depois de baixar a voz), escolha a voz em português do Brasil <b>faber</b> ou <b>cadu</b> (masculinas) e depois selecione SherpaTTS em "Motor de voz" aqui embaixo.</p>' +
    '<button class="btn outline full" onclick="Android.openUrl(\'https://f-droid.org/pt_BR/packages/org.woheller69.ttsengine/\')">Baixar o SherpaTTS (F-Droid)</button>' +
    '<p class="note" style="margin:0">As vozes do Google marcadas como <b>online</b> também soam melhor, mas mandam o texto para o servidor do Google: com elas, o briefing fala das contas sem dizer valores.</p>' +
    lista +
    '<label class="f">Velocidade · <span id="voz-vel-v">' + (+v.vel).toFixed(2).replace('.', ',') + '</span><input type="range" min="0.6" max="1.4" step="0.05" value="' + v.vel + '" oninput="vozAjuste(\'vel\',this.value)" style="height:auto;padding:0;border:0!important;background:transparent!important"></label>' +
    '<label class="f">Tom (mais grave ← → mais agudo) · <span id="voz-tom-v">' + (+v.tom).toFixed(2).replace('.', ',') + '</span><input type="range" min="0.6" max="1.4" step="0.02" value="' + v.tom + '" oninput="vozAjuste(\'tom\',this.value)" style="height:auto;padding:0;border:0!important;background:transparent!important"></label>' +
    '<div class="row"><button class="btn primary" style="flex:1" onclick="vozMordomo()">Estilo mordomo</button><button class="btn outline" style="flex:1" onclick="falar(VOZ_FRASE.replace(\'{nome}\', D.nome || \'David\'))">Testar</button></div>' +
    '<button class="btn outline full" onclick="vozPadrao()">Voltar ao padrão</button>';
}

// ---------- Integração ----------
(function(){
  const inicio = document.getElementById('s-inicio');
  const painel = document.createElement('div'); painel.id = 'hud-painel'; painel.className = 'hud-so hud-painel';
  const cmd = document.createElement('div'); cmd.id = 'hud-cmd'; cmd.className = 'hud-so hud-cmd';
  cmd.innerHTML = '<input id="hud-cmd-in" placeholder="Diga ou digite um comando" autocomplete="off" enterkeyhint="send">' +
    '<button class="hud-mic" aria-label="Falar" onclick="hudOuvir()"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/></svg></button>';
  const alertas = document.createElement('div'); alertas.id = 'hud-alertas'; alertas.className = 'hud-so hud-alertas';
  const modo = document.createElement('div'); modo.id = 'hud-modo'; modo.className = 'hud-so hud-modo';
  inicio.insertBefore(painel, inicio.firstChild);
  painel.insertAdjacentElement('afterend', cmd);
  cmd.insertAdjacentElement('afterend', alertas);
  const sm = document.getElementById('sm-sair') || document.getElementById('focus');
  sm.insertAdjacentElement('afterend', modo);
  cmd.querySelector('input').addEventListener('keydown', e => { if(e.key === 'Enter') hudEnviar(); });

  const _f = formHTML;
  formHTML = function(tipo, id){
    if(tipo === 'hud-briefing') return '<h2>Briefing</h2><p class="hud-brief-tx" id="hud-brief-tx"></p><p class="hud-brief-tx" id="hud-brief-det" style="color:var(--muted);display:none"></p>' +
      '<div class="row"><button class="btn primary" style="flex:1" onclick="hudDetalhes()">Ouvir detalhes</button>' +
      '<button class="btn outline" style="flex:1" onclick="pararFala();closeSheet()">Fechar</button></div>';
    if(tipo === 'hud-fechar') return hudFecharHTML();
    return _f(tipo, id);
  };

  // Configuração: respostas faladas (só no HUD)
  const _vc = visualCard;
  visualCard = function(){
    _vc();
    const c = document.getElementById('visual-card'); if(!c || !hudAtivo()) return;
    const l = document.createElement('label'); l.className = 'row'; l.style.cssText = 'font-size:15px;font-weight:600';
    l.innerHTML = '<input type="checkbox" style="width:22px;height:22px" ' + (D.cfg.hudVoz ? 'checked' : '') + ' onchange="D.cfg.hudVoz=this.checked;save()"> Responder os comandos em voz alta';
    c.insertBefore(l, c.children[3] || null);
  };

  const vc = document.createElement('div'); vc.id = 'voz-card'; vc.className = 'card pad';
  vc.style.cssText = 'display:none;flex-direction:column;gap:12px';
  const vis = document.getElementById('visual-card'); vis.insertAdjacentElement('afterend', vc);
  vozAplicar();

  const _r = render;
  render = function(){ _r(); if(hudAtivo()){ hudPainel(); hudAlertas(); hudModo(); } if(tela === 'mais') vozCard(); else { const c = document.getElementById('voz-card'); if(c && !hudAtivo()) c.style.display = 'none'; } };
  // O arena.js aplica o visual antes de o HUD existir: reaplica para o botão + e as barras do sistema
  if(hudAtivo()) aplicarVisual(); else render();
})();
