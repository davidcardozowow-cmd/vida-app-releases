// =====================================================================
// v4.3 MINHA SEMANA: revisão de 2 minutos (sábado a segunda).
// Últimos 7 dias em números visuais (tarefas por dia, rotina, gastos vs. semana anterior, clientes)
// e UMA pergunta: a coisa mais importante da próxima semana -> vira tarefa em foco na segunda.
// Bloco 'sem-card' no Início (some quando a semana já foi revisada). D.semanas[segunda] = {em, prioridade}.
// Finanças ficam no aparelho (nada vai para IA).
// =====================================================================
function semSegunda(){ const d = parseD(hoje()), dow = d.getDay(); return addDias(hoje(), dow === 1 ? 0 : (8 - dow) % 7 || 7); }  // próxima segunda (ou hoje, se for segunda)
function semDias(fim, n){ const r = []; for(let i = n - 1; i >= 0; i--) r.push(addDias(fim, -i)); return r; }
function semDados(){
  const dias = semDias(hoje(), 7), ant = semDias(addDias(hoje(), -7), 7), ini = dias[0];
  const feitas = D.tarefas.filter(t => t.feita && t.feitaEm && t.feitaEm >= ini);
  const porDia = dias.map(d => feitas.filter(t => t.feitaEm === d).length);
  const porArea = {}; feitas.forEach(t => { porArea[t.area] = (porArea[t.area] || 0) + 1; });
  const hab = D.habitos.length ? Math.round(100 * dias.reduce((s, d) => s + (D.habFeitos[d] || []).filter(id => D.habitos.some(h => h.id === id)).length, 0) / (D.habitos.length * 7)) : null;
  const gasto = ds => D.lanc.filter(l => !l.interno && l.tipo !== 'in' && ds.includes(l.data)).reduce((s, l) => s + l.valor, 0);
  const atrasadas = D.tarefas.filter(t => !t.feita && t.data && t.data < hoje()).length;
  const clientes = (D.clientes || []).filter(c => c.ultimo && c.ultimo >= ini).length;
  return {dias, porDia, feitas: feitas.length, porArea, hab, gasto: gasto(dias), gastoAnt: gasto(ant), atrasadas, clientes};
}
function semCardHTML(){
  const s = semDados(), feito = D.semanas && D.semanas[semSegunda()];
  return '<div class="ini-corpo"><div class="apr-topo"><span class="apr-ico"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="17" rx="3"/><path d="M3 9h18M8 2v4M16 2v4"/><path d="M8 14l2.5 2.5L16 12"/></svg></span>' +
    '<span style="flex:1;min-width:0"><b>Minha semana</b><small>' + (feito ? 'Revisada · prioridade definida' : '2 minutos para fechar a semana') + '</small></span><span class="apr-pct">' + s.feitas + '</span></div>' +
    semBarras(s) + '<span class="ini-cta">' + (feito ? 'Rever' : 'Revisar agora') + '</span></div>';
}
function semBarras(s){
  const mx = Math.max(1, ...s.porDia), L = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'];
  return '<div class="sem-barras">' + s.dias.map((d, i) => '<div><span style="height:' + Math.max(4, Math.round(44 * s.porDia[i] / mx)) + 'px" class="' + (s.porDia[i] ? 'ok' : '') + '"></span><small>' + L[parseD(d).getDay()] + '</small></div>').join('') + '</div>';
}
function semHTML(){
  const s = semDados(), seg = semSegunda(), r = (D.semanas || {})[seg];
  const dif = s.gastoAnt ? Math.round(100 * (s.gasto - s.gastoAnt) / s.gastoAnt) : null;
  const fmt = d => { const x = parseD(d); return pad2(x.getDate()) + '/' + pad2(x.getMonth() + 1); };
  const areas = Object.entries(s.porArea).sort((a, b) => b[1] - a[1]).map(([a, n]) => '<span class="chip">' + esc((AREAS[a] || {}).nome || a) + ' · ' + n + '</span>').join('');
  return '<h2>Minha semana</h2><div class="sub" style="margin-top:-8px">' + fmt(s.dias[0]) + ' a ' + fmt(s.dias[6]) + '</div>' +
    '<div class="card pad"><div class="between"><b>Tarefas concluídas</b><b style="font-size:22px">' + s.feitas + '</b></div>' + semBarras(s) +
      (areas ? '<div class="row" style="flex-wrap:wrap;gap:6px;margin-top:10px">' + areas + '</div>' : '') + '</div>' +
    '<div class="sem-grade">' +
      (s.hab !== null ? '<div class="card pad"><small class="sub">Rotina</small><b class="sem-num">' + s.hab + '%</b><div class="fc-barra"><span style="width:' + s.hab + '%"></span></div></div>' : '') +
      '<div class="card pad"><small class="sub">Gastos</small><b class="sem-num">' + brl(s.gasto) + '</b><small class="sub">' + (dif === null ? 'sem semana anterior' : (dif > 0 ? '▲ ' + dif + '% que a anterior' : dif < 0 ? '▼ ' + (-dif) + '% que a anterior' : 'igual à anterior')) + '</small></div>' +
      ((D.clientes || []).length ? '<div class="card pad"><small class="sub">Clientes contatados</small><b class="sem-num">' + s.clientes + '</b></div>' : '') +
      '<div class="card pad"><small class="sub">Atrasadas</small><b class="sem-num">' + s.atrasadas + '</b>' + (s.atrasadas ? '<button class="btn outline" style="height:34px;padding:0 14px;font-size:13px;align-self:flex-start" onclick="closeSheet();vista=\'lista\';go(\'tarefas\')">Ver</button>' : '<small class="sub">nenhuma</small>') + '</div>' +
    '</div>' +
    '<label class="f">A coisa mais importante da próxima semana<input id="sem-prio" maxlength="120" placeholder="Ex.: fechar a proposta da Atlas" value="' + esc(r && r.prioridade || '') + '"></label>' +
    '<button class="btn primary full" onclick="semSalvar()">' + (r ? 'Atualizar prioridade' : 'Fechar a semana') + '</button>' +
    '<div class="sub">Vira uma tarefa para segunda, já como foco.</div>';
}
function semSalvar(){
  const p = (val('sem-prio') || '').trim(); if(!p) return toast('Escreva a prioridade da semana');
  const seg = semSegunda(); D.semanas = D.semanas || {};
  const r = D.semanas[seg] || {};
  let t = r.tarefa && D.tarefas.find(x => x.id === r.tarefa);
  if(t) t.titulo = p;
  else { t = {id: uid(), titulo: p, area: 'pes', data: seg, feita: false, status: 'doing', passos: [], criada: Date.now()}; D.tarefas.push(t); }
  D.semanas[seg] = {em: hoje(), prioridade: p, tarefa: t.id};
  Object.keys(D.semanas).filter(k => k < addDias(hoje(), -120)).forEach(k => delete D.semanas[k]);
  save(); closeSheet(); render(); toast('Semana fechada. Segunda começa com: ' + p);
}
function semMostrar(){ const dow = new Date().getDay(); return dow === 6 || dow === 0 || dow === 1; }
(function(){
  const inicio = document.getElementById('s-inicio');
  const ban = document.createElement('button'); ban.id = 'sem-card'; ban.className = 'card ini-card'; ban.style.display = 'none';
  ban.onclick = () => openSheet('semana');
  inicio.appendChild(ban);
  BLOCOS['sem-card'] = {nome: 'Minha semana', desc: 'Revisão de sábado a segunda', temas: ['classico', 'arena', 'hud']};
  if(D.cfg.inicio && Array.isArray(D.cfg.inicio.ordem) && !D.cfg.inicio.ordem.includes('sem-card')){
    const o = D.cfg.inicio.ordem, k = Math.max(o.indexOf('hud-alertas'), o.indexOf('focus')); o.splice(k >= 0 ? k + 1 : o.length, 0, 'sem-card');
  }
  [typeof INICIO_PADRAO === 'object' && INICIO_PADRAO, typeof INICIO_V4 === 'object' && INICIO_V4].forEach(P => {
    if(P && !P.ordem.includes('sem-card')){ const k = Math.max(P.ordem.indexOf('hud-alertas'), P.ordem.indexOf('focus')); P.ordem.splice(k + 1, 0, 'sem-card'); }
  });
  const _f = formHTML;
  formHTML = function(tipo, id){ return tipo === 'semana' ? semHTML() : _f(tipo, id); };
  const _r = render;
  render = function(){
    _r();
    const b = document.getElementById('sem-card'); if(!b) return;
    const oculto = D.cfg.inicio && D.cfg.inicio.ocultos && D.cfg.inicio.ocultos['sem-card'];
    b.style.display = !oculto && semMostrar() ? '' : 'none';
    if(b.style.display !== 'none') b.innerHTML = semCardHTML();
  };
  render();
})();
