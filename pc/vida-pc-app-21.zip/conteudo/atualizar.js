// =====================================================================
// Atualização pela internet: aviso no Início + cartão em "Mais".
// A parte nativa (Atualizador.java) baixa do GitHub, confere o SHA-256
// e chama o instalador do Android. Depende de: NATIVO, toast, esc, render.
// =====================================================================

const UPD_KEY = 'vida.upd';
let UPD = {ultimaVerificacao: 0, disponivel: null};
try { UPD = Object.assign(UPD, JSON.parse(localStorage.getItem(UPD_KEY) || '{}')); } catch(e) {}
let updEstado = '', updMsg = '';
function updSalvar(){ try{ localStorage.setItem(UPD_KEY, JSON.stringify(UPD)); }catch(e){} }

window.__updCheck = (id, json) => {
  let r = {}; try { r = JSON.parse(json); } catch(e) {}
  const manual = id === 'manual';
  UPD.ultimaVerificacao = Date.now();
  if(r.erro){ if(manual) toast(r.erro); }
  else if(r.tem){ UPD.disponivel = {versao: r.versionName, notas: r.notas}; if(manual) toast('Versão ' + r.versionName + ' disponível'); }
  else { UPD.disponivel = null; if(manual) toast('Você já está na versão mais nova'); }
  updEstado = ''; updSalvar(); updRender();
};
window.__updCb = (estado, msg) => {
  updEstado = estado; updMsg = msg;
  if(estado === 'ok'){ UPD.disponivel = null; updSalvar(); }
  if(estado === 'erro' || estado === 'permissao' || estado === 'nada') toast(msg);
  updRender();
};

function updVerificar(manual){
  if(!NATIVO || !Android.checkUpdate){ if(manual) toast('Disponível só no app instalado'); return; }
  if(manual){ updEstado = 'verificando'; updRender(); }
  Android.checkUpdate(manual ? 'manual' : 'auto');
}
function updInstalar(){
  if(!NATIVO || !Android.installUpdate){ toast('Disponível só no app instalado'); return; }
  updEstado = 'baixando'; updMsg = 'Preparando...'; updRender();
  Android.installUpdate();
}

function updRender(){
  const versao = NATIVO && Android.appVersion ? Android.appVersion() : '—';
  const d = UPD.disponivel;
  const ocupado = updEstado === 'baixando' || updEstado === 'instalando' || updEstado === 'verificando';
  // Cartão em Mais
  const card = document.getElementById('upd-card');
  if(card){
    const quando = UPD.ultimaVerificacao ? new Date(UPD.ultimaVerificacao) : null;
    card.innerHTML = '<h2>Atualizações</h2>'+
      '<p class="note" style="margin:0">Você está na versão <b>'+esc(versao)+'</b>.'+(quando ? ' Última verificação: '+quando.toLocaleDateString('pt-BR')+' às '+String(quando.getHours()).padStart(2,'0')+':'+String(quando.getMinutes()).padStart(2,'0')+'.' : '')+'</p>'+
      (d ? '<div style="background:var(--accent-soft);border-radius:14px;padding:12px 14px;font-size:14px;line-height:1.5"><b>Nova versão '+esc(d.versao)+'</b>'+(d.notas ? '<br>'+esc(d.notas) : '')+'</div>' : '')+
      (updMsg && ocupado ? '<p class="note" style="margin:0;font-weight:700">'+esc(updMsg)+'</p>' : '')+
      (d ? '<button class="btn primary" '+(ocupado?'disabled':'')+' onclick="updInstalar()">'+(ocupado ? 'Aguarde...' : 'Atualizar agora')+'</button>'
         : '<button class="btn outline" '+(ocupado?'disabled':'')+' onclick="updVerificar(true)">'+(updEstado==='verificando' ? 'Verificando...' : 'Procurar atualização')+'</button>');
  }
  // Aviso no Início
  const ban = document.getElementById('upd-banner');
  if(ban){
    ban.style.display = d ? 'flex' : 'none';
    if(d) ban.innerHTML = '<span style="flex:1"><b style="font-size:15px;display:block">Nova versão '+esc(d.versao)+'</b><span class="sub" style="color:inherit;opacity:.85">'+esc(d.notas || 'Toque para atualizar')+'</span></span>'+
      '<span class="pill" style="background:#fff;color:var(--accent);border:0;display:flex;align-items:center;font-weight:700">'+(ocupado ? 'Aguarde' : 'Atualizar')+'</span>';
  }
}

(function(){
  const mais = document.getElementById('s-mais');
  const card = document.createElement('div');
  card.id = 'upd-card'; card.className = 'card pad';
  card.style.cssText = 'display:flex;flex-direction:column;gap:12px';
  mais.insertBefore(card, mais.children[2] || null);

  const inicio = document.getElementById('s-inicio');
  const ban = document.createElement('button');
  ban.id = 'upd-banner';
  ban.style.cssText = 'display:none;border:0;border-radius:18px;padding:14px 16px;align-items:center;gap:12px;text-align:left;background:var(--accent);color:#fff';
  ban.onclick = () => updInstalar();
  inicio.insertBefore(ban, inicio.children[1] || null);

  const _r = render;
  render = function(){ _r(); updRender(); };
  updRender();
  // Verifica sozinho ao abrir, no máximo a cada 6 horas.
  if(NATIVO && Date.now() - (UPD.ultimaVerificacao || 0) > 6 * 3600000) setTimeout(() => updVerificar(false), 3000);
})();
