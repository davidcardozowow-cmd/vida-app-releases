// =====================================================================
// VIDA 4 (v4.0): um desenho só, menos coisa por tela, módulos que liga/desliga.
// Carregado por ÚLTIMO: reorganiza a estrutura que os módulos anteriores criaram.
// - Aparência: escuro (padrão) ou claro do MESMO desenho (hud.css). Arena/Clássico saem da escolha.
//   As funções do antigo HUD (briefing, comando, alertas, fechar o dia) passam a ser do app todo.
// - Hoje: topo compacto (data, saudação, briefing, ajustes) + barra fina do dia; o Foco é o único destaque;
//   "Atenção" com até 3 linhas sem caixas.
// - Barra de baixo: Hoje, Tarefas, +, Finanças, Notícias. Ajustes pela engrenagem.
// - Ajustes em grupos recolhíveis; Módulos (D.cfg.modulos) somem do app quando desligados.
// Depende de: quase todos os módulos (index.html, arena.js, hud.js, evolucao.js, vendas.js, inicio.js,
//             lembretes.js, treino.js). Migração única: D.cfg.v4.
// =====================================================================

const MODULOS = [
  ['noticias', 'Notícias',              'Aba de notícias na barra de baixo'],
  ['clientes', 'Clientes',              'Follow-up de vendas em Tarefas'],
  ['treino',   'Treino do cérebro',     'Sessões de estudo e flashcards'],
  ['dividas',  'Plano de dívidas',      'Ordem para quitar, em Finanças'],
  ['voz',      'Voz e comandos',        'Briefing falado e comando por voz'],
  ['aprender', 'Aprender a usar IA',    'Lições curtas sobre IA']
];
function modCfg(){
  D.cfg.modulos = Object.assign({noticias:true, clientes:true, treino:true, aprender:true, voz:true,
    dividas: Array.isArray(D.dividas) && D.dividas.length > 0}, D.cfg.modulos || {});
  return D.cfg.modulos;
}
function modOn(k){ return modCfg()[k] !== false; }
function modAplicar(){ const m = modCfg(); MODULOS.forEach(([k]) => document.body.classList.toggle('sem-' + k, m[k] === false)); }
function modMudar(k, on){
  modCfg()[k] = !!on; save(); modAplicar();
  if(typeof lbEnviar === 'function') lbEnviar(true);
  if(!on && tela === ({noticias:'noticias', treino:'treino', aprender:'aprender'})[k]) go('inicio');
  render();
}

// ---------- Migração única para o Vida 4 ----------
const INICIO_V4 = {
  ordem:['hud-painel','focus','hud-alertas','hud-modo','tr-card','rotina','vd-banner','hud-cmd','hoje','tiles','nt-banner','apr-banner','saudacao','arena-perfil','dia-pontos'],
  ocultos:{'tr-card':true, rotina:true, 'vd-banner':true, 'hud-cmd':true, hoje:true, tiles:true, 'nt-banner':true, 'apr-banner':true}
};
function v4Migrar(){
  if(D.cfg.v4) return false;
  D.cfg.tema = D.cfg.visual === 'classico' ? 'claro' : 'escuro';
  D.cfg.visual = 'hud';
  D.cfg.inicio = JSON.parse(JSON.stringify(INICIO_V4));
  modCfg();
  D.cfg.v4 = true; save();
  return true;
}

// ---------- Aparência ----------
function temaAplicar(){
  const claro = D.cfg.tema === 'claro';
  document.body.classList.add('hud'); document.body.classList.remove('arena');
  document.body.classList.toggle('claro', claro);
  try{
    if(claro){ if(window.Android && Android.setBars) Android.setBars(false); }
    else if(window.Android && Android.setBarColor) Android.setBarColor('#0B0F14');
  }catch(e){}
  const plus = document.querySelector('nav .plus');
  if(plus) plus.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke-width="2.4" stroke-linecap="round"><path d="M12 5v14" stroke="currentColor"/><path d="M5 12h14" stroke="currentColor"/></svg>';
}
function mudarTema(t){ D.cfg.tema = t; save(); temaAplicar(); render(); }

// ---------- Hoje ----------
function v4Painel(){
  const el = document.getElementById('hud-painel'); if(!el) return;
  const a = new Date(), hr = a.getHours(), d = hudDia();
  const DS = ['Domingo','Segunda','Terça','Quarta','Quinta','Sexta','Sábado'];
  let dia = '';
  if(typeof diaEstado === 'function'){
    const e = diaEstado(), total = e.total * 15, passou = Math.min(total, e.passados * 15), cabe = !e.tarefas || e.tarefas <= e.resta;
    const txt = e.depois ? 'Dia útil encerrado' : e.antes ? 'Seu dia começa às ' + e.c.ini : 'Faltam <b>' + fmtMin(e.resta) + '</b> de dia';
    const tar = e.tarefas && !e.depois ? '<span class="' + (cabe ? '' : 'nao') + '">' + fmtMin(e.tarefas) + ' de tarefas' + (cabe ? '' : ' · não cabe') + '</span>' : '';
    const largT = total ? Math.min(100 - passou / total * 100, e.tarefas / total * 100) : 0;
    dia = '<div class="v4-dia"><div class="v4-dia-tx"><span>' + txt + '</span>' + tar + '</div>' +
      '<div class="v4-barra" role="img" aria-label="Quanto do dia já passou"><i style="width:' + (total ? passou / total * 100 : 0).toFixed(1) + '%"></i>' +
      (largT > 0 ? '<em style="left:' + (total ? passou / total * 100 : 0).toFixed(1) + '%;width:' + largT.toFixed(1) + '%"></em>' : '') + '</div></div>';
  }
  el.innerHTML =
    '<div class="v4-topo"><div style="min-width:0"><div class="v4-data">' + DS[a.getDay()] + ', ' + a.getDate() + ' de ' + MESES[a.getMonth()] + '</div>' +
      '<h1 class="v4-ola">' + (hr < 12 ? 'Bom dia' : hr < 18 ? 'Boa tarde' : 'Boa noite') + ', ' + esc(D.nome || 'você') + '</h1></div>' +
      '<div class="v4-acoes">' +
        '<button class="v4-ico' + (hudFalando ? ' on' : '') + '" id="v4-brief" aria-label="Briefing falado" onclick="hudBriefing()">' + (hudFalando
          ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="6" width="12" height="12" rx="2"/></svg>'
          : '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H3v6h3l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/></svg>') + '</button>' +
        '<button class="v4-ico" id="v4-ajustes" aria-label="Ajustes" onclick="go(\'mais\')"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg></button>' +
      '</div></div>' + dia;
}
// Atenção: até 3 linhas, sem caixas; some quando não há nada
function v4Alertas(){
  const el = document.getElementById('hud-alertas'); if(!el) return;
  const d = hudDia(), al = [];
  contasAbertas().filter(c => c.venc <= addDias(d.h, 2)).slice(0, 2).forEach(c =>
    al.push({t:c.desc + ' vence ' + quando(c.venc).toLowerCase(), s:brl(c.valor), b:'Paguei', f:'pagarConta(\'' + c.id + '\')', warn:true}));
  if(modOn('clientes') && typeof vdParaHoje === 'function'){ const v = vdParaHoje(); if(v.length) al.push({t:v.length > 1 ? v.length + ' clientes para contatar' : 'Contatar ' + v[0].nome, s:v.slice(0, 3).map(c => (c.prox && c.prox.t) || c.nome).join(', '), b:'Ver', f:'vista=\'clientes\';go(\'tarefas\')'}); }
  if(d.atrasadas.length) al.push({t:d.atrasadas.length > 1 ? d.atrasadas.length + ' tarefas atrasadas' : '1 tarefa atrasada', s:d.atrasadas[0].titulo, b:'Para hoje', f:'hudTrazerHoje()'});
  if(D.pendNotif && D.pendNotif.length) al.push({t:D.pendNotif.length > 1 ? D.pendNotif.length + ' gastos para confirmar' : '1 gasto para confirmar', s:'Capturado das notificações', b:'Ver', f:'go(\'financas\')'});
  hudAlertasTodos = al;
  el.classList.toggle('vazio', !al.length);
  el.innerHTML = al.length ? '<div class="hud-rot">Atenção</div>' + al.slice(0, 3).map(a => '<div class="hud-al' + (a.warn ? ' warn' : '') + '"><span class="hud-dot"></span><div><b>' + esc(a.t) + '</b><span>' + esc(a.s) + '</span></div><button onclick="' + a.f + '">' + a.b + '</button></div>').join('') +
    (al.length > 3 ? '<button class="hud-mais" onclick="hudTodosAlertas()">Ver mais ' + (al.length - 3) + '</button>' : '') : '';
}

// ---------- Ajustes em grupos ----------
function ajModulosHTML(){
  const m = modCfg();
  return MODULOS.map(([k, n, s]) => '<label class="aj-mod' + (k === 'aprender' ? ' aj-aprender-mod' : '') + '"><div><b>' + n + '</b><span>' + s + '</span></div>' +
    (k === 'treino' && m[k] !== false ? '<button onclick="event.preventDefault();go(\'treino\')">Abrir</button>' : '') +
    (k === 'aprender' && m[k] !== false ? '<button onclick="event.preventDefault();go(\'aprender\')">Abrir</button>' : '') +
    '<input type="checkbox" ' + (m[k] !== false ? 'checked' : '') + ' onchange="modMudar(\'' + k + '\',this.checked)"></label>').join('') +
    '<label class="aj-mod"><div><b>Tela Hoje</b><span>Escolha o que aparece e a ordem</span></div><button onclick="event.preventDefault();go(\'inicio\');openSheet(\'inicio-editar\')">Editar</button></label>';
}
function ajAparenciaHTML(){
  const t = D.cfg.tema === 'claro' ? 'claro' : 'escuro';
  return '<div class="card pad" style="display:flex;flex-direction:column;gap:10px"><div class="seg"><button class="' + (t === 'escuro' ? 'on' : '') + '" onclick="mudarTema(\'escuro\')">Escuro</button><button class="' + (t === 'claro' ? 'on' : '') + '" onclick="mudarTema(\'claro\')">Claro</button></div></div>';
}
function ajMontar(){
  const mais = document.getElementById('s-mais'); if(!mais || document.getElementById('aj-grupos')) return;
  const h1 = mais.querySelector('h1'); if(h1) h1.textContent = 'Ajustes';
  // Cabeçalho com voltar (os Ajustes não estão na barra de baixo)
  const cab = document.createElement('div'); cab.className = 'row'; cab.style.gap = '12px';
  cab.innerHTML = '<button class="v4-ico" aria-label="Voltar" onclick="go(\'inicio\')"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button>';
  h1.replaceWith(cab); cab.appendChild(h1);
  const porTitulo = re => [...mais.children].find(c => c.classList && c.classList.contains('card') && re.test((c.querySelector('h2') || {}).textContent || ''));
  const pega = id => document.getElementById(id);
  const grupos = [
    ['mod',   'Módulos',              'Ligue só o que você usa',          null],
    ['apar',  'Aparência',            'Escuro ou claro',                  null],
    ['voz',   'Voz do assistente',    'Motor, voz e velocidade',          [pega('voz-card')]],
    ['lemb',  'Lembretes e backup',   'Notificações e cópia dos dados',   [pega('lb-card')]],
    ['banco', 'Bancos e gastos',      'Pluggy e captura automática',      [porTitulo(/Pluggy/), porTitulo(/Captura/), porTitulo(/Privacidade/)]],
    ['ia',    'Inteligência artificial', 'IA grátis e Claude/ChatGPT',    [pega('ia-card')]],
    ['conta', 'Conta e app',          'Nome, atualizações e dados',       [porTitulo(/Seu nome/), pega('upd-card'), porTitulo(/Zona de perigo/)]]
  ];
  const box = document.createElement('div'); box.id = 'aj-grupos'; box.style.cssText = 'display:flex;flex-direction:column;gap:10px';
  grupos.forEach(([id, nome, sub, els]) => {
    const g = document.createElement('details'); g.className = 'aj-grupo'; g.id = 'aj-' + id;
    if(id === 'voz') g.classList.add('aj-voz');
    g.innerHTML = '<summary><div style="display:flex;flex-direction:column">' + nome + '<span>' + sub + '</span></div></summary><div class="aj-corpo"></div>';
    const corpo = g.querySelector('.aj-corpo');
    if(id === 'mod') corpo.innerHTML = '<div id="aj-mod-lista">' + ajModulosHTML() + '</div>';
    else if(id === 'apar') corpo.innerHTML = '<div id="aj-apar-corpo">' + ajAparenciaHTML() + '</div>';
    else (els || []).filter(Boolean).forEach(e => corpo.appendChild(e));
    box.appendChild(g);
  });
  cab.insertAdjacentElement('afterend', box);
  // Atalhos antigos que viraram parte dos Módulos
  ['tr-mais', 'in-mais', 'visual-card'].forEach(id => { const e = pega(id); if(e) e.style.display = 'none'; });
  [...mais.children].forEach(c => { if(c.tagName === 'BUTTON' && /Aprender a usar IA/.test(c.textContent)) c.style.display = 'none'; });
}
function ajRender(){
  const l = document.getElementById('aj-mod-lista'); if(l) l.innerHTML = ajModulosHTML();
  const a = document.getElementById('aj-apar-corpo'); if(a) a.innerHTML = ajAparenciaHTML();
}

// ---------- Telas mais enxutas ----------
function v4Enxugar(){
  // Finanças: um botão principal; o resto vira link discreto
  const fin = document.getElementById('s-financas');
  const linha = fin && [...fin.querySelectorAll(':scope > .row')].find(r => /Registrar gasto/.test(r.textContent));
  if(linha && !document.getElementById('fin-links')){
    const comprar = [...linha.querySelectorAll('button')].find(b => /Vou comprar/.test(b.textContent));
    const analisar = document.getElementById('ia-fin-btn');
    const links = document.createElement('div'); links.id = 'fin-links'; links.className = 'v4-links';
    if(comprar){ comprar.className = ''; links.appendChild(comprar); }
    if(analisar){ analisar.className = ''; analisar.textContent = 'Analisar com Claude/GPT'; links.appendChild(analisar); }
    linha.insertAdjacentElement('afterend', links);
    const reg = linha.querySelector('button'); if(reg) reg.classList.add('full');
  }
  // Tarefas: atalho para o Treino ao lado de Kanban/Lista/Clientes
  const seg = document.querySelector('#s-tarefas .seg');
  if(seg && !document.getElementById('v-treino')){
    const b = document.createElement('button'); b.id = 'v-treino'; b.textContent = 'Estudo'; b.onclick = () => go('treino');
    seg.appendChild(b); seg.style.width = '100%';
    const cab = seg.parentElement; if(cab){ cab.style.flexWrap = 'wrap'; cab.style.gap = '12px'; }
  }
  // Barra de baixo: Hoje, Tarefas, +, Finanças, Notícias (Ajustes pela engrenagem)
  const nav = document.querySelector('nav');
  const bt = s => nav.querySelector('[data-go=' + s + ']');
  if(bt('inicio')) bt('inicio').lastChild.textContent = 'Hoje';
  if(bt('mais')) bt('mais').style.display = 'none';
  const ordem = ['inicio', 'tarefas', null, 'financas', 'noticias'];
  ordem.forEach(k => { const e = k ? bt(k) : nav.querySelector('.plus'); if(e) nav.appendChild(e); });
  if(bt('tarefas')) bt('tarefas').lastChild.textContent = 'Tarefas';
  nav.classList.remove('seis');
}

(function(){
  const migrou = v4Migrar();
  modCfg();
  // As funções do antigo HUD valem para o app inteiro: o visual deixa de ser escolha
  arenaAtiva = () => false;
  hudAtivo = () => true;
  mudarVisual = function(v){ if(v === 'claro' || v === 'classico') mudarTema('claro'); else mudarTema('escuro'); };
  visualCard = function(){};
  aplicarVisual = function(){ temaAplicar(); render(); };
  if(typeof BLOCOS === 'object'){
    // No Vida 4 todos os blocos existem no mesmo desenho
    Object.keys(BLOCOS).forEach(k => { BLOCOS[k].temas = ['classico', 'arena', 'hud']; });
    ['saudacao', 'arena-perfil', 'dia-pontos'].forEach(k => delete BLOCOS[k]);
    BLOCOS['hud-painel'].nome = 'Topo do dia'; BLOCOS['hud-painel'].desc = 'Data, saudação e quanto do dia resta';
    BLOCOS['hud-alertas'].nome = 'Atenção'; BLOCOS['hud-alertas'].desc = 'Contas, clientes e atrasos (some se não houver nada)';
    BLOCOS['hud-modo'].nome = 'Plano da manhã / Fechar o dia'; BLOCOS['hud-modo'].desc = 'Aparece só de manhã (com plano) e à noite';
    if(BLOCOS['hud-cmd']) BLOCOS['hud-cmd'].nome = 'Campo de comando';
  }
  if(typeof INICIO_PADRAO === 'object'){ INICIO_PADRAO.ordem = INICIO_V4.ordem.slice(); INICIO_PADRAO.ocultos = Object.assign({}, INICIO_V4.ocultos); }
  hudPainel = v4Painel;
  const _fcb = window.__falaCb;
  window.__falaCb = function(e){ _fcb(e); v4Painel(); };
  hudAlertas = v4Alertas;
  // Lembretes respeitam os módulos desligados
  if(typeof lbLista === 'function'){
    const _ll = lbLista;
    lbLista = function(){ return _ll().filter(x => !(/^cli-/.test(x.id) && !modOn('clientes')) && !(/trein/i.test(x.id + x.abrir) && !modOn('treino'))); };
  }
  // Voltar de Ajustes para Hoje
  const _back = window.appBack;
  window.appBack = function(){ if(tela === 'mais' && !document.getElementById('sheet').classList.contains('on')){ go('inicio'); return true; } return _back(); };

  temaAplicar(); modAplicar(); ajMontar(); v4Enxugar();
  const _r = render;
  render = function(){ _r(); modAplicar(); if(tela === 'mais') ajRender(); };
  setInterval(() => { if(tela === 'inicio' && !document.hidden) v4Painel(); }, 60000);
  render();
  if(migrou && !(window.Android && Android.plataforma && Android.plataforma() === 'pc')) setTimeout(() => toast('Vida 4: visual novo e mais limpo. Ajustes ficam na engrenagem.'), 900);
})();
