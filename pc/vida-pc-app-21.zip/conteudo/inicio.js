// =====================================================================
// v3.2: Início personalizável. O David escolhe o que aparece e em que ordem (setas, que funcionam
// melhor que arrastar no celular). Padrão enxuto: o que dá para ver e fazer no Kanban (lista "Hoje",
// atalhos das áreas) fica fora do Início; dá para ligar de volta. Um layout só para os 3 visuais;
// blocos que não existem num visual simplesmente não aparecem nele.
// Config em D.cfg.inicio = {ordem:[ids], ocultos:{id:true}}.
// Depende de: D, save, render, esc, toast, openSheet, closeSheet, formHTML, go, arenaAtiva, hudAtivo.
// =====================================================================

const BLOCOS = {
  'saudacao':    {nome:'Saudação e data',            desc:'"Boa tarde, David" e o dia',               temas:['classico']},
  'arena-perfil':{nome:'Perfil e nível',             desc:'Seu nível, elo e XP',                      temas:['arena']},
  'hud-painel':  {nome:'Painel de status',           desc:'Relógio, % feito, tempo que resta, briefing', temas:['hud']},
  'focus':       {nome:'Foco agora',                 desc:'A tarefa principal e o próximo passo',     temas:['classico','arena','hud']},
  'hud-cmd':     {nome:'Comando por voz/texto',      desc:'"tarefa…", "gastei…", "abrir…"',          temas:['hud']},
  'hud-alertas': {nome:'Alertas',                    desc:'Até 2 avisos com ação de um toque',        temas:['hud']},
  'dia-pontos':  {nome:'Dia em pontos',              desc:'Quanto tempo resta e se as tarefas cabem', temas:['classico','arena']},
  'hud-modo':    {nome:'Manhã / Fechar o dia',       desc:'Seu plano de manhã e o fechamento à noite', temas:['hud']},
  'vd-banner':   {nome:'Clientes para contatar',     desc:'Só aparece quando há follow-up',           temas:['classico','arena','hud']},
  'rotina':      {nome:'Rotina de hoje',             desc:'Seus hábitos diários para marcar',         temas:['classico','arena','hud']},
  'hoje':        {nome:'Lista de hoje',              desc:'Todas as tarefas do dia (também no Kanban)', temas:['classico','arena','hud']},
  'tiles':       {nome:'Atalhos das áreas',          desc:'Finanças, Trabalho, Estudos, Pessoal',     temas:['classico','arena','hud']},
  'nt-banner':   {nome:'Manchete das notícias',      desc:'A notícia mais recente',                   temas:['classico','arena','hud']},
  'apr-banner':  {nome:'Aprender a usar IA',         desc:'Próxima lição',                            temas:['classico','arena','hud']}
};
const INICIO_PADRAO = {
  ordem:['saudacao','arena-perfil','hud-painel','focus','hud-cmd','hud-alertas','dia-pontos','hud-modo','vd-banner','rotina','hoje','tiles','nt-banner','apr-banner'],
  ocultos:{hoje:true, tiles:true, 'nt-banner':true, 'apr-banner':true}
};
function inCfg(){
  if(!D.cfg.inicio || !Array.isArray(D.cfg.inicio.ordem)) D.cfg.inicio = JSON.parse(JSON.stringify(INICIO_PADRAO));
  const c = D.cfg.inicio;
  if(!c.ocultos || typeof c.ocultos !== 'object') c.ocultos = {};
  Object.keys(BLOCOS).forEach(id => { if(!c.ordem.includes(id)) c.ordem.push(id); });   // blocos novos entram no fim
  c.ordem = c.ordem.filter(id => BLOCOS[id]);
  return c;
}
function temaAtual(){ return hudAtivo() ? 'hud' : arenaAtiva() ? 'arena' : 'classico'; }

// Elementos de cada bloco (alguns blocos têm mais de um elemento, como o foco e o "Só a missão")
function inElems(id){
  const s = document.getElementById('s-inicio');
  if(id === 'saudacao') return [s.querySelector(':scope > .between')];
  if(id === 'hoje') return [document.getElementById('hoje-lista') && document.getElementById('hoje-lista').parentElement];
  if(id === 'rotina') return [document.getElementById('rotina-lista') && document.getElementById('rotina-lista').parentElement];
  if(id === 'focus') return [document.getElementById('focus'), document.getElementById('sm-entrar'), document.getElementById('sm-sair')];
  return [document.getElementById(id)];
}
function inAplicar(){
  const c = inCfg();
  c.ordem.forEach((id, i) => inElems(id).forEach((el, k) => {
    if(!el) return;
    el.style.order = String(10 + i * 10 + k);
    el.classList.toggle('bloco-oculto', !!c.ocultos[id]);
  }));
}

// ---------- Editor ----------
function inEditorHTML(){
  const c = inCfg(), tema = temaAtual();
  const vis = c.ordem.filter(id => BLOCOS[id].temas.includes(tema));
  return '<h2>Editar o Início</h2>' +
    '<p class="note" style="margin:0">Ligue só o que você quer ver ao abrir o app. Use as setas para mudar a ordem. O resto continua no lugar de sempre (Kanban, Finanças, Notícias).</p>' +
    '<div class="card" style="padding:4px 12px">' + vis.map((id, i) => {
      const b = BLOCOS[id], on = !c.ocultos[id];
      return '<div class="item in-item' + (on ? '' : ' off') + '">' +
        '<input type="checkbox" aria-label="Mostrar ' + esc(b.nome) + '" ' + (on ? 'checked' : '') + ' onchange="inMostrar(\'' + id + '\',this.checked)">' +
        '<span class="txt">' + esc(b.nome) + '<small>' + esc(b.desc) + '</small></span>' +
        '<button class="in-seta" aria-label="Subir" ' + (i === 0 ? 'disabled' : '') + ' onclick="inMover(\'' + id + '\',-1)">↑</button>' +
        '<button class="in-seta" aria-label="Descer" ' + (i === vis.length - 1 ? 'disabled' : '') + ' onclick="inMover(\'' + id + '\',1)">↓</button></div>';
    }).join('') + '</div>' +
    '<div class="row"><button class="btn outline" style="flex:1" onclick="inPadrao()">Padrão enxuto</button><button class="btn primary" style="flex:1" onclick="closeSheet()">Pronto</button></div>';
}
function inRedesenhar(){ const sh = document.getElementById('sheet'); if(sheetTipo === 'inicio-editar') sh.innerHTML = '<div class="grab"></div>' + inEditorHTML(); }
function inMostrar(id, on){ const c = inCfg(); if(on) delete c.ocultos[id]; else c.ocultos[id] = true; save(); inAplicar(); inRedesenhar(); }
function inMover(id, dir){
  const c = inCfg(), tema = temaAtual();
  const vis = c.ordem.filter(x => BLOCOS[x].temas.includes(tema));
  const i = vis.indexOf(id), j = i + dir; if(j < 0 || j >= vis.length) return;
  const a = c.ordem.indexOf(vis[i]), b = c.ordem.indexOf(vis[j]);
  [c.ordem[a], c.ordem[b]] = [c.ordem[b], c.ordem[a]];
  save(); inAplicar(); inRedesenhar();
}
function inPadrao(){ D.cfg.inicio = JSON.parse(JSON.stringify(INICIO_PADRAO)); save(); inAplicar(); inRedesenhar(); toast('Início no padrão enxuto'); }

(function(){
  inCfg();
  // Botão discreto no fim do Início
  const s = document.getElementById('s-inicio');
  const bt = document.createElement('button'); bt.id = 'in-editar'; bt.className = 'in-editar';
  bt.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/></svg>Editar o Início';
  bt.onclick = () => openSheet('inicio-editar');
  bt.style.order = '9999';
  s.appendChild(bt);
  // Atalho em Mais
  const mais = document.getElementById('s-mais');
  const c = document.createElement('button'); c.className = 'card pad'; c.id = 'in-mais';
  c.style.cssText = 'border:0;text-align:left;display:flex;flex-direction:column;gap:4px';
  c.innerHTML = '<b style="font-size:16px">Editar o Início</b><span class="sub">Escolha o que aparece e em que ordem</span>';
  c.onclick = () => { go('inicio'); openSheet('inicio-editar'); };
  mais.insertBefore(c, mais.children[1] || null);

  const _f = formHTML;
  formHTML = function(tipo, id){ return tipo === 'inicio-editar' ? inEditorHTML() : _f(tipo, id); };
  const _r = render;
  render = function(){ _r(); inAplicar(); };
  inAplicar();
})();
