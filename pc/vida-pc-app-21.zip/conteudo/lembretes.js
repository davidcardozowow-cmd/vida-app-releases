// =====================================================================
// v3.1: lembretes com o app fechado + backup automático.
// Lembretes: a lista é calculada aqui (próximos 7 dias) e enviada ao Android (Android.setReminders),
// que agenda e mostra as notificações mesmo com o app fechado. Na tela bloqueada aparece só um texto
// genérico; nomes e valores só com o celular desbloqueado.
// Backup: a cada 7 dias (ao abrir o app) grava Downloads/Vida/Vida-backup-AAAA-MM-DD.json no celular
// (sem segredos: chaves ficam no cofre). Restaurar a partir do arquivo.
// Depende de: D, save, render, toast, esc, hoje, addDias, parseD, brl, quando, foco, proxPasso, paraHoje,
//             contasAbertas, go, vista, openSheet, closeSheet, formHTML, normalizar, vazio, NATIVO,
//             vdParaHoje (vendas.js), hudPlanoHoje (hud.js; opcional).
// =====================================================================

function lbCfg(){
  D.cfg.lembretes = Object.assign({ativo:true, manha:'08:00', noite:'21:30', contas:true, clientes:true, plano:true, fechar:true}, D.cfg.lembretes || {});
  return D.cfg.lembretes;
}
const lbHora = (dataStr, hm) => { const [h, m] = String(hm).split(':').map(Number); const d = parseD(dataStr); d.setHours(h || 0, m || 0, 0, 0); return d.getTime(); };

function lbLista(){
  const c = lbCfg(); if(!c.ativo) return [];
  const agora = Date.now(), h = hoje(), L = [];
  const add = (id, quando, titulo, texto, abrir, publico) => { if(quando > agora + 30000) L.push({id, quando, titulo, texto, abrir, publico}); };
  for(let i = 0; i < 7; i++){
    const dia = addDias(h, i), manha = lbHora(dia, c.manha), noite = lbHora(dia, c.noite);
    // Manhã: o plano "se-então" (se houver) ou a primeira ação do dia
    const plano = D.planoSeEntao && D.planoSeEntao.data === dia ? D.tarefas.find(t => t.id === D.planoSeEntao.tarefa && !t.feita) : null;
    if(c.plano && plano){
      const passo = proxPasso(plano);
      add('plano-' + dia, manha, 'Seu plano de hoje', 'Quando ' + D.planoSeEntao.quando + ', então: ' + (passo ? passo.t : plano.titulo) + '.', 'inicio', 'Seu plano de hoje');
    } else if(c.plano && i <= 1){
      // Hoje e amanhã: resumo curto das tarefas daquele dia
      const doDia = D.tarefas.filter(t => !t.feita && t.data && t.data <= dia && (i === 0 || t.data === dia));
      if(doDia.length){
        const f = i === 0 ? foco() : doDia[0];
        add('dia-' + dia, manha, doDia.length + (doDia.length > 1 ? ' tarefas para hoje' : ' tarefa para hoje'), 'Comece por: ' + (f ? (proxPasso(f) ? proxPasso(f).t : f.titulo) : doDia[0].titulo), 'inicio', 'Tarefas de hoje');
      }
    }
    // Clientes com próximo passo no dia (resumo único, 30 min depois da manhã)
    if(c.clientes && Array.isArray(D.clientes)){
      const cs = D.clientes.filter(x => x.etapa !== 'fechado' && x.etapa !== 'perdido' && x.prox && x.prox.data && (i === 0 ? x.prox.data <= dia : x.prox.data === dia));
      if(cs.length) add('cli-' + dia, manha + 30 * 60000, cs.length > 1 ? cs.length + ' clientes para contatar' : 'Contatar ' + cs[0].nome,
        cs.slice(0, 4).map(x => x.nome + (x.prox.t ? ': ' + x.prox.t : '')).join(' · '), 'clientes', 'Follow-up de clientes');
    }
    // Contas: na véspera e no dia, às 9h
    if(c.contas) contasAbertas().forEach(ct => {
      if(ct.venc === addDias(dia, 1)) add('conta1-' + ct.id + '-' + dia, lbHora(dia, '09:00'), ct.desc + ' vence amanhã', brl(ct.valor) + '. Toque para marcar como paga quando pagar.', 'financas', 'Conta vencendo');
      if(ct.venc === dia) add('conta0-' + ct.id + '-' + dia, lbHora(dia, '09:00'), ct.desc + ' vence hoje', brl(ct.valor) + '.', 'financas', 'Conta vencendo hoje');
    });
    // Noite: fechar o dia (se ainda não fechou)
    if(c.fechar && !(i === 0 && D.hudFechado === h)) add('fechar-' + dia, noite, 'Fechar o dia', 'Um minuto: veja o que fez, passe o resto para amanhã e escolha a prioridade.', 'fechar', 'Fechar o dia');
  }
  return L.sort((a, b) => a.quando - b.quando).slice(0, 60);
}
let lbUltimo = '';
function lbEnviar(forcar){
  if(!NATIVO || !Android.setReminders) return;
  const j = JSON.stringify(lbLista());
  if(!forcar && j === lbUltimo) return;
  lbUltimo = j;
  try { Android.setReminders(j); } catch(e){}
}

// Notificação tocada: abre a tela certa
function lbAbrirPedido(){
  if(!NATIVO || !Android.takeOpenRequest) return;
  const a = Android.takeOpenRequest(); if(!a) return;
  if(a === 'clientes'){ vista = 'clientes'; go('tarefas'); }
  else if(a === 'fechar'){ go('inicio'); openSheet('hud-fechar'); }
  else if(['inicio', 'financas', 'tarefas', 'noticias', 'mais'].includes(a)) go(a);
}

// ---------- Backup automático ----------
function bkCfg(){ D.cfg.backup = Object.assign({auto:true, ultimo:null, onde:''}, D.cfg.backup || {}); return D.cfg.backup; }
function bkFazer(manual){
  if(!NATIVO || !Android.saveBackup){ if(manual) exportar(); return; }
  const b = bkCfg(), nome = 'Vida-backup-' + hoje() + '.json';
  b.ultimo = hoje(); // grava a data antes, para ela já ir dentro do arquivo
  const r = Android.saveBackup(nome, JSON.stringify(D));
  if(r.startsWith('ok:')){ b.onde = r.slice(3); save(); if(manual) toast('Backup salvo em ' + b.onde); }
  else { b.ultimo = null; save(); toast('Não consegui salvar o backup (' + r.slice(5) + '). Use "Enviar para o Drive".'); }
  render();
}
function bkAutomatico(){ const b = bkCfg(); if(b.auto && (!b.ultimo || b.ultimo <= addDias(hoje(), -7))) bkFazer(false); }
window.__arquivoCb = function(txt){
  if(!txt){ toast('Nenhum arquivo lido'); return; }
  let o; try { o = JSON.parse(txt); } catch(e){ toast('Esse arquivo não é um backup do Vida'); return; }
  if(!o || !Array.isArray(o.tarefas)){ toast('Esse arquivo não é um backup do Vida'); return; }
  const qt = (o.tarefas || []).length, ql = (o.lanc || []).length, qc = (o.clientes || []).length;
  if(!confirm('Restaurar o backup de ' + ((o.cfg && o.cfg.backup && o.cfg.backup.ultimo) || 'data desconhecida') + '?\n' + qt + ' tarefas, ' + ql + ' lançamentos, ' + qc + ' clientes.\nIsso substitui os dados atuais.')) return;
  D = Object.assign(vazio(), o); normalizar(); save(); closeSheet(); go('inicio'); toast('Backup restaurado');
};

// ---------- Configuração em Mais ----------
function lbCard(){
  const el = document.getElementById('lb-card'); if(!el) return;
  const c = lbCfg(), b = bkCfg();
  const permitido = !NATIVO || !Android.notifPostEnabled || Android.notifPostEnabled();
  const prox = lbLista()[0];
  const diasBk = b.ultimo ? Math.round((parseD(hoje()) - parseD(b.ultimo)) / 864e5) : null;
  el.innerHTML = '<h2>Lembretes</h2>' +
    '<p class="note" style="margin:0">Chegam mesmo com o app fechado. Na tela bloqueada aparece só "Vida: lembrete"; nomes e valores só com o celular desbloqueado.</p>' +
    (permitido ? '' : '<button class="btn primary full" onclick="Android.requestNotifPost()">Permitir notificações</button>') +
    '<label class="row" style="font-size:15px;font-weight:600"><input type="checkbox" style="width:22px;height:22px" ' + (c.ativo ? 'checked' : '') + ' onchange="lbMudar(\'ativo\',this.checked)"> Lembretes ligados</label>' +
    (c.ativo ? '<div class="row"><label class="f" style="flex:1">Manhã<input type="time" value="' + c.manha + '" onchange="lbMudar(\'manha\',this.value)"></label><label class="f" style="flex:1">Noite<input type="time" value="' + c.noite + '" onchange="lbMudar(\'noite\',this.value)"></label></div>' +
      [['plano', 'Plano do dia e primeira tarefa (manhã)'], ['clientes', 'Clientes para contatar'], ['contas', 'Contas na véspera e no dia (9h)'], ['fechar', 'Fechar o dia (noite)']].map(([k, n]) =>
        '<label class="row" style="font-size:14px"><input type="checkbox" style="width:20px;height:20px" ' + (c[k] ? 'checked' : '') + ' onchange="lbMudar(\'' + k + '\',this.checked)"> ' + n + '</label>').join('') +
      '<p class="note" style="margin:0">' + (prox ? 'Próximo: <b>' + esc(prox.titulo) + '</b> · ' + quando(ymd(new Date(prox.quando))).toLowerCase() + ' às ' + pad2(new Date(prox.quando).getHours()) + ':' + pad2(new Date(prox.quando).getMinutes()) : 'Nenhum lembrete nos próximos 7 dias.') + '</p>' +
      '<p class="note" style="margin:0">Pode atrasar alguns minutos quando o celular está economizando bateria. Se não chegar, tire o Vida da otimização de bateria nas configurações do celular.</p>' : '') +
    '<h2 style="margin-top:8px">Backup automático</h2>' +
    '<p class="note" style="margin:0">A cada 7 dias o app salva uma cópia em <b>Downloads/Vida</b> no seu celular (as 4 mais recentes). Ela continua lá mesmo se o app for desinstalado. Para ficar seguro também se perder o celular, envie para o Drive de vez em quando.</p>' +
    '<label class="row" style="font-size:15px;font-weight:600"><input type="checkbox" style="width:22px;height:22px" ' + (b.auto ? 'checked' : '') + ' onchange="bkCfg().auto=this.checked;save();render()"> Backup automático semanal</label>' +
    '<p class="note" style="margin:0;font-weight:700">' + (b.ultimo ? 'Último backup: ' + (diasBk === 0 ? 'hoje' : 'há ' + diasBk + (diasBk > 1 ? ' dias' : ' dia')) + (b.onde ? ' · ' + esc(b.onde) : '') : 'Ainda não fez backup.') + '</p>' +
    '<button class="btn primary full" onclick="bkFazer(true)">Fazer backup agora</button>' +
    '<button class="btn outline full" onclick="exportar()">Enviar para o Drive / WhatsApp</button>' +
    '<button class="btn outline full" onclick="if(window.Android&&Android.pickFile)Android.pickFile();else openSheet(\'importar\')">Restaurar de um arquivo</button>';
}
function lbMudar(k, v){ lbCfg()[k] = v; save(); lbEnviar(true); render(); }

(function(){
  lbCfg(); bkCfg();
  // O cartão substitui o antigo "Backup dos dados" em Mais
  const mais = document.getElementById('s-mais');
  const antigo = [...mais.querySelectorAll('.card')].find(c => /Backup dos dados/.test(c.textContent));
  const el = document.createElement('div'); el.id = 'lb-card'; el.className = 'card pad'; el.style.cssText = 'display:flex;flex-direction:column;gap:12px';
  if(antigo) antigo.replaceWith(el); else mais.appendChild(el);

  window.__notifPostCb = () => { lbEnviar(true); render(); };
  const _r = render;
  render = function(){ _r(); clearTimeout(render._lb); render._lb = setTimeout(() => lbEnviar(false), 500); if(tela === 'mais') lbCard(); };
  const _res = window.appResume;
  window.appResume = function(){ if(_res) _res(); lbAbrirPedido(); lbEnviar(true); bkAutomatico(); };
  setTimeout(() => { lbAbrirPedido(); lbEnviar(true); bkAutomatico(); }, 1000);
  // Primeira vez: pede a permissão de notificação (Android 13+)
  setTimeout(() => { if(NATIVO && Android.notifPostEnabled && !Android.notifPostEnabled() && !D.cfg.lembretes.pediu){ D.cfg.lembretes.pediu = true; save(); Android.requestNotifPost(); } }, 2500);
  lbCard();
})();
