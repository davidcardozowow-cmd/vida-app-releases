// =====================================================================
// Clientes (v3.0): mini-pipeline de vendas dentro de Tarefas (aba "Clientes").
// Regra de ouro: nenhum cliente sem próximo passo com data. Alertas no Início e no HUD.
// WhatsApp pelo link oficial wa.me (sem biblioteca). A mensagem de follow-up é montada
// e enviada ao Claude/ChatGPT do David (abrirPerguntar), nunca para a IA grátis.
// Depende de: D, save, render, esc, toast, hoje, addDias, quando, uid, val, openSheet, closeSheet,
//             formHTML, go, vista, NATIVO, abrirPerguntar, ganharXP (index.html, ia.js, arena.js).
// =====================================================================

const ETAPAS = [['lead','Lead'],['conversa','Conversa'],['proposta','Proposta'],['negociacao','Negociação'],['fechado','Fechado'],['perdido','Perdido']];
const etapaNome = k => (ETAPAS.find(e => e[0] === k) || ['', k])[1];
function vdNorm(){ if(!Array.isArray(D.clientes)) D.clientes = []; return D.clientes; }
const vdAtivo = c => c.etapa !== 'fechado' && c.etapa !== 'perdido';
function vdParaHoje(){ const h = hoje(); return vdNorm().filter(c => vdAtivo(c) && c.prox && c.prox.data && c.prox.data <= h); }
function vdSemPasso(){ return vdNorm().filter(c => vdAtivo(c) && !(c.prox && c.prox.t && c.prox.data)); }
function vdDias(c){ if(!c.ultimo) return null; return Math.round((parseD(hoje()) - parseD(c.ultimo)) / 864e5); }
function vdTel(t){ let d = String(t || '').replace(/\D/g, ''); if(d.length === 10 || d.length === 11) d = '55' + d; return d.length >= 12 ? d : ''; }

function vdCard(c){
  const h = hoje(), late = c.prox && c.prox.data && c.prox.data < h, dias = vdDias(c);
  return '<div class="vd-card">' +
    '<div class="between" style="align-items:flex-start;gap:8px"><div style="min-width:0" onclick="openSheet(\'cliente\',\'' + c.id + '\')"><b>' + esc(c.nome) + '</b>' + (c.empresa ? '<span class="sub" style="display:block">' + esc(c.empresa) + '</span>' : '') + '</div>' +
      '<span class="vd-etapa vd-' + c.etapa + '">' + etapaNome(c.etapa) + '</span></div>' +
    (vdAtivo(c) ? (c.prox && c.prox.t
      ? '<div class="vd-prox' + (late ? ' late' : '') + '">Próximo: <b>' + esc(c.prox.t) + '</b> · ' + (c.prox.data ? (late ? 'atrasado, ' : '') + quando(c.prox.data).toLowerCase() : 'sem data') + '</div>'
      : '<div class="vd-prox late">Sem próximo passo. Defina um.</div>') : '') +
    '<div class="sub">' + (dias == null ? 'Nenhum contato registrado' : dias === 0 ? 'Último contato: hoje' : 'Último contato: há ' + dias + (dias > 1 ? ' dias' : ' dia')) + (c.valor ? ' · ' + brl(c.valor) : '') + '</div>' +
    '<div class="vd-ac">' + (vdTel(c.tel) ? '<button onclick="vdWhats(\'' + c.id + '\')">WhatsApp</button>' : '') +
      (vdAtivo(c) ? '<button onclick="openSheet(\'contato\',\'' + c.id + '\')">Registrar contato</button><button onclick="vdMensagem(\'' + c.id + '\')">Mensagem</button>' : '') + '</div>' +
  '</div>';
}
function vdRender(){
  const el = document.getElementById('vista-clientes'); if(!el) return;
  const cs = vdNorm(), h = hoje();
  const hojeL = vdParaHoje().sort((a, b) => a.prox.data < b.prox.data ? -1 : 1);
  const sem = vdSemPasso();
  const outros = cs.filter(c => vdAtivo(c) && !hojeL.includes(c) && !sem.includes(c)).sort((a, b) => (a.prox.data || '9') < (b.prox.data || '9') ? -1 : 1);
  const enc = cs.filter(c => !vdAtivo(c));
  const pipeline = cs.filter(vdAtivo).reduce((s, c) => s + (c.valor || 0), 0);
  const bloco = (tit, arr) => arr.length ? '<div class="between"><h2>' + tit + '</h2><span class="sub">' + arr.length + '</span></div>' + arr.map(vdCard).join('') : '';
  el.innerHTML =
    '<div class="vd-resumo"><div><b>' + hojeL.length + '</b><span>para hoje</span></div><div><b>' + cs.filter(vdAtivo).length + '</b><span>em andamento</span></div><div><b>' + (pipeline ? brl(pipeline).replace(',00', '') : '—') + '</b><span>em jogo</span></div></div>' +
    '<button class="btn primary full" onclick="openSheet(\'cliente\')">Novo cliente</button>' +
    (cs.length ? '' : '<div class="empty">Cadastre seus clientes e o próximo passo de cada um. O app te avisa no dia certo de fazer o follow-up.</div>') +
    bloco('Contatar hoje', hojeL) + bloco('Sem próximo passo', sem) + bloco('Em andamento', outros) +
    (enc.length ? '<details class="vd-enc"><summary>Fechados e perdidos (' + enc.length + ')</summary>' + enc.map(vdCard).join('') + '</details>' : '');
}

function vdWhats(id){
  const c = vdNorm().find(x => x.id === id); const n = c && vdTel(c.tel); if(!n) return;
  const u = 'https://wa.me/' + n;
  if(NATIVO && Android.openUrl) Android.openUrl(u); else window.open(u, '_blank');
}
function vdMensagem(id){
  const c = vdNorm().find(x => x.id === id); if(!c) return;
  const hist = (c.hist || []).slice(-3).map(x => '- ' + x.data + ': ' + x.t).join('\n');
  abrirPerguntar(
    'O que eu quero: uma mensagem curta de follow-up pelo WhatsApp para um cliente.\n' +
    'Contexto: sou vendedor B2B consultivo. Cliente: ' + c.nome + (c.empresa ? ' (' + c.empresa + ')' : '') + '. Etapa: ' + etapaNome(c.etapa) + '.' +
    (c.prox && c.prox.t ? ' Próximo passo previsto: ' + c.prox.t + '.' : '') + (c.notas ? '\nNotas: ' + c.notas : '') + (hist ? '\nÚltimos contatos:\n' + hist : '') + '\n' +
    'Como: tom consultivo, próximo e educado, até 4 linhas, em português do Brasil.\n' +
    'O que NÃO quero: não ofereça desconto, não pressione, não invente informação que não está aqui.\n' +
    'Como saber que deu certo: termina com uma pergunta simples que o cliente consiga responder rápido. Me dê 2 versões.');
}
function salvarCliente(){
  const nome = (val('f-nome') || '').trim(); if(!nome){ toast('Nome do cliente'); return; }
  const prox = {t:(val('f-prox') || '').trim(), data:val('f-pdata') || null};
  const d = {nome, empresa:(val('f-emp') || '').trim(), tel:(val('f-tel') || '').trim(), etapa:val('f-etapa'), valor:lerValor(val('f-valor')) || 0, notas:(val('f-notas') || '').trim(), prox};
  if(sheetId) Object.assign(vdNorm().find(x => x.id === sheetId), d);
  else vdNorm().push(Object.assign({id:uid(), criado:hoje(), ultimo:null, hist:[]}, d));
  save(); closeSheet(); render(); toast(prox.t && prox.data ? 'Cliente salvo' : 'Salvo. Lembre de definir o próximo passo.');
}
function salvarContato(){
  const c = vdNorm().find(x => x.id === sheetId); if(!c) return;
  const oque = (val('f-oque') || '').trim(), prox = (val('f-prox') || '').trim(), data = val('f-pdata');
  if(!prox || !data){ toast('Defina o próximo passo e a data'); return; }
  c.hist = (c.hist || []).concat([{data:hoje(), t:oque || 'Contato'}]).slice(-20);
  c.ultimo = hoje(); c.etapa = val('f-etapa'); c.prox = {t:prox, data};
  const xpDia = 'xp' + hoje();
  if(typeof ganharXP === 'function' && c.xpDia !== xpDia){ c.xpDia = xpDia; ganharXP(10, 'follow-up'); }
  save(); closeSheet(); render(); toast('Contato registrado. Próximo: ' + quando(data).toLowerCase());
}
function excluirCliente(id){ if(!confirm('Excluir este cliente?')) return; D.clientes = vdNorm().filter(x => x.id !== id); save(); closeSheet(); render(); }
function vdOpcoesEtapa(sel){ return ETAPAS.map(e => '<option value="' + e[0] + '"' + (e[0] === sel ? ' selected' : '') + '>' + e[1] + '</option>').join(''); }

// Atalho no Início (todos os visuais)
function vdBanner(){
  const b = document.getElementById('vd-banner'); if(!b) return;
  const n = vdParaHoje().length, s = vdSemPasso().length;
  if(!n && !s){ b.style.display = 'none'; return; }
  b.style.display = '';
  b.innerHTML = '<div class="ico" style="background:var(--trab-soft);flex-shrink:0"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--trab)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div>' +
    '<span style="flex:1"><b style="font-size:15px;display:block">' + (n ? n + (n > 1 ? ' clientes para contatar hoje' : ' cliente para contatar hoje') : 'Clientes sem próximo passo') + '</b>' +
    '<span class="sub">' + (n ? vdParaHoje().slice(0, 3).map(c => esc(c.nome)).join(', ') : s + (s > 1 ? ' clientes precisam' : ' cliente precisa') + ' de um próximo passo') + '</span></span>';
}

(function(){
  vdNorm();
  // Terceira opção no seletor de Tarefas: Clientes
  const seg = document.querySelector('#s-tarefas .seg');
  seg.style.width = '250px';
  const bt = document.createElement('button'); bt.id = 'v-clientes'; bt.textContent = 'Clientes';
  bt.onclick = () => { vista = 'clientes'; render(); };
  seg.appendChild(bt);
  const vc = document.createElement('div'); vc.id = 'vista-clientes'; vc.style.cssText = 'display:none;flex-direction:column;gap:12px';
  document.getElementById('vista-lista').insertAdjacentElement('afterend', vc);

  const inicio = document.getElementById('s-inicio');
  const ban = document.createElement('button'); ban.id = 'vd-banner'; ban.className = 'card pad';
  ban.style.cssText = 'border:0;text-align:left;display:none;align-items:center;gap:12px';
  ban.onclick = () => { vista = 'clientes'; go('tarefas'); };
  const ref = document.getElementById('nt-banner') || null;
  inicio.insertBefore(ban, ref);

  const _f = formHTML;
  formHTML = function(tipo, id){
    if(tipo === 'cliente'){
      const c = id ? vdNorm().find(x => x.id === id) : null;
      return '<h2>' + (c ? 'Editar cliente' : 'Novo cliente') + '</h2>' +
        '<label class="f">Nome<input id="f-nome" value="' + (c ? esc(c.nome) : '') + '" placeholder="Ex.: Carlos"></label>' +
        '<label class="f">Empresa (opcional)<input id="f-emp" value="' + (c ? esc(c.empresa || '') : '') + '" placeholder="Ex.: Construtora Alfa"></label>' +
        '<label class="f">WhatsApp com DDD (opcional)<input id="f-tel" inputmode="tel" value="' + (c ? esc(c.tel || '') : '') + '" placeholder="71 99999-9999"></label>' +
        '<label class="f">Etapa<select id="f-etapa">' + vdOpcoesEtapa(c ? c.etapa : 'lead') + '</select></label>' +
        '<label class="f">Próximo passo<input id="f-prox" value="' + (c && c.prox ? esc(c.prox.t || '') : '') + '" placeholder="Ex.: mandar proposta revisada"></label>' +
        '<label class="f">Quando<input type="date" id="f-pdata" value="' + (c && c.prox && c.prox.data ? c.prox.data : addDias(hoje(), 1)) + '"></label>' +
        '<label class="f">Valor estimado do negócio (R$, opcional)<input id="f-valor" inputmode="decimal" value="' + (c && c.valor ? String(c.valor).replace('.', ',') : '') + '" placeholder="0,00"></label>' +
        '<label class="f">Notas<textarea id="f-notas" style="height:90px" placeholder="O que ele precisa, objeções, decisor...">' + (c ? esc(c.notas || '') : '') + '</textarea></label>' +
        '<button class="btn primary full" onclick="salvarCliente()">Salvar</button>' +
        (c && (c.hist || []).length ? '<div class="sub" style="font-weight:700">Histórico</div><div class="card" style="padding:4px 14px">' + c.hist.slice().reverse().map(x => '<div class="item"><span class="txt">' + esc(x.t) + '<small>' + quando(x.data) + '</small></span></div>').join('') + '</div>' : '') +
        (c ? '<button class="btn danger full" onclick="excluirCliente(\'' + c.id + '\')">Excluir cliente</button>' : '');
    }
    if(tipo === 'contato'){
      const c = vdNorm().find(x => x.id === id); if(!c) return '';
      return '<h2>Contato com ' + esc(c.nome) + '</h2>' +
        '<label class="f">O que aconteceu?<input id="f-oque" placeholder="Ex.: pediu proposta com prazo de 30 dias"></label>' +
        '<label class="f">Etapa agora<select id="f-etapa">' + vdOpcoesEtapa(c.etapa) + '</select></label>' +
        '<label class="f">Próximo passo<input id="f-prox" placeholder="Ex.: ligar para confirmar"></label>' +
        '<div class="row" style="gap:6px">' + [['Amanhã', 1], ['3 dias', 3], ['1 semana', 7]].map(([n, d]) => '<button class="pill" style="flex:1" onclick="document.getElementById(\'f-pdata\').value=\'' + addDias(hoje(), d) + '\'">' + n + '</button>').join('') + '</div>' +
        '<label class="f">Data do próximo passo<input type="date" id="f-pdata" value="' + addDias(hoje(), 3) + '"></label>' +
        '<button class="btn primary full" onclick="salvarContato()">Salvar contato</button>';
    }
    return _f(tipo, id);
  };

  const _r = render;
  render = function(){
    _r();
    const cl = vista === 'clientes';
    document.getElementById('v-clientes').classList.toggle('on', cl);
    document.getElementById('vista-clientes').style.display = cl ? 'flex' : 'none';
    document.getElementById('filtros').style.display = cl ? 'none' : '';
    if(cl){ document.getElementById('vista-kanban').style.display = 'none'; document.getElementById('vista-lista').style.display = 'none'; vdRender(); }
    const nova = document.querySelector('#s-tarefas > .btn.primary.full'); if(nova) nova.style.display = cl ? 'none' : '';
    vdBanner();
  };
  render();
})();
