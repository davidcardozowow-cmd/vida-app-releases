// =====================================================================
// Visual arena + progresso (XP, nível e elo).
// Regras de motivação (teoria da autodeterminação + cuidado com TDAH):
// - XP só soma: nada é tirado por atraso ou por dia perdido.
// - Cada conquista rende XP uma vez só (desmarcar e marcar de novo não "farma").
// - O visual é escolha do David: dá para voltar ao clássico em Mais.
// Depende de: D, save, render, esc, toast, hoje, go (index.html).
// =====================================================================

const XP_NIVEL = 100;
const ELOS = ['Bronze', 'Prata', 'Ouro', 'Platina', 'Diamante', 'Mestre'];
const DIVS = ['V', 'IV', 'III', 'II', 'I'];

function xpEstado(){
  if(!D.xp || typeof D.xp !== 'object') D.xp = {total: 0};
  if(!D.xp.dia || D.xp.dia.data !== hoje()) D.xp.dia = {data: hoje(), hab: [], lanc: 0};
  return D.xp;
}
function nivelDe(total){
  const nivel = Math.floor(total / XP_NIVEL) + 1;
  const i = Math.min(Math.floor((nivel - 1) / 5), ELOS.length - 1);
  const elo = ELOS[i] + (i < ELOS.length - 1 ? ' ' + DIVS[(nivel - 1) % 5] : '');
  return {nivel, elo, eloBase: ELOS[i], noNivel: total % XP_NIVEL};
}
function ganharXP(qtd, motivo){
  const x = xpEstado(), antes = nivelDe(x.total);
  x.total += qtd; save();
  const depois = nivelDe(x.total);
  const animadas = D.cfg.recompensas === 'animadas';
  if(arenaAtiva() && animadas){
    const f = document.createElement('div'); f.className = 'xp-float'; f.textContent = '+' + qtd + ' XP';
    document.body.appendChild(f); setTimeout(() => f.remove(), 1200);
  }
  if(depois.nivel > antes.nivel){
    // Discreto (padrão): só um aviso curto, sem tela cheia, para não tirar o foco da tarefa.
    if(animadas) setTimeout(() => celebrar(antes, depois), 700);
    else setTimeout(() => toast('Nível ' + depois.nivel + ' · ' + depois.elo), 400);
  }
}
function mudarRecompensas(v){ D.cfg.recompensas = v; save(); render(); }

// ---------- Só a missão ----------
function entrarSoMissao(){ go('inicio'); document.body.classList.add('so-missao'); document.querySelector('main').scrollTop = 0; }
function sairSoMissao(){ document.body.classList.remove('so-missao'); }
const _appBack = window.appBack;
window.appBack = function(){
  if(document.body.classList.contains('so-missao') && !document.getElementById('sheet').classList.contains('on')){ sairSoMissao(); return true; }
  return _appBack();
};
function celebrar(antes, depois){
  const novoElo = depois.eloBase !== antes.eloBase;
  const el = document.getElementById('nivel-up');
  el.innerHTML = '<div class="t1">'+(novoElo ? 'NOVO ELO' : 'NOVO NÍVEL')+'</div>'+
    '<div class="t2">'+(novoElo ? esc(depois.elo) : 'Nível ' + depois.nivel)+'</div>'+
    '<div class="t3">'+(novoElo ? 'Você subiu para ' + esc(depois.elo) + '. Cada missão concluída te trouxe até aqui.' : 'Agora você é ' + esc(depois.elo) + '. Continue no seu ritmo.')+'</div>'+
    '<button class="btn primary" style="min-width:200px;margin-top:10px" onclick="document.getElementById(\'nivel-up\').classList.remove(\'on\')">Continuar</button>';
  el.classList.add('on');
  try{ if(window.Android && Android.vibrate) Android.vibrate(); }catch(e){}
}

// ---------- XP nas ações (cada uma rende uma vez) ----------
function xpTarefa(id){
  const t = D.tarefas.find(x => x.id === id);
  if(t && t.feita && !t.xpDado){ t.xpDado = true; ganharXP(20, 'missão'); }
}
const _concluir = concluir;
concluir = function(id){ _concluir(id); xpTarefa(id); };
const _mover = mover;
mover = function(id, dir){ _mover(id, dir); xpTarefa(id); };
const _togglePasso = togglePasso;
togglePasso = function(tid, i){
  _togglePasso(tid, i);
  const t = D.tarefas.find(x => x.id === tid), p = t && t.passos[i];
  if(p && p.ok && !p.xp){ p.xp = true; ganharXP(5, 'passo'); }
};
const _toggleHab = toggleHab;
toggleHab = function(id){
  _toggleHab(id);
  const x = xpEstado();
  if((D.habFeitos[hoje()] || []).includes(id) && !x.dia.hab.includes(id)){ x.dia.hab.push(id); ganharXP(10, 'rotina'); }
};
const _pagarConta = pagarConta;
pagarConta = function(id){
  _pagarConta(id);
  const c = D.contas.find(x => x.id === id);
  if(c && c.paga && !c.xp){ c.xp = true; ganharXP(15, 'conta paga'); }
};
function xpLanc(qtdAntes){
  const x = xpEstado();
  if(D.lanc.length > qtdAntes && x.dia.lanc < 6){ x.dia.lanc++; ganharXP(5, 'gasto anotado'); }
}
const _salvarLanc = salvarLanc;
salvarLanc = function(tipo){ const n = D.lanc.length; _salvarLanc(tipo); xpLanc(n); };
const _confirmarPend = confirmarPend;
confirmarPend = function(id){ const n = D.lanc.length; _confirmarPend(id); xpLanc(n); };
const _fimFoco = fimFoco;
fimFoco = function(){ _fimFoco(); ganharXP(30, 'foco'); };

// ---------- Tema ----------
function arenaAtiva(){ return (D.cfg && D.cfg.visual) === 'arena'; }
function hudAtivo(){ return (D.cfg && D.cfg.visual) === 'hud'; }
function mudarVisual(v){ D.cfg.visual = v; save(); aplicarVisual(); toast({classico:'Visual clássico', arena:'Visual arena', hud:'Visual HUD'}[v] || 'Visual alterado'); }

const PLUS_CLASSICO = document.querySelector('nav .plus').innerHTML;
const PLUS_ARENA = ''; const _PLUS_ARENA_ANTIGO = '<svg width="60" height="66" viewBox="0 0 60 66"><polygon points="30,2 58,17 58,49 30,64 2,49 2,17" fill="#0B3A47" stroke="#C8AA6E" stroke-width="2"/><path d="M30 22v22M19 33h22" stroke="#CDFAFA" stroke-width="3" stroke-linecap="round"/></svg>';

function aplicarVisual(){
  const a = arenaAtiva(), h = hudAtivo();
  document.body.classList.toggle('arena', a);
  document.body.classList.toggle('hud', h);
  try{
    if(h && window.Android && Android.setBarColor) Android.setBarColor('#05090F');
    else if(window.Android && Android.setBars) Android.setBars(a);
  }catch(e){}
  document.querySelector('nav .plus').innerHTML = a ? PLUS_ARENA : h ? (window.PLUS_HUD || PLUS_CLASSICO) : PLUS_CLASSICO;
  const navT = document.querySelector('nav [data-go=tarefas]');
  if(navT) navT.lastChild.textContent = a ? 'Missões' : 'Tarefas';
  render();
}

// Vida 4: o visual Arena foi removido; o XP continua contando por trás (o Treino usa).
function arenaRender(){}

function visualCard(){
  const c = document.getElementById('visual-card'); if(!c) return;
  const a = arenaAtiva(), x = xpEstado(), n = nivelDe(x.total);
  const v = D.cfg.visual || 'arena';
  c.innerHTML = '<h2>Visual e progresso</h2>'+
    '<div class="seg"><button class="'+(v==='hud'?'on':'')+'" onclick="mudarVisual(\'hud\')">HUD</button><button class="'+(v==='arena'?'on':'')+'" onclick="mudarVisual(\'arena\')">Arena</button><button class="'+(v==='classico'?'on':'')+'" onclick="mudarVisual(\'classico\')">Clássico</button></div>'+
    '<p class="note" style="margin:0">'+({hud:'HUD: painel de status, briefing falado, comandos por voz, alertas e fechamento do dia.', arena:'Arena: visual de jogo com nível e elo.', classico:'Clássico: claro e simples.'}[v]||'')+'</p>'+
    '<p class="note" style="margin:0">Nível '+n.nivel+' · '+esc(n.elo)+' · '+x.total+' XP no total.</p>'+
    '<div class="sub" style="font-weight:700">Comemorações</div>'+
    '<div class="seg"><button class="'+(D.cfg.recompensas!=='animadas'?'on':'')+'" onclick="mudarRecompensas(\'discretas\')">Discretas</button><button class="'+(D.cfg.recompensas==='animadas'?'on':'')+'" onclick="mudarRecompensas(\'animadas\')">Animadas</button></div>'+
    '<p class="note" style="margin:0">Como ganhar XP: missão concluída +20 · passo +5 · item da rotina +10 · conta paga +15 · gasto anotado +5 · foco completo +30. O XP só soma: nada é tirado por atraso.</p>';
}

(function(){
  if(!D.cfg.visual) { D.cfg.visual = 'arena'; save(); }
  if(!D.cfg.recompensas) { D.cfg.recompensas = 'discretas'; save(); }
  // Fundo de subida de nível
  const nu = document.createElement('div'); nu.id = 'nivel-up'; nu.className = 'nivel-up';
  document.body.appendChild(nu);
  // Perfil no Início
  const inicio = document.getElementById('s-inicio');
  // Só a missão: entrar (logo abaixo da missão) e sair
  const fe = document.getElementById('focus');
  const entrar = document.createElement('button'); entrar.id = 'sm-entrar';
  entrar.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/></svg>Só a missão: esconder o resto';
  entrar.onclick = entrarSoMissao;
  fe.insertAdjacentElement('afterend', entrar);
  const sair = document.createElement('button'); sair.id = 'sm-sair'; sair.textContent = 'Mostrar o resto do app';
  sair.onclick = sairSoMissao;
  entrar.insertAdjacentElement('afterend', sair);
  // Cartão em Mais
  const mais = document.getElementById('s-mais');
  const c = document.createElement('div'); c.id = 'visual-card'; c.className = 'card pad';
  c.style.cssText = 'display:flex;flex-direction:column;gap:12px';
  mais.insertBefore(c, mais.children[1] || null);

  const _r = render;
  render = function(){ _r(); arenaRender(); visualCard(); };
  aplicarVisual();
})();
