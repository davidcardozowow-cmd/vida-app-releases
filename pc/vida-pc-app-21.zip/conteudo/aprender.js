// =====================================================================
// Seção "Aprender": como usar IA (base: Flow #663 com Fabio Akita e o
// livro "Competente o Suficiente"). Conteúdo didático + teste rápido por
// lição + montador de pedido + player do YouTube (tela própria no Android).
// Depende de: D, save, toast, esc, go, render, NATIVO (index.html).
// =====================================================================

const APR_VIDEOS = [
  {id:'N3eU-2VIByQ', titulo:'Flow #663 — Fabio Akita', sub:'Episódio completo · 4h17 · Nerds falando sobre IA'},
  {id:'hki3MH4AhVQ', titulo:'Corte: o desbloqueio do PS5 e a IA', sub:'Por que a IA só acelera quando tem como conferir'}
];

const APR_LICOES = [
  {
    id:'pedir', titulo:'Como pedir', frase:'A resposta é tão boa quanto o pedido: diga o que quer, como, o que NÃO quer e como saber que deu certo.',
    explica:[
      'A IA não lê pensamento. Tudo o que está na sua cabeça e não foi escrito, para ela não existe.',
      'Pense nela como um prestador de serviço terceirizado muito rápido: faz exatamente o que foi pedido, com as informações que recebeu.',
      'A parte mais esquecida é o "não quero". É ali que moram os pressupostos que viram erro depois.'
    ],
    exemplo:'Em vez de "escreva um e-mail para o cliente", diga: "quero retomar uma negociação parada (o quê), tom consultivo e curto (como), sem oferecer desconto (não quero), e que termine com uma pergunta fácil de responder (deu certo)".',
    pratica:'No próximo pedido importante, use o botão "Montar um pedido" lá embaixo.',
    teste:{p:'Qual parte do pedido é a mais esquecida e a mais importante?', ops:['O que eu quero','O que eu NÃO quero','Como eu quero'], certa:1,
      exp:'O "não quero" evita que a IA siga o caminho padrão, que pode ser o oposto do que você precisa.'}
  },
  {
    id:'concorda', titulo:'Ela vai concordar com você', frase:'A IA foi treinada para agradar: se a pergunta traz uma opinião, a resposta tende a concordar.',
    explica:[
      'Pergunte "quais os problemas disso?" e ela acha problemas. Pergunte "isso está certo?" e ela acha méritos. O mesmo texto, duas respostas opostas.',
      'Quando falta informação, ela inventa algo plausível, com o mesmo tom seguro de uma verdade. Tom confiante não prova nada.',
      'Defesa: perguntar sem entregar a opinião, pedir a fonte e abrir a fonte, e informar a data de hoje e os dados que faltam.'
    ],
    exemplo:'Antes de decidir uma compra parcelada, em vez de "vale a pena?", peça: "liste os argumentos a favor e contra, e mostre a conta dos juros passo a passo". Depois confira a conta na calculadora.',
    pratica:'Quando eu concordar rápido demais com algo importante, peça: "agora me dê o melhor argumento contra".',
    teste:{p:'A IA respondeu com muita segurança. Isso significa que está certo?', ops:['Sim, ela só fala com certeza quando sabe','Não, a resposta inventada sai com o mesmo tom da verdadeira','Depende do tamanho da resposta'], certa:1,
      exp:'Não existe alarme interno quando ela chuta. Confira na fonte primária: contrato, extrato, norma, documento oficial.'}
  },
  {
    id:'memoria', titulo:'A memória de um peixinho', frase:'A IA não lembra de você: a cada mensagem, ela relê os "bilhetes" que estão na mesa.',
    explica:[
      'O modelo não aprende com as conversas. A cada mensagem, o sistema junta suas instruções, a conversa e as anotações de memória, e ela lê tudo de novo.',
      'Em conversas muito longas, o começo é resumido e perde detalhe. Por isso ela às vezes "esquece" o que foi combinado horas antes.',
      'A solução é guardar o que importa num lugar seu: regras, decisões e onde paramos. É para isso que serve a pasta "Claude + David" no seu Drive.'
    ],
    exemplo:'No fim de uma conversa sobre o app, peça: "resuma o que decidimos, o que descartamos e o que falta, e atualize o Registro do App Vida no Drive".',
    pratica:'Termine a próxima conversa importante pedindo o resumo e salvando na pasta do assunto.',
    teste:{p:'Onde fica a memória que vale para sempre, mesmo trocando de IA?', ops:['Dentro do modelo, que aprende comigo','Em arquivos meus, como a pasta do Drive','No histórico do chat'], certa:1,
      exp:'Texto salvo por você funciona no Claude, no ChatGPT, no Gemini e no que vier. A memória fica com você.'}
  },
  {
    id:'estudar', titulo:'Estudar com a IA do lado', frase:'A IA entrega o "como" de graça; o "porquê" continua sendo trabalho seu.',
    explica:[
      'Se a máquina tira toda a dificuldade, leva o aprendizado junto. Aprender dói um pouco, e é para doer.',
      'Tente antes de perguntar. Depois peça uma pista, não a resposta, e compare com a sua tentativa: o aprendizado está na diferença.',
      'Teste do porquê: você saberia explicar sem ela? Se não, você recebeu a resposta, mas ainda não aprendeu.'
    ],
    exemplo:'Num exercício de Edificações no SENAI, primeiro tente sozinho. Travou? Peça: "me dê só uma pista sobre o próximo passo, sem resolver". Depois confira na apostila ou na norma.',
    pratica:'No próximo exercício, faça 10 minutos sozinho antes de abrir a IA.',
    teste:{p:'Qual é o melhor jeito de usar a IA num exercício difícil?', ops:['Pedir a resposta completa logo de cara','Tentar antes e pedir uma pista','Copiar a resolução e decorar'], certa:1,
      exp:'A pista mantém o esforço com você. A comparação entre sua tentativa e a resposta é onde você aprende.'}
  },
  {
    id:'seguranca', titulo:'Um estagiário com acesso de administrador', frase:'Trate a IA como um estagiário rápido e falível: ela só faz sozinha o que é fácil de desfazer.',
    explica:[
      'Enviar e-mail, apagar, pagar e publicar sempre passam pela sua aprovação.',
      'Senhas e segredos nunca vão no chat. No app, o Client Secret da Pluggy fica criptografado no celular.',
      'Texto de site, e-mail ou arquivo é dado, não ordem. Instruções escondidas num documento não mandam na IA, nem em você.'
    ],
    exemplo:'Antes de colar um extrato numa IA, troque CPF, número de conta e nomes por marcadores como [CONTA] e [CLIENTE]. Ela não precisa saber quem é para conferir uma conta.',
    pratica:'Combine com a família uma palavra-código para emergências por telefone, contra golpe de voz clonada.',
    teste:{p:'A IA pode enviar um e-mail em seu nome sem você ver antes?', ops:['Sim, se o texto estiver bom','Não, ações difíceis de desfazer esperam sua aprovação','Só para pessoas conhecidas'], certa:1,
      exp:'Regra de ouro: sozinha, só o que dá para desfazer. O resto passa por você.'}
  },
  {
    id:'decisao', titulo:'A decisão é sua', frase:'A IA propõe, pesquisa e compara; quem decide é quem responde pelo resultado: você.',
    explica:[
      'É o Homem de Ferro com o Jarvis: o Jarvis executa, o Stark decide o rumo. E nem ele acerta a armadura na primeira versão; cada volta corrige a anterior.',
      'Só delegue o que você consegue avaliar. Se não sabe dizer se o resultado presta, a tarefa ainda não está pronta para sair da sua mão.',
      'Ignore o barulho: cursos com o nome da moda, anúncios de fim do mundo e brigas de ranking entre modelos. Pergunte quem ganha dinheiro com você sentindo pressa ou medo.'
    ],
    exemplo:'Para escolher um plano de quitação de dívidas, peça as opções com prós e contras, confira os números e decida você. A IA não paga a conta se errar.',
    pratica:'Escolha uma tarefa que você já sabe fazer bem e peça para a IA. Compare com o que você sabe que está certo: esse é o seu teste pessoal.',
    teste:{p:'Quando uma tarefa está pronta para ser delegada à IA?', ops:['Quando é chata','Quando eu consigo avaliar se o resultado presta','Quando a IA diz que consegue'], certa:1,
      exp:'Sem saber avaliar, você não percebe quando ela erra.'}
  }
];

const APR_FONTES = [
  ['Flow #663 com Fabio Akita (YouTube)', 'https://www.youtube.com/watch?v=N3eU-2VIByQ'],
  ['Livro gratuito "Competente o Suficiente"', 'https://github.com/akitaonrails/ai-book-2026'],
  ['LLMs + Agentes = competente o suficiente', 'https://akitaonrails.com/2026/10/12/llms-agentes-competente-o-suficiente/'],
  ['Clean Code pra Agentes de IA', 'https://akitaonrails.com/2026/04/20/clean-code-para-agentes-de-ia/'],
  ['Manual de uso da IA do David', 'https://claude.ai/artifact/Prf2JJZDoMLtewriDtRce1']
];

// ---------- Estado ----------
function aprEstado(){
  if(!D.aprender || typeof D.aprender !== 'object') D.aprender = {lidas:{}, respostas:{}};
  D.aprender.lidas = D.aprender.lidas || {}; D.aprender.respostas = D.aprender.respostas || {};
  return D.aprender;
}
let aprAberta = null;

// ---------- Ações ----------
function aprAbrir(id){ aprAberta = aprAberta === id ? null : id; aprRender(); if(aprAberta){ const el = document.getElementById('apr-' + id); if(el) el.scrollIntoView({block:'start'}); } }
function aprResponder(id, i){
  const st = aprEstado(), l = APR_LICOES.find(x => x.id === id);
  st.respostas[id] = i;
  if(i === l.teste.certa){ st.lidas[id] = true; toast('Isso! Lição concluída.'); }
  save(); aprRender(); render();
}
function aprVideo(id){
  if(NATIVO && Android.playVideo) Android.playVideo(id);
  else window.open('https://www.youtube.com/watch?v=' + id, '_blank');
}
function aprLink(url){ if(NATIVO && Android.openUrl) Android.openUrl(url); else window.open(url, '_blank'); }
function aprMontar(){
  const v = k => (document.getElementById('apr-p-' + k).value || '').trim();
  const partes = [['O que eu quero', v('q')], ['Como', v('c')], ['O que eu NÃO quero', v('n')], ['Como saber que deu certo', v('d')]];
  if(!partes[0][1]){ toast('Comece pelo "o que eu quero"'); return; }
  const faltam = partes.filter(p => !p[1]).map(p => p[0]);
  const txt = partes.filter(p => p[1]).map(p => p[0] + ': ' + p[1]).join('\n');
  document.getElementById('apr-saida').textContent = txt;
  document.getElementById('apr-saida-box').style.display = 'flex';
  document.getElementById('apr-faltam').textContent = faltam.length ? 'Faltou: ' + faltam.join(', ') + '. Vale preencher?' : 'Pedido completo.';
}
function aprCopiar(){
  const txt = document.getElementById('apr-saida').textContent;
  if(NATIVO && Android.copy) Android.copy(txt);
  else { try{ navigator.clipboard.writeText(txt); }catch(e){} }
  toast('Copiado. Cole na conversa com o Claude.');
}

// ---------- Render ----------
function aprRender(){
  const el = document.getElementById('s-aprender'); if(!el) return;
  const st = aprEstado(), feitas = APR_LICOES.filter(l => st.lidas[l.id]).length;
  el.innerHTML =
    '<div class="row"><button class="iconbtn" aria-label="Voltar" onclick="go(\'inicio\')"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button><h1>Aprender a usar IA</h1></div>'+
    '<p class="note" style="margin:0">Baseado no Flow #663 com Fabio Akita e no livro dele, "Competente o Suficiente". Seis lições curtas, cada uma com um teste rápido.</p>'+
    '<div class="card pad" style="display:flex;flex-direction:column;gap:8px"><div class="between"><b>Seu progresso</b><b style="color:var(--accent)">'+feitas+' de '+APR_LICOES.length+'</b></div>'+
      '<div class="bar"><div style="width:'+Math.round(feitas/APR_LICOES.length*100)+'%"></div></div></div>'+

    '<h2>Assista</h2>'+
    APR_VIDEOS.map(v =>
      '<button class="card" style="padding:0;border:0;overflow:hidden;text-align:left;display:flex;flex-direction:column" onclick="aprVideo(\''+v.id+'\')">'+
        '<div style="position:relative;width:100%;padding-top:56.25%;background:#17191C">'+
          '<img src="https://i.ytimg.com/vi/'+v.id+'/hqdefault.jpg" alt="" style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover" onerror="this.style.display=\'none\'">'+
          '<div style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center"><div style="width:64px;height:64px;border-radius:32px;background:rgba(0,0,0,.65);display:flex;align-items:center;justify-content:center">'+
          '<svg width="26" height="26" viewBox="0 0 24 24" fill="#fff"><path d="M8 5v14l11-7z"/></svg></div></div></div>'+
        '<div style="padding:12px 16px"><b style="font-size:15px">'+esc(v.titulo)+'</b><div class="sub">'+esc(v.sub)+'</div></div></button>').join('')+
    '<p class="note" style="margin:0">O episódio é longo. Uma boa estratégia: ouça em partes e, quando algo chamar a atenção, anote o minuto e me mande.</p>'+

    '<h2>Lições</h2>'+
    APR_LICOES.map((l, i) => {
      const aberta = aprAberta === l.id, feita = !!st.lidas[l.id], resp = st.respostas[l.id];
      return '<div class="card" id="apr-'+l.id+'" style="padding:0">'+
        '<button style="width:100%;border:0;background:transparent;text-align:left;padding:14px 16px;display:flex;gap:12px;align-items:center" onclick="aprAbrir(\''+l.id+'\')">'+
          '<span style="width:32px;height:32px;border-radius:16px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:14px;'+
            (feita ? 'background:var(--accent);color:#fff">✓' : 'background:var(--accent-soft);color:var(--accent)">'+(i+1))+'</span>'+
          '<span style="flex:1"><b style="font-size:15px;display:block">'+esc(l.titulo)+'</b><span class="sub">'+(aberta?'Toque para fechar':esc(l.frase))+'</span></span></button>'+
        (aberta ?
          '<div style="padding:0 16px 16px;display:flex;flex-direction:column;gap:12px">'+
            '<div style="background:var(--accent-soft);border-radius:14px;padding:12px 14px;font-weight:700;font-size:15px;line-height:1.4">'+esc(l.frase)+'</div>'+
            l.explica.map(p => '<p style="margin:0;font-size:15px;line-height:1.5">'+esc(p)+'</p>').join('')+
            '<div style="border:1px solid var(--border);border-radius:14px;padding:12px 14px"><div class="sub" style="font-weight:700;margin-bottom:4px">EXEMPLO DA SUA VIDA</div><div style="font-size:14px;line-height:1.5">'+esc(l.exemplo)+'</div></div>'+
            '<div style="border:1px solid var(--border);border-radius:14px;padding:12px 14px"><div class="sub" style="font-weight:700;margin-bottom:4px">NA PRÁTICA, HOJE</div><div style="font-size:14px;line-height:1.5">'+esc(l.pratica)+'</div></div>'+
            '<div style="background:#E8E4DA;border-radius:14px;padding:12px 14px;display:flex;flex-direction:column;gap:8px">'+
              '<div class="sub" style="font-weight:700">TESTE RÁPIDO</div><b style="font-size:15px">'+esc(l.teste.p)+'</b>'+
              l.teste.ops.map((o, j) => {
                const marcada = resp === j, certa = j === l.teste.certa;
                const estilo = resp == null ? '' : marcada ? (certa ? 'background:var(--accent);color:#fff;border-color:var(--accent)' : 'background:#FBE3D3;border-color:#E7B7B3;color:var(--danger)') : '';
                return '<button class="btn outline" style="height:auto;min-height:44px;padding:10px 14px;text-align:left;font-weight:600;'+estilo+'" onclick="aprResponder(\''+l.id+'\','+j+')">'+esc(o)+'</button>';
              }).join('')+
              (resp != null ? '<div style="font-size:14px;line-height:1.5"><b>'+(resp === l.teste.certa ? 'Certo! ' : 'Quase. ')+'</b>'+esc(l.teste.exp)+'</div>' : '')+
            '</div></div>' : '')+
      '</div>';
    }).join('')+

    '<h2>Montar um pedido</h2>'+
    '<div class="card pad" style="display:flex;flex-direction:column;gap:10px">'+
      '<p class="note" style="margin:0">Preencha as 4 partes, toque em Montar e cole o resultado na conversa com o Claude.</p>'+
      '<label class="f">1. O que eu quero<input id="apr-p-q" placeholder="Ex.: um e-mail para retomar a negociação com o cliente"></label>'+
      '<label class="f">2. Como<input id="apr-p-c" placeholder="Ex.: tom consultivo, curto, citando a dor dele"></label>'+
      '<label class="f">3. O que eu NÃO quero<input id="apr-p-n" placeholder="Ex.: sem desconto, sem prometer prazo"></label>'+
      '<label class="f">4. Como saber que deu certo<input id="apr-p-d" placeholder="Ex.: termina com uma pergunta fácil de responder"></label>'+
      '<button class="btn primary" onclick="aprMontar()">Montar</button>'+
      '<div id="apr-saida-box" style="display:none;flex-direction:column;gap:8px">'+
        '<pre id="apr-saida" style="margin:0;white-space:pre-wrap;font-family:inherit;font-size:14px;background:#F4F2EC;border-radius:12px;padding:12px"></pre>'+
        '<span class="sub" id="apr-faltam"></span>'+
        '<button class="btn dark" onclick="aprCopiar()">Copiar pedido</button></div></div>'+

    '<h2>Checklist "vamos evoluir"</h2>'+
    '<div class="card pad" style="display:flex;flex-direction:column;gap:6px;font-size:15px;line-height:1.5">'+
      ['O pedido tem as 4 partes? Falta algum "não quero"?','Como vamos saber que deu certo? Tem teste ou fonte?','O contexto está guardado num lugar meu (Drive, memória)?','Tem algo que só eu sei e a IA não tem como saber?','Alguma ação é difícil de desfazer? Então espera minha aprovação.','No fim: resumo do que decidimos, descartamos e falta.']
        .map(x => '<div class="row" style="align-items:flex-start"><span style="color:var(--accent);font-weight:800">✓</span><span>'+esc(x)+'</span></div>').join('')+
    '</div>'+

    '<h2>Para ir mais fundo</h2>'+
    '<div class="card" style="padding:4px 16px">'+APR_FONTES.map(f =>
      '<button class="item" style="width:100%;border:0;border-bottom:1px solid var(--line);background:transparent;text-align:left" onclick="aprLink(\''+f[1]+'\')"><span class="txt">'+esc(f[0])+'</span><span class="sub">abrir</span></button>').join('')+'</div>';
}

// ---------- Integração com o app ----------
(function(){
  const sec = document.createElement('section');
  sec.className = 'screen'; sec.id = 's-aprender';
  document.querySelector('main').appendChild(sec);

  // Atalho em "Mais"
  const mais = document.getElementById('s-mais');
  const card = document.createElement('button');
  card.className = 'card pad'; card.style.cssText = 'border:0;text-align:left;display:flex;flex-direction:column;gap:6px;background:var(--accent);color:#fff';
  card.innerHTML = '<b style="font-size:17px">Aprender a usar IA</b><span style="font-size:14px;opacity:.9">6 lições curtas, vídeo do Flow #663 e o montador de pedidos</span>';
  card.onclick = () => go('aprender');
  mais.insertBefore(card, mais.children[1]);

  // Atalho no Início
  const inicio = document.getElementById('s-inicio');
  const ban = document.createElement('button');
  ban.id = 'apr-banner'; ban.className = 'card ini-card apr-card';
  ban.onclick = () => go('aprender');
  inicio.appendChild(ban);

  const _r = render;
  render = function(){
    _r();
    const st = aprEstado(), feitas = APR_LICOES.filter(l => st.lidas[l.id]).length;
    const prox = APR_LICOES.find(l => !st.lidas[l.id]);
    const ix = prox ? APR_LICOES.indexOf(prox) : -1;
    document.getElementById('apr-banner').innerHTML =
      '<div class="ini-corpo">' +
        '<div class="apr-topo"><span class="apr-ico"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l1.9 4.6L18.5 9l-4.6 1.9L12 15.5l-1.9-4.6L5.5 9l4.6-1.4z"/><path d="M19 15l.8 1.9 1.9.8-1.9.8L19 20.5l-.8-1.9-1.9-.8 1.9-.8z"/></svg></span>' +
          '<span style="flex:1;min-width:0"><b>Aprender a usar IA</b><small>' + feitas + ' de ' + APR_LICOES.length + ' lições · 2 min cada</small></span>' +
          '<span class="apr-pct">' + Math.round(100 * feitas / APR_LICOES.length) + '%</span></div>' +
        '<div class="apr-trilha">' + APR_LICOES.map((l, i) => '<span class="' + (st.lidas[l.id] ? 'ok' : i === ix ? 'agora' : '') + '" title="' + esc(l.titulo) + '"></span>').join('') + '</div>' +
        (prox
          ? '<div class="apr-prox"><small>Próxima · lição ' + (ix + 1) + '</small><b>' + esc(prox.titulo) + '</b><span class="apr-frase">' + esc(prox.frase) + '</span></div><span class="ini-cta">Começar a lição</span>'
          : '<div class="apr-prox"><b>Todas as lições concluídas</b><span class="apr-frase">Revise quando quiser ou use o montador de pedidos.</span></div><span class="ini-cta">Abrir</span>') +
      '</div>';
    if(tela === 'aprender' && !document.getElementById('s-aprender').innerHTML) aprRender();
  };
  const _go = go;
  go = function(t){ _go(t); if(t === 'aprender') aprRender(); };
  render();
})();
