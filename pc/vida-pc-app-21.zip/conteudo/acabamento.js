// =====================================================================
// v4.1 ACABAMENTO (sem funções novas). Carregado depois do v4.js.
// 1. Formulários enxutos: o essencial em cima; o resto em "Mais opções". "Quando" vira botões.
//    Gasto sugere a categoria pela descrição. (Os campos mantêm os mesmos ids: as funções de salvar não mudam.)
// 2. Toque curtinho (Android.tick) ao concluir, marcar passo/rotina, pagar e salvar.
// 3. Deslizar a tarefa para a direita conclui (listas).
// 4. Sua cara: cor de destaque (D.cfg.cor) e frase pessoal no topo do Hoje (D.cfg.frase).
// 5. Notícias, Clientes e Treino no padrão do Vida 4 (menos botões e caixas).
// 6. Transição suave entre telas (respeita "reduzir movimento").
// =====================================================================

// ---------- 1. Formulários ----------
function acMaisOpcoes(sh, nos, aberto, resumo){
  nos = nos.filter(Boolean); if(!nos.length) return null;
  const d = document.createElement('details'); d.className = 'mais-op'; if(aberto) d.open = true;
  d.innerHTML = '<summary><span>Mais opções</span><small class="mais-res">' + esc(resumo || '') + '</small></summary><div class="mais-corpo"></div>';
  const corpo = d.querySelector('.mais-corpo');
  const salvar = [...sh.querySelectorAll('.btn.primary')].find(b => /Salvar/.test(b.textContent)) || sh.querySelector('.btn.primary');
  nos.forEach(n => corpo.appendChild(n));
  if(salvar) salvar.insertAdjacentElement('beforebegin', d); else sh.appendChild(d);
  return d;
}
const acCampo = id => { const e = document.getElementById(id); return e ? (e.closest('label.f') || e.closest('.f') || e) : null; };
function acChips(sh, select, opcoes, depoisDe){
  if(!select) return;
  const box = document.createElement('div'); box.className = 'ac-chips';
  const pinta = () => box.querySelectorAll('button').forEach(b => b.classList.toggle('on', b.dataset.v === select.value));
  opcoes.forEach(([v, n]) => {
    const b = document.createElement('button'); b.type = 'button'; b.dataset.v = v; b.textContent = n;
    b.onclick = () => { select.value = v; select.dispatchEvent(new Event('change', {bubbles: true})); pinta(); acTick(); };
    box.appendChild(b);
  });
  const lab = select.closest('label.f'); if(lab) lab.style.display = 'none';
  (depoisDe || lab).insertAdjacentElement('afterend', box);
  pinta();
}
function acForm(tipo, id){
  const sh = document.getElementById('sheet');
  if(tipo === 'tarefa'){
    const t = id ? D.tarefas.find(x => x.id === id) : null;
    acChips(sh, document.getElementById('f-quando'), [['hoje', 'Hoje'], ['amanha', 'Amanhã'], ['sem', 'Sem data'], ['data', 'Escolher dia']], acCampo('f-titulo'));
    const temExtra = t && (t.area !== 'pes' || t.min || (t.passos && t.passos.length));
    const area = val('f-area');
    acMaisOpcoes(sh, [acCampo('f-area'), acCampo('f-min'), acCampo('f-passos')], !!temExtra,
      'Área: ' + ((AREAS[area] || {}).nome || '') + ' · tempo e passos');
  }
  if(tipo === 'gasto' || tipo === 'entrada'){
    const desc = document.getElementById('f-desc'), cat = document.getElementById('f-cat');
    const det = acMaisOpcoes(sh, [acCampo('f-cat'), acCampo('f-data')], false, (cat ? 'Categoria: ' + cat.value + ' · ' : '') + 'hoje');
    // Sugere a categoria pela descrição (dá para trocar em "Mais opções")
    if(desc && cat && typeof mapCat === 'function'){
      let mexeu = false; cat.addEventListener('change', () => { mexeu = true; });
      const atualiza = () => {
        if(!mexeu){ const c = mapCat('', desc.value); if(CATS.includes(c) && c !== 'Outros') cat.value = c; }
        const r = det && det.querySelector('.mais-res'); if(r) r.textContent = 'Categoria: ' + cat.value + ' · ' + quando(val('f-data') || hoje()).toLowerCase();
      };
      desc.addEventListener('input', atualiza); cat.addEventListener('change', atualiza);
      const dt = document.getElementById('f-data'); if(dt) dt.addEventListener('change', atualiza);
    }
  }
  if(tipo === 'conta'){
    const c = id ? D.contas.find(x => x.id === id) : null;
    acMaisOpcoes(sh, [acCampo('f-cat'), (document.getElementById('f-rep') || {}).closest ? document.getElementById('f-rep').closest('label') : null], !!(c && c.repetir), 'Categoria e repetir todo mês');
  }
  if(tipo === 'cliente'){
    const c = id ? (D.clientes || []).find(x => x.id === id) : null;
    acMaisOpcoes(sh, [acCampo('f-emp'), acCampo('f-tel'), acCampo('f-etapa'), acCampo('f-valor'), acCampo('f-notas')], !!c, 'Empresa, WhatsApp, etapa, valor e notas');
  }
}

// ---------- 2. Toque curtinho ----------
function acTick(){ try{ if(window.Android && Android.tick) Android.tick(); }catch(e){} }

// ---------- 3. Deslizar para concluir ----------
function acDeslizar(){
  let el = null, x0 = 0, y0 = 0, dx = 0, ativo = false;
  document.addEventListener('touchstart', e => {
    const it = e.target.closest('#hoje-lista .item, #tarefas-lista .item');
    if(!it || !it.querySelector('input[type=checkbox]') || e.target.closest('input,button')) { el = null; return; }
    el = it; x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; dx = 0; ativo = false;
  }, {passive: true});
  document.addEventListener('touchmove', e => {
    if(!el) return;
    const mx = e.touches[0].clientX - x0, my = e.touches[0].clientY - y0;
    if(!ativo && Math.abs(my) > Math.abs(mx)) { el = null; return; }
    if(mx > 8){ ativo = true; dx = Math.min(mx, 140); el.style.transform = 'translateX(' + dx + 'px)'; el.classList.toggle('desl-ok', dx > 90); }
  }, {passive: true});
  document.addEventListener('touchend', () => {
    if(!el) return;
    const alvo = el; el.style.transform = ''; el.classList.remove('desl-ok');
    if(ativo && dx > 90){ const cb = alvo.querySelector('input[type=checkbox]'); if(cb) cb.click(); }
    el = null;
  });
}

// ---------- 4. Sua cara: cor de destaque e frase ----------
const CORES = {
  azul:    ['#5CC8FF', '#04131D', '#0B7FB8'],
  verde:   ['#3DDBB0', '#03211A', '#0E7A5F'],
  roxo:    ['#A99BFF', '#140F2E', '#5B4BC4'],
  laranja: ['#FFB25C', '#2A1603', '#B5610A'],
  rosa:    ['#FF8FB8', '#2B0A17', '#B23A68']
};
function corAplicar(){
  const c = CORES[D.cfg.cor] || CORES.azul, claro = D.cfg.tema === 'claro', b = document.body.style;
  const cor = claro ? c[2] : c[0];
  b.setProperty('--accent', cor);
  b.setProperty('--on-accent', claro ? '#FFFFFF' : c[1]);
  b.setProperty('--accent-soft', cor + (claro ? '1A' : '1F'));
}
function mudarCor(k){ D.cfg.cor = k; save(); corAplicar(); acTick(); render(); }
function salvarFrase(v){ D.cfg.frase = String(v || '').trim().slice(0, 90); save(); render(); }
function acAparenciaHTML(){
  const atual = D.cfg.cor || 'azul';
  return '<div class="card pad" style="display:flex;flex-direction:column;gap:12px">' +
    '<div class="sub" style="font-weight:600">Cor de destaque</div>' +
    '<div class="ac-cores">' + Object.keys(CORES).map(k => '<button aria-label="' + k + '" class="' + (k === atual ? 'on' : '') + '" style="background:' + (D.cfg.tema === 'claro' ? CORES[k][2] : CORES[k][0]) + '" onclick="mudarCor(\'' + k + '\')"></button>').join('') + '</div>' +
    '<label class="f">Sua frase no Hoje (opcional)<input id="ac-frase" maxlength="90" value="' + esc(D.cfg.frase || '') + '" placeholder="Ex.: Um passo de cada vez." onchange="salvarFrase(this.value)"></label></div>';
}

// ---------- 5. Telas antigas no padrão ----------
function acTreino(){
  const s = document.getElementById('s-treino'); if(!s) return;
  s.querySelectorAll('.tr-col').forEach(c => {
    if(c.dataset.ac || !/Como funciona a sessão/.test(c.textContent)) return;
    c.dataset.ac = '1';
    const d = document.createElement('details'); d.className = 'mais-op tr-como';
    d.innerHTML = '<summary><span>Como funciona a sessão</span><small class="mais-res">6 passos · regra-mãe</small></summary>';
    const b = c.querySelector('b'); if(b) b.remove();
    const corpo = document.createElement('div'); corpo.className = 'mais-corpo';
    while(c.firstChild) corpo.appendChild(c.firstChild);
    d.appendChild(corpo); c.replaceWith(d);
  });
}

(function(){
  const _open = openSheet;
  openSheet = function(tipo, id){ _open(tipo, id); try { acForm(tipo, id); } catch(e){} };
  // Toque curtinho nas ações que completam algo
  ['concluir', 'togglePasso', 'toggleHab', 'pagarConta', 'salvarLanc', 'salvarTarefa', 'salvarConta', 'salvarContato'].forEach(n => {
    if(typeof window[n] !== 'function') return;
    const f = window[n];
    window[n] = function(){ acTick(); return f.apply(this, arguments); };
  });
  // Aparência: tema + cor + frase
  const _apar = ajAparenciaHTML;
  ajAparenciaHTML = function(){ return _apar() + acAparenciaHTML(); };
  const _tema = mudarTema;
  mudarTema = function(t){ _tema(t); corAplicar(); render(); };
  // Frase pessoal no topo do Hoje
  const _painel = v4Painel;
  v4Painel = function(){
    _painel();
    const el = document.getElementById('hud-painel'); if(!el || !D.cfg.frase) return;
    const ola = el.querySelector('.v4-ola'); if(!ola || el.querySelector('.ac-frase')) return;
    const f = document.createElement('div'); f.className = 'ac-frase'; f.textContent = D.cfg.frase;
    ola.insertAdjacentElement('afterend', f);
  };
  hudPainel = v4Painel;
  if(typeof trRender === 'function'){ const _tr = trRender; trRender = function(){ _tr(); acTreino(); }; }
  // Transição suave entre telas
  const _go = go;
  go = function(t){ _go(t); const s = document.getElementById('s-' + t); if(s){ s.classList.remove('entra'); void s.offsetWidth; s.classList.add('entra'); } };
  acDeslizar(); corAplicar();
  const sec = document.getElementById('aj-apar-corpo'); if(sec) sec.innerHTML = ajAparenciaHTML();
  render();
})();

// ---------- 7. (v4.3) Finanças: para onde foi o dinheiro do mês + versão no rodapé ----------
function acCategorias(){
  const fin = document.getElementById('s-financas'); if(!fin) return;
  let box = document.getElementById('fin-cats');
  if(!box){
    box = document.createElement('div'); box.id = 'fin-cats'; box.className = 'card pad';
    const bal = fin.querySelector('.balance'); if(bal) bal.insertAdjacentElement('afterend', box); else fin.appendChild(box);
  }
  const por = {}; let total = 0;
  lancMes().filter(l => !l.interno && l.tipo !== 'in').forEach(l => { const c = l.cat || 'Outros'; por[c] = (por[c] || 0) + l.valor; total += l.valor; });
  const lista = Object.entries(por).sort((a, b) => b[1] - a[1]);
  if(!lista.length){ box.style.display = 'none'; return; }
  box.style.display = '';
  const top = lista.slice(0, 5), resto = lista.slice(5).reduce((s, x) => s + x[1], 0);
  if(resto > 0) top.push(['Outras', resto]);
  const maior = top[0][1];
  box.innerHTML = '<div class="between" style="margin-bottom:12px"><b style="font-size:15px">Para onde foi o dinheiro</b><span class="sub">' + MESES[new Date().getMonth()] + '</span></div>' +
    '<div class="fc-lista">' + top.map(([c, v], i) => '<div class="fc-item"><div class="fc-top"><span>' + esc(c) + '</span><span><b>' + brl(v) + '</b> · ' + Math.round(100 * v / total) + '%</span></div>' +
      '<div class="fc-barra"><span style="width:' + Math.max(3, Math.round(100 * v / maior)) + '%;opacity:' + (i === 0 ? 1 : Math.max(.45, 1 - i * .12)) + '"></span></div></div>').join('') + '</div>';
}
(function(){
  const _r = render;
  render = function(){ _r(); try { acCategorias(); } catch(e){} };
  const v = document.getElementById('versao-rodape');
  if(v){ try { v.textContent = 'Vida · versão ' + (NATIVO && Android.appVersion ? Android.appVersion() : '—'); } catch(e){} }
  render();
})();
