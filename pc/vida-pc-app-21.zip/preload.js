// Ponte window.Android do PC: mesmos nomes do celular, para o app não precisar saber onde está.
// O que não existe no PC (vibrar, widget, ouvir comando de voz) simplesmente não faz nada ou não é oferecido.
'use strict';
const { contextBridge, ipcRenderer, webFrame } = require('electron');
const S = (n, ...a) => ipcRenderer.sendSync('sync', n, ...a);
const A = (n, ...a) => ipcRenderer.send('async', n, ...a);
const cb = (fn, ...args) => webFrame.executeJavaScript('window.' + fn + ' && window.' + fn + '(' + args.map(x => JSON.stringify(x)).join(',') + ')');
const nada = () => {};

// ---------- Voz do Windows (Microsoft Maria/Daniel em português, se instaladas) ----------
let voz = { nome: '', vel: 1, tom: 1 };
const vozes = () => speechSynthesis.getVoices();
function escolherVoz() {
  const v = vozes();
  return v.find(x => x.name === voz.nome) || v.find(x => /^pt-BR/i.test(x.lang)) || v.find(x => /^pt/i.test(x.lang)) || null;
}
function falar(t) {
  speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(String(t || '').slice(0, 3500));
  const v = escolherVoz();
  if (!v) { cb('__falaCb', 'erro'); return; }
  u.voice = v; u.lang = v.lang; u.rate = voz.vel; u.pitch = voz.tom;
  u.onstart = () => cb('__falaCb', 'inicio');
  u.onend = u.onerror = () => cb('__falaCb', 'fim');
  speechSynthesis.speak(u);
}
function listarVozes() {
  const montar = () => cb('__vozesCb', JSON.stringify({
    motores: [{ pkg: 'windows', nome: 'Vozes do Windows' }], motorAtual: 'windows',
    vozes: vozes().map(v => ({ nome: v.name, local: v.lang.replace('-', '_'), rede: !v.localService, qualidade: 300, instalada: true }))
  }));
  if (vozes().length) montar(); else { speechSynthesis.onvoiceschanged = () => { speechSynthesis.onvoiceschanged = null; montar(); }; setTimeout(montar, 1500); }
}
const copiar = t => { A('copy', t); webFrame.executeJavaScript('window.toast && toast("Texto copiado")'); };

contextBridge.exposeInMainWorld('Android', {
  plataforma: () => 'pc',
  // Rede e dados
  http: (id, metodo, url, cab, corpo) => A('http', id, metodo, url, cab, corpo),
  fetchText: (id, url) => A('fetchText', id, url),
  secureGet: k => S('secureGet', k),
  secureSet: (k, v) => S('secureSet', k, v),
  persist: t => A('persist', t),
  loadPersisted: () => S('loadPersisted'),
  saveBackup: (nome, c) => S('saveBackup', nome, c),
  pickFile: () => A('pickFile'),
  // Abrir e compartilhar
  openUrl: u => A('openUrl', u),
  playVideo: id => A('openUrl', 'https://www.youtube.com/watch?v=' + encodeURIComponent(id)),
  copy: t => A('copy', t),
  share: copiar, shareText: copiar,
  askApp: (pacote, t) => { A('copy', t); A('openUrl', /openai/.test(pacote) ? 'https://chatgpt.com/' : 'https://claude.ai/new'); },
  takeShared: () => '', takeNotifs: () => '[]', takeVoiceRequest: () => false,
  // Voz
  speak: falar,
  stopSpeak: () => { speechSynthesis.cancel(); cb('__falaCb', 'fim'); },
  setVoice: (motor, nome, vel, tom) => { voz = { nome: nome || '', vel: Math.max(0.5, Math.min(2, +vel || 1)), tom: Math.max(0.5, Math.min(2, +tom || 1)) }; },
  listVoices: listarVozes,
  // Lembretes e notificações
  setReminders: j => A('setReminders', j),
  notifEnabled: () => false, notifPostEnabled: () => true, requestNotifPost: nada, openNotifSettings: nada,
  takeOpenRequest: () => S('takeOpenRequest'),
  // Atualização
  appVersion: () => S('appVersion'),
  checkUpdate: id => A('checkUpdate', id),
  installUpdate: () => A('installUpdate'),
  // Trava das Finanças: o PC já é protegido pelo login do Windows
  auth: id => setTimeout(() => cb('__authCb', id, 'ok'), 0),
  // Só existem no celular
  vibrate: nada, tick: nada, setBars: nada, setBarColor: nada, setWidget: nada
});
window.addEventListener('DOMContentLoaded', () => document.body.classList.add('pc'));
// Atalhos de teclado: Ctrl+N nova tarefa, Ctrl+G gasto, Esc fecha o formulário, Ctrl+1..4 telas
window.addEventListener('keydown', e => {
  const run = c => { e.preventDefault(); webFrame.executeJavaScript(c); };
  if (e.key === 'Escape') return webFrame.executeJavaScript('sheetTipo && closeSheet()');
  if (!e.ctrlKey || e.altKey) return;
  const k = e.key.toLowerCase();
  if (k === 'n') run("openSheet('tarefa')");
  else if (k === 'g') run("openSheet('gasto')");
  else if (['1', '2', '3', '4'].includes(k)) run("closeSheet(); go(['inicio','tarefas','financas','noticias'][" + (Number(k) - 1) + "])");
});
